package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#excelSheetAutoMapping.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseExcelSheetAutoMappingScenario {

    @Test
    @DisplayName("UTAPI-012456")
    void case_UTAPI_012456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012456",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012456", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012456", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012456", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012456", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012456", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012456")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012457")
    void case_UTAPI_012457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012457",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012457", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012457", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012457", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012457", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012457", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012457")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012458")
    void case_UTAPI_012458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012458",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012458", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012458", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012458", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012458", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012458", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012458")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012459")
    void case_UTAPI_012459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012459",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012459", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012459", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012459", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012459", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012459", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012459")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012460")
    void case_UTAPI_012460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012460",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012460", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012460", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012460", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012460", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012460", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012460")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012461")
    void case_UTAPI_012461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012461",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012461", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012461", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012461", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012461", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012461", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012461")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012462")
    void case_UTAPI_012462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012462",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012462", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012462", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012462", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012462", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012462", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012462")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012463")
    void case_UTAPI_012463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012463",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012463", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012463", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012463", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012463", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012463", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012463")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012464")
    void case_UTAPI_012464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012464",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012464", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012464", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012464", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012464", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012464", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012464")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012465")
    void case_UTAPI_012465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012465",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012465", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012465", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012465", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012465", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012465", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012465")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012466")
    void case_UTAPI_012466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012466",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012466", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012466", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012466", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012466", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012466", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012466")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012467")
    void case_UTAPI_012467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012467",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012467", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012467", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012467", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012467", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012467", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012467")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012468")
    void case_UTAPI_012468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012468",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012468", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012468", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012468", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012468", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012468", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012468")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012469")
    void case_UTAPI_012469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012469",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012469", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012469", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012469", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012469", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012469", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012469")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012470")
    void case_UTAPI_012470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012470",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012470", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012470", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012470", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012470", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012470", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012470")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012471")
    void case_UTAPI_012471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012471",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012471", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012471", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012471", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012471", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012471")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012472")
    void case_UTAPI_012472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012472",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012472", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012472", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012472", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012472", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012472")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012473")
    void case_UTAPI_012473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012473",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012473", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012473", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012473", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012473", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012473")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012474")
    void case_UTAPI_012474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012474",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012474", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012474", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012474", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012474", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012474")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012475")
    void case_UTAPI_012475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012475",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012475", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012475", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012475", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012475", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012475")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012476")
    void case_UTAPI_012476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012476",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012476", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012476", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012476", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012476", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012476")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012477")
    void case_UTAPI_012477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012477",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012477", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012477", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012477", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012477", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012477")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012478")
    void case_UTAPI_012478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012478",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012478", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012478", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012478", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012478", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012478")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012479")
    void case_UTAPI_012479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012479",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012479", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012479", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012479", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012479", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012479")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012480")
    void case_UTAPI_012480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012480",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012480", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012480", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012480", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012480", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012480")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012481")
    void case_UTAPI_012481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012481",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012481", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012481", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012481", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012481", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012481")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012482")
    void case_UTAPI_012482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012482",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012482", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012482", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012482", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012482", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012482")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012483")
    void case_UTAPI_012483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012483",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012483", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012483", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012483", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012483", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012483")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012484")
    void case_UTAPI_012484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012484",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012484", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012484", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012484", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012484", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012484")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012485")
    void case_UTAPI_012485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012485",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012485", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012485", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012485", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012485", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012485")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012486")
    void case_UTAPI_012486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012486",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012486", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012486", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012486", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012486", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012486")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012487")
    void case_UTAPI_012487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012487",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012487", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012487", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012487", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012487", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012487")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012488")
    void case_UTAPI_012488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012488",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012488", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012488", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012488", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012488", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012488", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012488")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012489")
    void case_UTAPI_012489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012489",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012489", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012489", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012489", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012489", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012489", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012489")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012490")
    void case_UTAPI_012490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012490",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012490", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012490", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012490", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012490", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012490", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012490")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012491")
    void case_UTAPI_012491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012491",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012491", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012491", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012491", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012491", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012491", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012491")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012492")
    void case_UTAPI_012492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012492",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012492", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012492", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012492", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012492", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012492", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012492")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012493")
    void case_UTAPI_012493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012493",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012493", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012493", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012493", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012493", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012493", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012493")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012494")
    void case_UTAPI_012494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012494",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012494", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012494", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012494", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012494", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012494", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012494")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012495")
    void case_UTAPI_012495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012495",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012495", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012495", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012495", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012495", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012495", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012495")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012496")
    void case_UTAPI_012496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012496",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012496", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012496", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012496", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012496", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012496", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012496")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012497")
    void case_UTAPI_012497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012497",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012497", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012497", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012497", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012497", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012497", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012497")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012498")
    void case_UTAPI_012498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012498",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012498", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012498", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012498", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012498", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012498", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012498")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012499")
    void case_UTAPI_012499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012499",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012499", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012499", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012499", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012499", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012499", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012499")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012500")
    void case_UTAPI_012500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012500",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012500", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012500", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012500", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012500", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012500", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012500")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012501")
    void case_UTAPI_012501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012501",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012501", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012501", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012501", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012501", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012501", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012501")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012502")
    void case_UTAPI_012502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012502",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012502", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012502", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012502", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012502", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012502", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012502")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012503")
    void case_UTAPI_012503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012503",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012503", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012503", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012503", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012503", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012503", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012503")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012504")
    void case_UTAPI_012504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012504",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012504", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012504", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012504", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012504", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012504", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012504")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012505")
    void case_UTAPI_012505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012505",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012505", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012505", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012505", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012505", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012505", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012505")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012506")
    void case_UTAPI_012506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012506",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012506", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012506", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012506", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012506", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012506", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012506")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012507")
    void case_UTAPI_012507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012507",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012507", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012507", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012507", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012507", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012507", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012507")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012508")
    void case_UTAPI_012508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012508",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012508", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012508", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012508", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012508", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012508", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012508")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::3::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012509")
    void case_UTAPI_012509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012509",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012509", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012509", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012509", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012509", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012509")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::4::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012510")
    void case_UTAPI_012510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012510",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012510", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012510", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012510", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012510", "sheetIndex", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012510")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::4::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "connectionSettingRepository", "findById", "0", "data:file")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012511")
    void case_UTAPI_012511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012511",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012511", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012511", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012511", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012511", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012511")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "1:length_null", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012512")
    void case_UTAPI_012512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012512",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012512", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012512", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012512", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012512", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012512")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "2:length_empty", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012513")
    void case_UTAPI_012513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012513",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012513", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012513", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012513", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012513", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012513")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "3:length_min", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012514")
    void case_UTAPI_012514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012514",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012514", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012514", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012514", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012514", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012514")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012515")
    void case_UTAPI_012515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012515",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012515", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012515", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012515", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012515", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012515")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "5:length_max", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012516")
    void case_UTAPI_012516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012516",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012516", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012516", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012516", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012516", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012516")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012517")
    void case_UTAPI_012517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012517",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012517", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012517", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012517", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012517", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012517")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012518")
    void case_UTAPI_012518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012518",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012518", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012518", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012518", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012518", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012518")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("46:hw_integer", "-", "-")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012519")
    void case_UTAPI_012519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012519",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012519", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012519", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012519", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012519", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012519")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "-", "12:integer_positive")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012520")
    void case_UTAPI_012520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012520",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012520", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012520", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012520", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012520", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012520")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "-", "13:integer_negative")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a sheet selection outside the uploaded workbook must be rejected before any table access", "java.lang.Exception", "importRepository", "data:sheetIndex")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012521")
    void case_UTAPI_012521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012521",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "excelSheetAutoMapping",
                "AutoMappingResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("sheetIndex", "int", "sheetIndex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012521", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-012521", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012521", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012521", "sheetIndex", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-012521")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::excelSheetAutoMapping::3::ARG::5::-::sheetIndex")
                    .mirror("-", "-", "14:integer_zero")
                    .target("sheetIndex", "sheetIndex")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.findColumnNames")
                    .expected("the value generated for sheetIndex is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.findColumnNames", "importRepository", "findColumnNames")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.findColumnNames must carry the value generated for schemaName", "importRepository", "findColumnNames", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.findColumnNames must carry the value generated for tableName", "importRepository", "findColumnNames", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "the first sheet of the workbook must be readable and supply the reported header", "getCsvHeaders", "text:COL_A", "data:sheetIndex")
                    .check(CheckType.RETURN_FIELD_CONTAINS, "an accepted sheet selection must report the content of that sheet", "getCsvHeaders", "text:COL_A")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

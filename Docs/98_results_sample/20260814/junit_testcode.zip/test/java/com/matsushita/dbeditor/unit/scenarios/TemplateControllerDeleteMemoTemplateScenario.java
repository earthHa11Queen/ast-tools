package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateController#deleteMemoTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateControllerDeleteMemoTemplateScenario {

    @Test
    @DisplayName("UTAPI-001745")
    void case_UTAPI_001745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001745",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001745", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001745")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001746")
    void case_UTAPI_001746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001746",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001746", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001746")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001747")
    void case_UTAPI_001747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001747",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001747", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001747")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001748")
    void case_UTAPI_001748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001748",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001748", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001748")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001749")
    void case_UTAPI_001749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001749",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001749", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001749")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001750")
    void case_UTAPI_001750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001750",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001750", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001750")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001751")
    void case_UTAPI_001751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001751",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001751", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001751")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001752")
    void case_UTAPI_001752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001752",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001752", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001752")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001753")
    void case_UTAPI_001753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001753",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001753", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001753")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001754")
    void case_UTAPI_001754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001754",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001754", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001754")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001755")
    void case_UTAPI_001755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001755",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "deleteMemoTemplate",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001755", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001755")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.deleteMemoTemplate")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.deleteMemoTemplate", "templateUseCase", "deleteMemoTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.deleteMemoTemplate must carry the value generated for n", "templateUseCase", "deleteMemoTemplate", "0", "data:n")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

}

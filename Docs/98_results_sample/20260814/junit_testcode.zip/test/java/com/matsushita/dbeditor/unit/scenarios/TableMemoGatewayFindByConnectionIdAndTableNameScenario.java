package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMemoGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMemoGateway#findByConnectionIdAndTableName.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMemoGatewayFindByConnectionIdAndTableNameScenario {

    @Test
    @DisplayName("UTAPI-004687")
    void case_UTAPI_004687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004687",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004687", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004687")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004688")
    void case_UTAPI_004688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004688",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004688", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004688")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004689")
    void case_UTAPI_004689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004689",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004689", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004689")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004690")
    void case_UTAPI_004690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004690",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004690", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004690")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004691")
    void case_UTAPI_004691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004691",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004691", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004691")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004692")
    void case_UTAPI_004692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004692",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004692", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004692")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004693")
    void case_UTAPI_004693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004693",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004693", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004693")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004694")
    void case_UTAPI_004694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004694",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004694", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004694")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004695")
    void case_UTAPI_004695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004695",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004695", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004695")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004696")
    void case_UTAPI_004696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004696",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004696", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004696")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004697")
    void case_UTAPI_004697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004697",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004697", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004697")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004698")
    void case_UTAPI_004698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004698",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004698", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004698", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004698")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004699")
    void case_UTAPI_004699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004699",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004699", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004699", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004699")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004700")
    void case_UTAPI_004700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004700",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004700", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004700", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004700")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004701")
    void case_UTAPI_004701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004701",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004701", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004701", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004701")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004702")
    void case_UTAPI_004702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004702",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004702", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004702", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004702")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004703")
    void case_UTAPI_004703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004703",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004703", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004703", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004703")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004704")
    void case_UTAPI_004704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004704",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004704", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004704", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004704")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004705")
    void case_UTAPI_004705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004705",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004705", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004705", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004705")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004706")
    void case_UTAPI_004706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004706",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004706", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004706", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004706")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004707")
    void case_UTAPI_004707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004707",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004707", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004707", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004707")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004708")
    void case_UTAPI_004708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004708",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004708", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004708", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004708")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004709")
    void case_UTAPI_004709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004709",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004709", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004709", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004709")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004710")
    void case_UTAPI_004710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004710",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004710", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004710", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004710")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004711")
    void case_UTAPI_004711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004711",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004711", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004711", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004711")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004712")
    void case_UTAPI_004712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004712",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004712", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004712", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004712")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004713")
    void case_UTAPI_004713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004713",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004713", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004713", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004713")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004714")
    void case_UTAPI_004714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004714",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004714", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004714", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004714")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004715")
    void case_UTAPI_004715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004715",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004715", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004715", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004715")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004716")
    void case_UTAPI_004716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004716",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004716", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004716", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004716")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004717")
    void case_UTAPI_004717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004717",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004717", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004717", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004717")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004718")
    void case_UTAPI_004718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004718",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "findByConnectionIdAndTableName",
                "Optional<TableMemo>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004718", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004718", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004718")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::findByConnectionIdAndTableName::1::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for tableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordRepository#createCopyTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordRepositoryCreateCopyTableScenario {

    @Test
    @DisplayName("UTAPI-009028")
    void case_UTAPI_009028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009028",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009028", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009028", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009028", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009028", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009028", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009028", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009028", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009028", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009028", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009028", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009028", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009028", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009028")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009029")
    void case_UTAPI_009029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009029",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009029", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009029", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009029", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009029", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009029", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009029", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009029", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009029", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009029", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009029", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009029", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009029", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009029")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009030")
    void case_UTAPI_009030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009030",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009030", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009030", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009030", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009030", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009030", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009030", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009030", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009030", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009030", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009030", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009030", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009030", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009030")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009031")
    void case_UTAPI_009031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009031",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009031", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009031", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009031", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009031", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009031", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009031", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009031", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009031", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009031", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009031", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009031", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009031", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009031")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009032")
    void case_UTAPI_009032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009032",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009032", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009032", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009032", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009032", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009032", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009032", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009032", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009032", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009032", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009032", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009032", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009032", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009032")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009033")
    void case_UTAPI_009033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009033",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009033", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009033", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009033", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009033", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009033", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009033", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009033", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009033", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009033", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009033", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009033", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009033", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009033")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009034")
    void case_UTAPI_009034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009034",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009034", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009034", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009034", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009034", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009034", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009034", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009034", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009034", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009034", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009034", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009034", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009034", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009034")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009035")
    void case_UTAPI_009035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009035",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009035", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009035", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009035", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009035", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009035", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009035", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009035", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009035", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009035", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009035", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009035", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009035", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009035")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009036")
    void case_UTAPI_009036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009036",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009036", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009036", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009036", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009036", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009036", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009036", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009036", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009036", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009036", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009036", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009036", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009036", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009036")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009037")
    void case_UTAPI_009037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009037",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009037", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009037", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009037", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009037", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009037", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009037", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009037", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009037", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009037", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009037", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009037", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009037", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009037")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009038")
    void case_UTAPI_009038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009038",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009038", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009038", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009038", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009038", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009038", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009038", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009038", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009038", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009038", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009038", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009038", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009038", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009038")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009039")
    void case_UTAPI_009039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009039",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009039", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009039", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009039", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009039", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009039", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009039", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009039", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009039", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009039", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009039", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009039", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009039", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009039")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009040")
    void case_UTAPI_009040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009040",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009040", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009040", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009040", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009040", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009040", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009040", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009040", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009040", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009040", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009040", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009040", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009040", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009040")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009041")
    void case_UTAPI_009041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009041",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009041", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009041", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009041", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009041", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009041", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009041", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009041", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009041", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009041", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009041", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009041", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009041", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009041")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009042")
    void case_UTAPI_009042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009042",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009042", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009042", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009042", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009042", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009042", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009042", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009042", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009042", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009042", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009042", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009042", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009042", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009042")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009043")
    void case_UTAPI_009043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009043",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009043", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009043", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009043", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009043", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009043", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009043", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009043", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009043", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009043", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009043", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009043", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009043", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009043")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009044")
    void case_UTAPI_009044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009044",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009044", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009044", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009044", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009044", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009044", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009044", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009044", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009044", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009044", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009044", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009044", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009044", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009044")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009045")
    void case_UTAPI_009045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009045",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009045", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009045", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009045", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009045", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009045", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009045", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009045", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009045", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009045", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009045", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009045", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009045", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009045")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009046")
    void case_UTAPI_009046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009046",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009046", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009046", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009046", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009046", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009046", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009046", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009046", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009046", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009046", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009046", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009046", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009046", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009046")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009047")
    void case_UTAPI_009047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009047",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009047", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009047", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009047", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009047", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009047", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009047", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009047", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009047", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009047", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009047", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009047", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009047", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009047")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009048")
    void case_UTAPI_009048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009048",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009048", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009048", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009048", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009048", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009048", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009048", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009048", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009048", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009048", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009048", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009048", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009048", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009048")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009049")
    void case_UTAPI_009049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009049",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009049", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009049", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009049", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009049", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009049", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009049", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009049", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009049", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009049", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009049", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009049", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009049", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009049")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009050")
    void case_UTAPI_009050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009050",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009050", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009050", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009050", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009050", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009050", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009050", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009050", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009050", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009050", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009050", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009050", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009050", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009050")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009051")
    void case_UTAPI_009051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009051",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009051", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009051", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009051", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009051", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009051", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009051", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009051", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009051", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009051", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009051", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009051", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009051", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009051")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009052")
    void case_UTAPI_009052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009052",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009052", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009052", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009052", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009052", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009052", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009052", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009052", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009052", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009052", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009052", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009052", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009052", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009052")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009053")
    void case_UTAPI_009053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009053",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009053", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009053", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009053", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009053", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009053", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009053", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009053", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009053", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009053", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009053", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009053", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009053", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009053")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009054")
    void case_UTAPI_009054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009054",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009054", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009054", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009054", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009054", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009054", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009054", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009054", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009054", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009054", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009054", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009054", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009054", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009054")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009055")
    void case_UTAPI_009055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009055",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009055", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009055", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009055", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009055", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009055", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009055", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009055", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009055", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009055", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009055", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009055", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009055", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009055")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009056")
    void case_UTAPI_009056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009056",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009056", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009056", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009056", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009056", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009056", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009056", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009056", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009056", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009056", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009056", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009056", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009056", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009056")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009057")
    void case_UTAPI_009057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009057",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009057", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009057", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009057", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009057", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009057", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009057", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009057", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009057", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009057", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009057", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009057", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009057", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009057")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009058")
    void case_UTAPI_009058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009058",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009058", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009058", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009058", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009058", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009058", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009058", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009058", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009058", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009058", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009058", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009058", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009058", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009058")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009059")
    void case_UTAPI_009059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009059",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009059", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009059", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009059", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009059", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009059", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009059", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009059", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009059", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009059", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009059", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009059", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009059", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009059")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009060")
    void case_UTAPI_009060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009060",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009060", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009060", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009060", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009060", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009060", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009060", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009060", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009060", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009060", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009060", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009060", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009060", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009060")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009061")
    void case_UTAPI_009061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009061",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009061", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009061", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009061", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009061", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009061", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009061", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009061", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009061", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009061", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009061", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009061", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009061", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009061")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009062")
    void case_UTAPI_009062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009062",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009062", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009062", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009062", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009062", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009062", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009062", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009062", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009062", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009062", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009062", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009062", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009062", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009062")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009063")
    void case_UTAPI_009063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009063",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009063", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009063", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009063", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009063", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009063", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009063", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009063", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009063", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009063", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009063", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009063", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009063", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009063")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009064")
    void case_UTAPI_009064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009064",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009064", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009064", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009064", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009064", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009064", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009064", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009064", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009064", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009064", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009064", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009064", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009064", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009064")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009065")
    void case_UTAPI_009065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009065",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009065", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009065", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009065", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009065", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009065", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009065", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009065", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009065", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009065", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009065", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009065", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009065", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009065")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009066")
    void case_UTAPI_009066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009066",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009066", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009066", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009066", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009066", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009066", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009066", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009066", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009066", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009066", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009066", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009066", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009066", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009066")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009067")
    void case_UTAPI_009067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009067",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009067", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009067", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009067", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009067", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009067", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009067", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009067", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009067", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009067", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009067", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009067", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009067", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009067")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009068")
    void case_UTAPI_009068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009068",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009068", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009068", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009068", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009068", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009068", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009068", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009068", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009068", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009068", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009068", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009068", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009068", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009068")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009069")
    void case_UTAPI_009069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009069",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009069", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009069", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009069", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009069", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009069", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009069", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009069", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009069")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009070")
    void case_UTAPI_009070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009070",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009070", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009070", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009070", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009070", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009070", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009070", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009070", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009070")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009071")
    void case_UTAPI_009071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009071",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009071", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009071", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009071", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009071", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009071", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009071", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009071", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009071")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009072")
    void case_UTAPI_009072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009072",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009072", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009072", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009072", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009072", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009072", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009072", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009072", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009072")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009073")
    void case_UTAPI_009073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009073",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009073", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009073", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009073", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009073", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009073", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009073", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009073", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009073")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009074")
    void case_UTAPI_009074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009074",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009074", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009074", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009074", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009074", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009074", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009074", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009074", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009074")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009075")
    void case_UTAPI_009075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009075",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009075", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009075", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009075", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009075", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009075", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009075", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009075", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009075")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009076")
    void case_UTAPI_009076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009076",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009076", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009076", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009076", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009076", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009076", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009076", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009076", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009076")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009077")
    void case_UTAPI_009077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009077",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009077", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009077", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009077", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009077", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009077", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009077", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009077")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009078")
    void case_UTAPI_009078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009078",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009078", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009078", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009078", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009078", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009078", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009078", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009078")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009079")
    void case_UTAPI_009079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009079",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009079", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009079", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009079", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009079", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009079", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009079", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009079")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009080")
    void case_UTAPI_009080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009080",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009080", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009080", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009080", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009080", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009080", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009080")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009081")
    void case_UTAPI_009081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009081",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009081", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009081", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009081", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009081", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009081", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009081")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009082")
    void case_UTAPI_009082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009082",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009082", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009082", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009082", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009082", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009082", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009082")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009083")
    void case_UTAPI_009083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009083",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009083", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009083", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009083", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009083", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009083", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009083")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009084")
    void case_UTAPI_009084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009084",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009084", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009084", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009084", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009084", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009084", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009084")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009085")
    void case_UTAPI_009085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009085",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009085", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009085", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009085", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009085", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009085", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009085", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009085")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009086")
    void case_UTAPI_009086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009086",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009086", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009086", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009086", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009086", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009086", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009086", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009086")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009087")
    void case_UTAPI_009087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009087",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009087", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009087", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009087", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009087", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009087", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009087", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009087")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009088")
    void case_UTAPI_009088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009088",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009088", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009088", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009088", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009088", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009088", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009088", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009088")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009089")
    void case_UTAPI_009089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009089",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009089", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009089", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009089", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009089", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009089", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009089", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009089")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009090")
    void case_UTAPI_009090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009090",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009090", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009090", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009090", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009090", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009090", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009090", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009090")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009091")
    void case_UTAPI_009091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009091",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009091", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009091", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009091", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009091", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009091", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009091", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009091")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009092")
    void case_UTAPI_009092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009092",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009092", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009092", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009092", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009092", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009092", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009092", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009092")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009093")
    void case_UTAPI_009093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009093",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009093", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009093", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009093", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009093", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009093", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009093", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009093")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009094")
    void case_UTAPI_009094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009094",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009094", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009094", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009094", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009094", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009094", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009094", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009094")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009095")
    void case_UTAPI_009095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009095",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009095", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009095", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009095", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009095", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009095", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009095", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009095")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009096")
    void case_UTAPI_009096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009096",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009096", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009096", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009096", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009096", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009096", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009096", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009096")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009097")
    void case_UTAPI_009097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009097",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009097", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009097", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009097", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009097", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009097", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009097", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009097")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009098")
    void case_UTAPI_009098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009098",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009098", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009098", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009098", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009098", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009098", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009098")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009099")
    void case_UTAPI_009099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009099",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009099", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009099", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009099", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009099", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009099", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009099")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009100")
    void case_UTAPI_009100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009100",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009100", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009100", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009100", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009100", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009100", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009100")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009101")
    void case_UTAPI_009101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009101",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009101", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009101", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009101", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009101", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009101", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009101")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009102")
    void case_UTAPI_009102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009102",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009102", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009102", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009102", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009102", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009102", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009102")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009103")
    void case_UTAPI_009103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009103",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009103", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009103", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009103", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009103", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009103", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009103")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009104")
    void case_UTAPI_009104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009104",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009104", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009104", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009104", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009104", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009104")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009105")
    void case_UTAPI_009105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009105",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009105", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009105", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009105", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009105", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009105")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009106")
    void case_UTAPI_009106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009106",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009106", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009106", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009106", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009106", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009106")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009107")
    void case_UTAPI_009107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009107",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009107", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009107", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009107", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009107", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009107")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009108")
    void case_UTAPI_009108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009108",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009108", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009108", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009108", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009108", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009108")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009109")
    void case_UTAPI_009109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009109",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009109", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009109", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009109", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009109", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009109")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009110")
    void case_UTAPI_009110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009110",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009110", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009110", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009110", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009110", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009110")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009111")
    void case_UTAPI_009111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009111",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009111", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009111", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009111", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009111", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009111")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009112")
    void case_UTAPI_009112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009112",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009112", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009112", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009112", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009112", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009112", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009112", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009112", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009112")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009113")
    void case_UTAPI_009113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009113",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009113", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009113", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009113", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009113", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009113", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009113", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009113", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009113")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009114")
    void case_UTAPI_009114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009114",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009114", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009114", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009114", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009114", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009114", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009114", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009114", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009114")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009115")
    void case_UTAPI_009115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009115",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009115", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009115", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009115", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009115", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009115", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009115", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009115", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009115")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009116")
    void case_UTAPI_009116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009116",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009116", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009116", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009116", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009116", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009116", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009116", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009116", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009116")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009117")
    void case_UTAPI_009117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009117",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009117", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009117", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009117", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009117", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009117", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009117", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009117", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009117")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009118")
    void case_UTAPI_009118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009118",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009118", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009118", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009118", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009118", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009118", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009118", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009118", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009118")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009119")
    void case_UTAPI_009119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009119",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009119", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009119", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009119", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009119", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009119", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009119", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009119", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009119")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009120")
    void case_UTAPI_009120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009120",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009120", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009120", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009120", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009120", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009120", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009120", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009120", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009120")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009121")
    void case_UTAPI_009121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009121",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009121", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009121", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009121", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009121", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009121", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009121", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009121", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009121")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009122")
    void case_UTAPI_009122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009122",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009122", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009122", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009122", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009122", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009122", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009122", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009122", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009122", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009122")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009123")
    void case_UTAPI_009123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009123",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009123", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009123", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009123", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009123", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009123", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009123", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009123", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009123", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009123")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009124")
    void case_UTAPI_009124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009124",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009124", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009124", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009124", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009124", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009124", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009124", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009124", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009124", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009124")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009125")
    void case_UTAPI_009125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009125",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009125", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009125", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009125", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009125", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009125", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009125", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009125", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009125", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009125")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009126")
    void case_UTAPI_009126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009126",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009126", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009126", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009126", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009126", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009126", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009126", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009126", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009126", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009126")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009127")
    void case_UTAPI_009127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009127",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009127", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009127", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009127", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009127", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009127")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009128")
    void case_UTAPI_009128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009128",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009128", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009128", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009128", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009128", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009128")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009129")
    void case_UTAPI_009129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009129",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009129", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009129", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009129", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009129", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009129")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009130")
    void case_UTAPI_009130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009130",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009130", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009130", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009130", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009130", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009130")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009131")
    void case_UTAPI_009131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009131",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009131", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009131", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009131", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009131", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009131")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009132")
    void case_UTAPI_009132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009132",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009132", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009132", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009132", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009132", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009132")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009133")
    void case_UTAPI_009133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009133",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009133", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009133", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009133", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009133")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009134")
    void case_UTAPI_009134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009134",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009134", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009134", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009134", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009134")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009135")
    void case_UTAPI_009135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009135",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009135", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009135", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009135", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009135", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009135")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009136")
    void case_UTAPI_009136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009136",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009136", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009136", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009136", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009136")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009137")
    void case_UTAPI_009137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009137",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009137", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009137", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009137", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009137")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009138")
    void case_UTAPI_009138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009138",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009138", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009138", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009138", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009138")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009139")
    void case_UTAPI_009139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009139",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009139", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009139", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009139", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009139", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009139")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009140")
    void case_UTAPI_009140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009140",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009140", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009140", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009140", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009140", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009140")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009141")
    void case_UTAPI_009141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009141",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009141", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009141", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009141", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009141", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009141")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009142")
    void case_UTAPI_009142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009142",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009142", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009142", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009142", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009142", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009142")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009143")
    void case_UTAPI_009143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009143",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009143", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009143", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009143", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009143", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009143")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009144")
    void case_UTAPI_009144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009144",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009144", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009144", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009144", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009144", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009144")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009145")
    void case_UTAPI_009145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009145",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009145", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009145", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009145", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009145", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009145")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009146")
    void case_UTAPI_009146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009146",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009146", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009146", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009146", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009146", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009146")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009147")
    void case_UTAPI_009147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009147",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009147", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009147", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009147", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009147", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009147")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009148")
    void case_UTAPI_009148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009148",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009148", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009148", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009148", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009148", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009148")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009149")
    void case_UTAPI_009149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009149",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009149", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009149", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009149", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009149", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009149")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009150")
    void case_UTAPI_009150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009150",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009150", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009150", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009150", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009150", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009150")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009151")
    void case_UTAPI_009151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009151",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009151", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009151", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009151", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009151", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009151")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009152")
    void case_UTAPI_009152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009152",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009152", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009152", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009152", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009152", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009152")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009153")
    void case_UTAPI_009153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009153",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009153", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009153", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009153", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009153")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009154")
    void case_UTAPI_009154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009154",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009154", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009154", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009154", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009154")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009155")
    void case_UTAPI_009155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009155",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009155", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009155", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009155")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009156")
    void case_UTAPI_009156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009156",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009156", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009156", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009156", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009156", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009156")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009157")
    void case_UTAPI_009157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009157",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009157", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009157", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009157", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009157", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009157")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009158")
    void case_UTAPI_009158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009158",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009158", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009158", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009158", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009158", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009158")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009159")
    void case_UTAPI_009159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009159",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009159", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009159", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009159", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009159", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009159", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009159")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009160")
    void case_UTAPI_009160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009160",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009160", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009160", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009160", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009160", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009160", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009160")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009161")
    void case_UTAPI_009161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009161",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009161", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009161", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009161", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009161", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009161", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009161")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009162")
    void case_UTAPI_009162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009162",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009162", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009162", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009162", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009162", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009162", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009162")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009163")
    void case_UTAPI_009163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009163",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009163", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009163", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009163", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009163", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009163", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009163")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009164")
    void case_UTAPI_009164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009164",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009164", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009164", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009164", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009164", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009164", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009164")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009165")
    void case_UTAPI_009165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009165",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009165", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009165", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009165", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009165", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009165", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009165")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009166")
    void case_UTAPI_009166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009166",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009166", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009166", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009166", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009166", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009166", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009166")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009167")
    void case_UTAPI_009167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009167",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009167", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009167", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009167", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009167", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009167", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009167")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009168")
    void case_UTAPI_009168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009168",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009168", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009168", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009168", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009168", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009168")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009169")
    void case_UTAPI_009169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009169",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009169", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009169", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009169", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009169")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009170")
    void case_UTAPI_009170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009170",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009170", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009170", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009170", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009170", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009170")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009171")
    void case_UTAPI_009171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009171",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009171", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009171", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009171", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009171", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009171")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009172")
    void case_UTAPI_009172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009172",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009172", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009172", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009172", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009172", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009172")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009173")
    void case_UTAPI_009173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009173",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009173", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009173", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009173", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009173", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009173")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009174")
    void case_UTAPI_009174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009174",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009174", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009174", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009174", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009174")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009175")
    void case_UTAPI_009175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009175",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009175", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009175", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009175", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009175")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009176")
    void case_UTAPI_009176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009176",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009176", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009176", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009176", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009176", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009176")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009177")
    void case_UTAPI_009177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009177",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009177", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009177", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009177", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009177", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009177")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009178")
    void case_UTAPI_009178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009178",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009178", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009178", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009178", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009178", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009178")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009179")
    void case_UTAPI_009179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009179",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009179", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009179", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009179", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009179", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009179")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009180")
    void case_UTAPI_009180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009180",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009180", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009180", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009180", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009180", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009180")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009181")
    void case_UTAPI_009181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009181",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009181", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009181", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009181", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009181", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009181")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009182")
    void case_UTAPI_009182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009182",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009182", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009182", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009182", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009182", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009182")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009183")
    void case_UTAPI_009183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009183",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009183", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009183", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009183", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009183", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009183")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009184")
    void case_UTAPI_009184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009184",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009184", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009184", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009184", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009184", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009184")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009185")
    void case_UTAPI_009185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009185",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009185", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009185", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009185", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009185", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009185")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009186")
    void case_UTAPI_009186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009186",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009186", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009186", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009186", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009186", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009186")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009187")
    void case_UTAPI_009187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009187",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009187", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009187", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009187", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009187", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009187", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009187", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009187")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009188")
    void case_UTAPI_009188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009188",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009188", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009188", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009188", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009188", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009188", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009188", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009188")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009189")
    void case_UTAPI_009189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009189",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009189", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009189", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009189", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009189", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009189", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009189", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009189")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009190")
    void case_UTAPI_009190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009190",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009190", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009190", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009190", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009190", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009190", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009190")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009191")
    void case_UTAPI_009191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009191",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009191", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009191", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009191", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009191", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009191")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009192")
    void case_UTAPI_009192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009192",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009192", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009192", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009192", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009192", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009192")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009193")
    void case_UTAPI_009193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009193",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009193", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009193", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009193", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009193", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009193")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009194")
    void case_UTAPI_009194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009194",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009194", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009194", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009194", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009194", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009194", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009194")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009195")
    void case_UTAPI_009195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009195",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009195", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009195", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009195", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009195", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009195", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009195")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009196")
    void case_UTAPI_009196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009196",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009196", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009196", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009196", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009196", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009196", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009196")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009197")
    void case_UTAPI_009197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009197",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009197", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009197", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009197", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009197", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009197")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009198")
    void case_UTAPI_009198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009198",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009198", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009198", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009198", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009198", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009198", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009198", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009198")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009199")
    void case_UTAPI_009199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009199",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009199", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009199", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009199", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009199", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009199", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009199", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009199")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009200")
    void case_UTAPI_009200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009200",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009200", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009200", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009200", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009200", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009200", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009200", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009200")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009201")
    void case_UTAPI_009201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009201",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009201", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009201", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009201", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009201", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009201", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009201", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009201")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009202")
    void case_UTAPI_009202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009202",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009202", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009202", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009202", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009202", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009202", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009202")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009203")
    void case_UTAPI_009203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009203",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009203", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009203", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009203", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009203", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009203", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009203")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009204")
    void case_UTAPI_009204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009204",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009204", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009204", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009204", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009204", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009204", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009204")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009205")
    void case_UTAPI_009205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009205",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009205", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009205", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009205", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009205", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009205", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009205")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009206")
    void case_UTAPI_009206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009206",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009206", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009206", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009206", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009206", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009206", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009206", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009206")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009207")
    void case_UTAPI_009207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009207",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009207", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009207", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009207", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009207", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009207", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009207", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009207")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009208")
    void case_UTAPI_009208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009208",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009208", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009208", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009208", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009208", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009208", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009208", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009208")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009209")
    void case_UTAPI_009209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009209",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009209", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009209", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009209", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009209", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009209", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009209", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009209")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009210")
    void case_UTAPI_009210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009210",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "createCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009210", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009210", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009210", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009210", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009210", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009210", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009210")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::createCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionUseCase#getAll.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionUseCaseGetAllScenario {

    @Test
    @DisplayName("UTAPI-011838")
    void case_UTAPI_011838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011838",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "getAll",
                "List<ConnectionSetting>",
                new ParamSpec[] {},
                new DataRef[] {},
                OraclePlan.builder("UTAPI-011838")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::getAll::1::METHOD::-1::-::-")
                    .mirror("-", "-", "-")
                    .target("-", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findAll")
                    .expected("the value generated for - is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findAll", "connectionSettingRepository", "findAll")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from connectionSettingRepository.findAll", "connectionSettingRepository", "findAll")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

}

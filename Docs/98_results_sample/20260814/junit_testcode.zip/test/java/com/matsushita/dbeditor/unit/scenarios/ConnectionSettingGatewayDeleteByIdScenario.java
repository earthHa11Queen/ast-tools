package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingGateway#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingGatewayDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-001847")
    void case_UTAPI_001847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001847",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001847", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001847")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001848")
    void case_UTAPI_001848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001848",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001848", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001848")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001849")
    void case_UTAPI_001849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001849",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001849", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001849")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001850")
    void case_UTAPI_001850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001850",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001850", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001850")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001851")
    void case_UTAPI_001851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001851",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001851", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001851")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001852")
    void case_UTAPI_001852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001852",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001852", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001852")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001853")
    void case_UTAPI_001853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001853",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001853", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001853")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001854")
    void case_UTAPI_001854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001854",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001854", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001854")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001855")
    void case_UTAPI_001855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001855",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001855", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001855")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001856")
    void case_UTAPI_001856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001856",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001856", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001856")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-001857")
    void case_UTAPI_001857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001857",
                "com.matsushita.dbeditor.adapter.gateway.ConnectionSettingGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001857", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001857")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ConnectionSettingGateway.java::ConnectionSettingGateway::deleteById::5::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingGatewayWrapper());
    }

}

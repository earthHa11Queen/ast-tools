package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictRepository#hasConflict.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictRepositoryHasConflictScenario {

    @Test
    @DisplayName("UTAPI-007832")
    void case_UTAPI_007832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007832",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007832", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007832", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007832", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007832", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007832", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007832", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007832", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007832", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007832", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007832", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007832", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007832", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007832")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007833")
    void case_UTAPI_007833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007833",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007833", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007833", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007833", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007833", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007833", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007833", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007833", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007833", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007833", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007833", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007833", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007833", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007833")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007834")
    void case_UTAPI_007834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007834",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007834", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007834", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007834", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007834", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007834", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007834", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007834", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007834", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007834", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007834", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007834", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007834", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007834")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007835")
    void case_UTAPI_007835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007835",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007835", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007835", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007835", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007835", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007835", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007835", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007835", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007835", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007835", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007835", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007835", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007835", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007835")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007836")
    void case_UTAPI_007836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007836",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007836", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007836", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007836", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007836", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007836", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007836", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007836", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007836", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007836", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007836", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007836", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007836", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007836")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007837")
    void case_UTAPI_007837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007837",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007837", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007837", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007837", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007837", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007837", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007837", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007837", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007837", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007837", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007837", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007837", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007837", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007837")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007838")
    void case_UTAPI_007838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007838",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007838", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007838", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007838", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007838", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007838", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007838", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007838", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007838", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007838", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007838", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007838", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007838", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007838")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007839")
    void case_UTAPI_007839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007839",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007839", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007839", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007839", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007839", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007839", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007839", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007839", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007839", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007839", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007839", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007839", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007839", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007839")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007840")
    void case_UTAPI_007840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007840",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007840", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007840", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007840", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007840", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007840", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007840", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007840", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007840", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007840", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007840", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007840", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007840", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007840")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007841")
    void case_UTAPI_007841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007841",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007841", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007841", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007841", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007841", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007841", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007841", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007841", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007841", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007841", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007841", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007841", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007841", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007841")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007842")
    void case_UTAPI_007842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007842",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007842", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007842", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007842", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007842", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007842", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007842", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007842", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007842", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007842", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007842", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007842", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007842", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007842")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007843")
    void case_UTAPI_007843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007843",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007843", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007843", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007843", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007843", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007843", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007843", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007843", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007843", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007843", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007843", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007843", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007843", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007843")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007844")
    void case_UTAPI_007844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007844",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007844", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007844", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007844", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007844", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007844", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007844", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007844", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007844", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007844", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007844", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007844", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007844", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007844")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007845")
    void case_UTAPI_007845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007845",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007845", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007845", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007845", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007845", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007845", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007845", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007845", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007845", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007845", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007845", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007845", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007845", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007845")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007846")
    void case_UTAPI_007846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007846",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007846", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007846", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007846", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007846", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007846", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007846", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007846", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007846", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007846", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007846", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007846", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007846", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007846")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007847")
    void case_UTAPI_007847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007847",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007847", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007847", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007847", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007847", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007847", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007847", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007847", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007847", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007847", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007847", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007847", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007847", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007847")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007848")
    void case_UTAPI_007848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007848",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007848", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007848", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007848", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007848", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007848", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007848", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007848", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007848", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007848", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007848", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007848", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007848", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007848")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007849")
    void case_UTAPI_007849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007849",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007849", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007849", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007849", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007849", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007849", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007849", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007849", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007849", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007849", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007849", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007849", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007849", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007849")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007850")
    void case_UTAPI_007850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007850",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007850", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007850", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007850", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007850", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007850", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007850", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007850", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007850", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007850", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007850", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007850", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007850", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007850")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007851")
    void case_UTAPI_007851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007851",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007851", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007851", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007851", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007851", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007851", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007851", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007851", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007851", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007851", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007851", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007851", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007851", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007851")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007852")
    void case_UTAPI_007852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007852",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007852", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007852", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007852", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007852", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007852", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007852", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007852", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007852", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007852", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007852", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007852", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007852", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007852")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007853")
    void case_UTAPI_007853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007853",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007853", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007853", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007853", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007853", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007853", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007853", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007853", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007853", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007853", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007853", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007853", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007853", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007853")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007854")
    void case_UTAPI_007854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007854",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007854", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007854", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007854", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007854", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007854", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007854", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007854", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007854", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007854", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007854", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007854", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007854", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007854")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007855")
    void case_UTAPI_007855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007855",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007855", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007855", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007855", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007855", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007855", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007855", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007855", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007855", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007855", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007855", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007855", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007855", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007855")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007856")
    void case_UTAPI_007856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007856",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007856", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007856", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007856", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007856", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007856", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007856", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007856", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007856", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007856", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007856", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007856", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007856", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007856")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007857")
    void case_UTAPI_007857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007857",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007857", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007857", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007857", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007857", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007857", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007857", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007857", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007857", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007857", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007857", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007857", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007857", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007857")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007858")
    void case_UTAPI_007858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007858",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007858", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007858", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007858", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007858", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007858", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007858", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007858", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007858", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007858", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007858", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007858", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007858", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007858")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007859")
    void case_UTAPI_007859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007859",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007859", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007859", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007859", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007859", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007859", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007859", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007859", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007859", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007859", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007859", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007859", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007859", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007859")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007860")
    void case_UTAPI_007860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007860",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007860", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007860", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007860", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007860", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007860", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007860", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007860", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007860", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007860", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007860", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007860", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007860", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007860")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007861")
    void case_UTAPI_007861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007861",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007861", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007861", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007861", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007861", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007861", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007861", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007861", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007861", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007861", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007861", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007861", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007861", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007861")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007862")
    void case_UTAPI_007862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007862",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007862", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007862", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007862", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007862", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007862", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007862", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007862", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007862", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007862", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007862", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007862", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007862", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007862")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007863")
    void case_UTAPI_007863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007863",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007863", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007863", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007863", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007863", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007863", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007863", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007863", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007863", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007863", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007863", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007863", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007863", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007863")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007864")
    void case_UTAPI_007864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007864",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007864", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007864", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007864", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007864", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007864", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007864", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007864", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007864", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007864", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007864", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007864", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007864", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007864")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007865")
    void case_UTAPI_007865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007865",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007865", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007865", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007865", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007865", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007865", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007865", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007865", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007865", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007865", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007865", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007865", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007865", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007865")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007866")
    void case_UTAPI_007866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007866",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007866", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007866", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007866", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007866", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007866", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007866", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007866", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007866", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007866", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007866", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007866", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007866", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007866")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007867")
    void case_UTAPI_007867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007867",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007867", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007867", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007867", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007867", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007867", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007867", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007867", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007867", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007867", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007867", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007867", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007867", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007867")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007868")
    void case_UTAPI_007868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007868",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007868", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007868", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007868", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007868", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007868", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007868", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007868", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007868", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007868", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007868", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007868", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007868", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007868")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007869")
    void case_UTAPI_007869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007869",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007869", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007869", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007869", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007869", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007869", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007869", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007869", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007869", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007869", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007869", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007869", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007869", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007869")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007870")
    void case_UTAPI_007870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007870",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007870", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007870", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007870", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007870", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007870", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007870", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007870", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007870", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007870", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007870", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007870", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007870", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007870")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007871")
    void case_UTAPI_007871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007871",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007871", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007871", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007871", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007871", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007871", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007871", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007871", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007871", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007871", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007871", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007871", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007871", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007871")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007872")
    void case_UTAPI_007872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007872",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007872", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007872", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007872", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007872", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007872", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007872", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007872", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007872", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007872", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007872", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007872", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007872", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007872")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007873")
    void case_UTAPI_007873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007873",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007873", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007873", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007873", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007873", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007873", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007873", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007873", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007873", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007873", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007873", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007873", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007873", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007873")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007874")
    void case_UTAPI_007874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007874",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007874", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007874", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007874", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007874", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007874", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007874", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007874", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007874", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007874", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007874", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007874", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007874", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007874")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007875")
    void case_UTAPI_007875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007875",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007875", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007875", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007875", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007875", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007875", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007875", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007875", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007875", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007875", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007875", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007875", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007875", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007875")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007876")
    void case_UTAPI_007876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007876",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007876", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007876", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007876", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007876", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007876", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007876", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007876", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007876", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007876", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007876", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007876", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007876", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007876")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007877")
    void case_UTAPI_007877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007877",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007877", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007877", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007877", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007877", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007877", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007877", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007877", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007877", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007877", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007877", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007877", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007877", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007877")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007878")
    void case_UTAPI_007878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007878",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007878", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007878", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007878", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007878", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007878", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007878", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007878", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007878", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007878", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007878", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007878", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007878", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007878")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007879")
    void case_UTAPI_007879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007879",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007879", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007879", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007879", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007879", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007879", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007879", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007879", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007879", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007879", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007879", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007879", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007879", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007879")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007880")
    void case_UTAPI_007880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007880",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007880", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007880", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007880", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007880", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007880", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007880", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007880", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007880", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007880", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007880", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007880", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007880", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007880")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007881")
    void case_UTAPI_007881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007881",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007881", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007881", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007881", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007881", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007881", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007881", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007881", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007881", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007881", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007881", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007881", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007881", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007881")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007882")
    void case_UTAPI_007882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007882",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007882", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007882", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007882", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007882", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007882", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007882", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007882", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007882")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007883")
    void case_UTAPI_007883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007883",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007883", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007883", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007883", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007883", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007883", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007883", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007883", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007883")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007884")
    void case_UTAPI_007884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007884",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007884", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007884", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007884", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007884", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007884", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007884", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007884", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007884")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007885")
    void case_UTAPI_007885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007885",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007885", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007885", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007885", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007885", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007885", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007885", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007885", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007885")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007886")
    void case_UTAPI_007886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007886",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007886", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007886", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007886", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007886", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007886", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007886", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007886", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007886")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007887")
    void case_UTAPI_007887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007887",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007887", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007887", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007887", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007887", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007887", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007887")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007888")
    void case_UTAPI_007888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007888",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007888", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007888", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007888", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007888", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007888", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007888")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007889")
    void case_UTAPI_007889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007889",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007889", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007889", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007889", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007889", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007889", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007889")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007890")
    void case_UTAPI_007890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007890",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007890", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007890", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007890", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007890", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007890", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007890")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007891")
    void case_UTAPI_007891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007891",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007891", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007891", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007891", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007891", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007891", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007891")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007892")
    void case_UTAPI_007892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007892",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007892", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007892", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007892", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007892", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007892", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007892")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007893")
    void case_UTAPI_007893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007893",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007893", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007893", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007893", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007893", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007893", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007893")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007894")
    void case_UTAPI_007894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007894",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007894", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007894", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007894", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007894", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007894", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007894")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007895")
    void case_UTAPI_007895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007895",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007895", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007895", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007895", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007895", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007895", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007895")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007896")
    void case_UTAPI_007896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007896",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007896", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007896", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007896", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007896", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007896", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007896")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007897")
    void case_UTAPI_007897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007897",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007897", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007897", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007897", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007897", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007897", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007897")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007898")
    void case_UTAPI_007898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007898",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007898", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007898", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007898", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007898", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007898", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007898")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007899")
    void case_UTAPI_007899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007899",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007899", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007899", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007899", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007899", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007899", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007899")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007900")
    void case_UTAPI_007900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007900",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007900", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007900", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007900", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007900", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007900", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007900")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007901")
    void case_UTAPI_007901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007901",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007901", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007901", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007901", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007901", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007901", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007901")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007902")
    void case_UTAPI_007902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007902",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007902", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007902", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007902", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007902", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007902", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007902")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007903")
    void case_UTAPI_007903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007903",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007903", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007903", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007903", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007903", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007903", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007903")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007904")
    void case_UTAPI_007904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007904",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007904", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007904", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007904", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007904", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007904", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007904")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007905")
    void case_UTAPI_007905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007905",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007905", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007905", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007905", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007905", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007905", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007905")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007906")
    void case_UTAPI_007906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007906",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007906", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007906", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007906", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007906", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007906", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007906")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007907")
    void case_UTAPI_007907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007907",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007907", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007907", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007907", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007907", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007907", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007907")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007908")
    void case_UTAPI_007908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007908",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007908", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007908", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007908", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007908", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007908", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007908")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007909")
    void case_UTAPI_007909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007909",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007909", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007909", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007909", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007909", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007909", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007909")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007910")
    void case_UTAPI_007910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007910",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007910", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007910", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007910", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007910", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007910", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007910")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007911")
    void case_UTAPI_007911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007911",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007911", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007911", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007911", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007911", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007911", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007911")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007912")
    void case_UTAPI_007912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007912",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007912", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007912", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007912", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007912", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007912", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007912")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007913")
    void case_UTAPI_007913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007913",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007913", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007913", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007913", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007913", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007913", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007913")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007914")
    void case_UTAPI_007914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007914",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007914", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007914", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007914", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007914", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007914", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007914")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007915")
    void case_UTAPI_007915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007915",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007915", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007915", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007915", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007915", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007915", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007915")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007916")
    void case_UTAPI_007916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007916",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007916", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007916", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007916", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007916", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007916", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007916")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007917")
    void case_UTAPI_007917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007917",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007917", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007917", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007917", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007917", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007917", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007917")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007918")
    void case_UTAPI_007918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007918",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007918", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007918", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007918", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007918", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007918", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007918")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007919")
    void case_UTAPI_007919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007919",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007919", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007919", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007919", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007919", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007919", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007919")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007920")
    void case_UTAPI_007920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007920",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007920", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007920", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007920", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007920", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007920", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007920")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007921")
    void case_UTAPI_007921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007921",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007921", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007921", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007921", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007921", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007921", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007921")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007922")
    void case_UTAPI_007922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007922",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007922", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007922", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007922", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007922", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007922")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007923")
    void case_UTAPI_007923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007923",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007923", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007923", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007923", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007923", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007923")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007924")
    void case_UTAPI_007924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007924",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007924", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007924", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007924", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007924", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007924")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007925")
    void case_UTAPI_007925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007925",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007925", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007925", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007925", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007925", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007925")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007926")
    void case_UTAPI_007926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007926",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007926", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007926", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007926", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007926", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007926")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007927")
    void case_UTAPI_007927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007927",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007927", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007927", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007927", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007927", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007927")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007928")
    void case_UTAPI_007928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007928",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007928", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007928", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007928", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007928", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007928")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007929")
    void case_UTAPI_007929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007929",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007929", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007929", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007929", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007929", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007929")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007930")
    void case_UTAPI_007930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007930",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007930", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007930", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007930", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007930", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007930", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007930")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007931")
    void case_UTAPI_007931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007931",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007931", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007931", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007931", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007931", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007931")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007932")
    void case_UTAPI_007932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007932",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007932", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007932", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007932", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007932", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007932")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007933")
    void case_UTAPI_007933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007933",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007933", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007933", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007933", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007933", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007933")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007934")
    void case_UTAPI_007934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007934",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007934", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007934", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007934", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007934", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007934")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007935")
    void case_UTAPI_007935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007935",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007935", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007935", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007935", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007935", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007935")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007936")
    void case_UTAPI_007936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007936",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007936", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007936", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007936", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007936", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007936")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007937")
    void case_UTAPI_007937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007937",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007937", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007937", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007937", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007937", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007937")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007938")
    void case_UTAPI_007938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007938",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007938", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007938", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007938", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007938", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007938")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007939")
    void case_UTAPI_007939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007939",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007939", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007939", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007939", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007939")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007940")
    void case_UTAPI_007940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007940",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007940", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007940", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007940", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007940")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007941")
    void case_UTAPI_007941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007941",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007941", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007941", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007941", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007941")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007942")
    void case_UTAPI_007942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007942",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007942", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007942", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007942", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007942")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007943")
    void case_UTAPI_007943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007943",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007943", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007943", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007943", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007943")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007944")
    void case_UTAPI_007944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007944",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007944", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007944", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007944", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007944")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007945")
    void case_UTAPI_007945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007945",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007945", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007945", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007945", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007945")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007946")
    void case_UTAPI_007946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007946",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007946", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007946", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007946", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007946")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007947")
    void case_UTAPI_007947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007947",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007947", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007947", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007947", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007947", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007947")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007948")
    void case_UTAPI_007948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007948",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007948", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007948", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007948", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007948", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007948")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007949")
    void case_UTAPI_007949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007949",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007949", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007949", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007949", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007949", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007949")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007950")
    void case_UTAPI_007950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007950",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007950", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007950", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007950", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007950", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007950")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007951")
    void case_UTAPI_007951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007951",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007951", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007951", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007951", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007951")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007952")
    void case_UTAPI_007952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007952",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007952", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007952", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007952", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007952")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007953")
    void case_UTAPI_007953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007953",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007953", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007953", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007953", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007953")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007954")
    void case_UTAPI_007954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007954",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007954", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007954", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007954", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007954")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007955")
    void case_UTAPI_007955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007955",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007955", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007955", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007955", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007955")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007956")
    void case_UTAPI_007956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007956",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007956", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007956", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007956", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007956")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007957")
    void case_UTAPI_007957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007957",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007957", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007957", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007957", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007957")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007958")
    void case_UTAPI_007958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007958",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007958", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007958", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007958", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007958")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007959")
    void case_UTAPI_007959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007959",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007959", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007959", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007959", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007959")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007960")
    void case_UTAPI_007960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007960",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007960", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007960", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007960", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007960")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007961")
    void case_UTAPI_007961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007961",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007961", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007961", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007961", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007961", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007961")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007962")
    void case_UTAPI_007962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007962",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007962", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007962", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007962", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007962", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007962")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007963")
    void case_UTAPI_007963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007963",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007963", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007963", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007963", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007963", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007963")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007964")
    void case_UTAPI_007964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007964",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007964", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007964", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007964", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007964", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007964")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007965")
    void case_UTAPI_007965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007965",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007965", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007965", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007965", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007965", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007965")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007966")
    void case_UTAPI_007966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007966",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007966", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007966", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007966", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007966", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007966")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007967")
    void case_UTAPI_007967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007967",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007967", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007967", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007967", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007967", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007967")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007968")
    void case_UTAPI_007968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007968",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007968", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007968", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007968", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007968", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007968", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007968")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007969")
    void case_UTAPI_007969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007969",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007969", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007969", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007969", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007969", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007969", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007969")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007970")
    void case_UTAPI_007970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007970",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007970", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007970", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007970", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007970", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007970")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007971")
    void case_UTAPI_007971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007971",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007971", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007971", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007971", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007971")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007972")
    void case_UTAPI_007972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007972",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007972", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007972", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007972")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007973")
    void case_UTAPI_007973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007973",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007973", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007973", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007973")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007974")
    void case_UTAPI_007974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007974",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007974", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007974", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007974")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007975")
    void case_UTAPI_007975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007975",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007975", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007975", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007975")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007976")
    void case_UTAPI_007976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007976",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007976", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007976", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007976")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007977")
    void case_UTAPI_007977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007977",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007977", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007977", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007977", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007977")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007978")
    void case_UTAPI_007978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007978",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007978", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007978", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007978", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007978")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007979")
    void case_UTAPI_007979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007979",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007979", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007979", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007979", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007979")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007980")
    void case_UTAPI_007980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007980",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007980", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007980", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007980", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007980")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007981")
    void case_UTAPI_007981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007981",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007981", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007981", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007981", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007981")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007982")
    void case_UTAPI_007982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007982",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007982", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007982", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007982", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007982")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007983")
    void case_UTAPI_007983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007983",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007983", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007983", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007983", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007983")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007984")
    void case_UTAPI_007984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007984",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007984", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007984", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007984", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007984")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007985")
    void case_UTAPI_007985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007985",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007985", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007985", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007985", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007985")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007986")
    void case_UTAPI_007986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007986",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007986", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007986", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007986", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007986")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007987")
    void case_UTAPI_007987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007987",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007987", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007987", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007987", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007987")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007988")
    void case_UTAPI_007988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007988",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007988", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007988", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007988", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007988", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007988")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007989")
    void case_UTAPI_007989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007989",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007989", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007989", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007989", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007989", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007989")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007990")
    void case_UTAPI_007990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007990",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007990", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007990", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007990", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007990", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007990")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007991")
    void case_UTAPI_007991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007991",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007991", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007991", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007991", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007991", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007991")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007992")
    void case_UTAPI_007992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007992",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007992", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007992", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007992", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007992")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007993")
    void case_UTAPI_007993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007993",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007993", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007993", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-007993", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007993")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007994")
    void case_UTAPI_007994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007994",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007994", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007994", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007994", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007994")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007995")
    void case_UTAPI_007995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007995",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007995", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007995", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007995")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007996")
    void case_UTAPI_007996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007996",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007996", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007996", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007996")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007997")
    void case_UTAPI_007997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007997",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007997", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007997", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007997")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007998")
    void case_UTAPI_007998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007998",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007998", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007998", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007998")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007999")
    void case_UTAPI_007999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007999",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007999", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007999", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007999", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007999")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008000")
    void case_UTAPI_008000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008000",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008000", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008000", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008000", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008000")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008001")
    void case_UTAPI_008001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008001",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008001", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008001", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008001", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008001")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008002")
    void case_UTAPI_008002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008002",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008002", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008002", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008002", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008002")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008003")
    void case_UTAPI_008003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008003",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008003", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008003", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008003", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008003")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008004")
    void case_UTAPI_008004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008004",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008004", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008004", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008004")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008005")
    void case_UTAPI_008005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008005",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008005", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008005", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008005", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008005", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008005", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008005", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008005", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008005")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008006")
    void case_UTAPI_008006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008006",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008006", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008006", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008006", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008006", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008006", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008006", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008006", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008006")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008007")
    void case_UTAPI_008007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008007",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008007", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008007", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008007", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008007", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008007", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008007", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008007", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008007")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008008")
    void case_UTAPI_008008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008008",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008008", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008008", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008008", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008008", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008008", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008008", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008008", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008008")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008009")
    void case_UTAPI_008009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008009",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008009", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008009", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008009", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008009", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008009", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008009")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008010")
    void case_UTAPI_008010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008010",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008010", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008010", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008010", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008010", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008010", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008010")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008011")
    void case_UTAPI_008011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008011",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008011", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008011", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008011", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008011", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008011", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008011", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008011", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008011", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008011", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008011", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008011", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008011", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008011")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008012")
    void case_UTAPI_008012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008012",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008012", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008012", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008012", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008012", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008012", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008012", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008012", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008012", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008012", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008012", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008012", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008012", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008012")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008013")
    void case_UTAPI_008013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008013",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008013", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008013", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008013", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008013", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008013", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008013", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008013", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008013", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008013", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008013", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008013", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008013", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008013")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008014")
    void case_UTAPI_008014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008014",
                "com.matsushita.dbeditor.domain.repository.TableConflictRepository",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008014", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008014", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008014", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008014", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008014", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008014", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008014", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008014", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008014", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008014", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008014", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008014", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-008014")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableConflictRepository.java::TableConflictRepository::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictRepositoryWrapper());
    }

}

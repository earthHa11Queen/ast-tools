package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConflictUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConflictUseCase#applyToReal.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConflictUseCaseApplyToRealScenario {

    @Test
    @DisplayName("UTAPI-011496")
    void case_UTAPI_011496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011496",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011496", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011496", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011496")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011497")
    void case_UTAPI_011497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011497",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011497", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011497")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011498")
    void case_UTAPI_011498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011498",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011498", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011498")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011499")
    void case_UTAPI_011499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011499",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011499", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011499")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011500")
    void case_UTAPI_011500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011500",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011500", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011500")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011501")
    void case_UTAPI_011501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011501",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011501", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011501")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011502")
    void case_UTAPI_011502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011502",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011502", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011502")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011503")
    void case_UTAPI_011503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011503",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011503", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011503")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011504")
    void case_UTAPI_011504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011504",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011504", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011504")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011505")
    void case_UTAPI_011505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011505",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011505", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011505")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011506")
    void case_UTAPI_011506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011506",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011506", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011506")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011507")
    void case_UTAPI_011507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011507",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011507", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011507", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011507")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011508")
    void case_UTAPI_011508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011508",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011508", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011508", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011508")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011509")
    void case_UTAPI_011509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011509",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011509", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011509", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011509")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011510")
    void case_UTAPI_011510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011510",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011510", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011510", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011510")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011511")
    void case_UTAPI_011511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011511",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011511", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011511", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011511")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011512")
    void case_UTAPI_011512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011512",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011512", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011512", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011512")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011513")
    void case_UTAPI_011513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011513",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011513", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011513", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011513")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011514")
    void case_UTAPI_011514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011514",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011514", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011514", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011514")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011515")
    void case_UTAPI_011515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011515",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011515", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011515", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011515")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011516")
    void case_UTAPI_011516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011516",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011516", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011516", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011516")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011517")
    void case_UTAPI_011517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011517",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011517", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011517", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011517")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011518")
    void case_UTAPI_011518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011518",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011518", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011518", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011518")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011519")
    void case_UTAPI_011519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011519",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011519", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011519", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011519")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011520")
    void case_UTAPI_011520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011520",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011520", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011520", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011520")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011521")
    void case_UTAPI_011521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011521",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011521", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011521", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011521")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011522")
    void case_UTAPI_011522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011522",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011522", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011522", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011522")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011523")
    void case_UTAPI_011523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011523",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011523", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011523", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011523")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011524")
    void case_UTAPI_011524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011524",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011524", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011524", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011524")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011525")
    void case_UTAPI_011525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011525",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011525", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011525", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011525")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011526")
    void case_UTAPI_011526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011526",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011526", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011526", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011526")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011527")
    void case_UTAPI_011527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011527",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011527", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011527", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011527")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011528")
    void case_UTAPI_011528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011528",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011528", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011528", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011528")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011529")
    void case_UTAPI_011529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011529",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011529", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011529", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011529")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011530")
    void case_UTAPI_011530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011530",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011530", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011530", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011530")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011531")
    void case_UTAPI_011531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011531",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011531", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011531", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011531")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011532")
    void case_UTAPI_011532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011532",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011532", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011532", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011532")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011533")
    void case_UTAPI_011533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011533",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011533", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011533", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011533")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011534")
    void case_UTAPI_011534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011534",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011534", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011534", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011534")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011535")
    void case_UTAPI_011535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011535",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011535", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011535", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011535", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011535")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011536")
    void case_UTAPI_011536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011536",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011536", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011536", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011536", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011536")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011537")
    void case_UTAPI_011537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011537",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011537", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011537", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011537", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011537")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011538")
    void case_UTAPI_011538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011538",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011538", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011538", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011538", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011538")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011539")
    void case_UTAPI_011539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011539",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011539", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011539", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011539", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011539")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011540")
    void case_UTAPI_011540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011540",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011540", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011540", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011540", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011540")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011541")
    void case_UTAPI_011541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011541",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011541", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011541", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011541", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011541")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011542")
    void case_UTAPI_011542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011542",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011542", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011542", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011542", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011542")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011543")
    void case_UTAPI_011543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011543",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011543", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011543", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011543", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011543")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011544")
    void case_UTAPI_011544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011544",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011544", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011544", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011544", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011544")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011545")
    void case_UTAPI_011545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011545",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011545", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011545", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011545", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011545")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011546")
    void case_UTAPI_011546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011546",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011546", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011546", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011546", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011546")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011547")
    void case_UTAPI_011547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011547",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011547", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011547", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011547", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011547")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011548")
    void case_UTAPI_011548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011548",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "applyToReal",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011548", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011548", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011548", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011548")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::applyToReal::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.applyToReal")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.applyToReal", "tableConflictRepository", "applyToReal")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.applyToReal must carry the value generated for schemaName", "tableConflictRepository", "applyToReal", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.applyToReal must carry the value generated for tableName", "tableConflictRepository", "applyToReal", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

}

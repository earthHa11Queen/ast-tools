package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryRepository#findHistoryRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryRepositoryFindHistoryRecordsScenario {

    @Test
    @DisplayName("UTAPI-008198")
    void case_UTAPI_008198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008198",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008198", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008198", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008198", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008198")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008199")
    void case_UTAPI_008199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008199",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008199", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008199", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008199", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008199")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008200")
    void case_UTAPI_008200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008200",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008200", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008200", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008200", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008200")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008201")
    void case_UTAPI_008201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008201",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008201", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008201", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008201", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008201")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008202")
    void case_UTAPI_008202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008202",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008202", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008202", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008202", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008202")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008203")
    void case_UTAPI_008203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008203",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008203", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008203", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008203", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008203")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008204")
    void case_UTAPI_008204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008204",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008204", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008204", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008204", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008204")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008205")
    void case_UTAPI_008205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008205",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008205", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008205", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008205", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008205", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008205")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008206")
    void case_UTAPI_008206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008206",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008206", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008206", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008206", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008206", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008206", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008206", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008206", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008206")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008207")
    void case_UTAPI_008207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008207",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008207", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008207", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008207", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008207", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008207", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008207", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008207", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008207")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008208")
    void case_UTAPI_008208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008208",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008208", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008208", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008208", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008208", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008208", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008208", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008208", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008208")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008209")
    void case_UTAPI_008209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008209",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008209", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008209", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008209", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008209", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008209", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008209", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008209", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008209")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008210")
    void case_UTAPI_008210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008210",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008210", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008210", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008210", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008210", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008210", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008210", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008210", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008210")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008211")
    void case_UTAPI_008211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008211",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008211", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008211", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008211", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008211", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008211", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008211", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008211", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008211")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008212")
    void case_UTAPI_008212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008212",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008212", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008212", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008212", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008212", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008212", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008212", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008212", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008212", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008212")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008213")
    void case_UTAPI_008213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008213",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008213", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008213", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008213", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008213", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008213", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008213", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008213", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008213", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008213")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008214")
    void case_UTAPI_008214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008214",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008214", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008214", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008214", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008214", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008214", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008214", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008214", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008214", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008214")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008215")
    void case_UTAPI_008215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008215",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008215", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008215", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008215", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008215", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008215", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008215", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008215", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008215", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008215")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008216")
    void case_UTAPI_008216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008216",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008216", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008216", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008216", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008216", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008216", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008216", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008216", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008216", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008216")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008217")
    void case_UTAPI_008217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008217",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008217", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008217", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008217", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008217", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008217", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008217", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008217", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008217")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008218")
    void case_UTAPI_008218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008218",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008218", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008218", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008218", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008218", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008218", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008218", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008218", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008218")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008219")
    void case_UTAPI_008219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008219",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008219", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008219", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008219", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008219", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008219", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008219", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008219")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008220")
    void case_UTAPI_008220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008220",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008220", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008220", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008220", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008220", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008220", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008220", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008220")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008221")
    void case_UTAPI_008221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008221",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008221", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008221", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008221", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008221", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008221", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008221", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008221")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008222")
    void case_UTAPI_008222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008222",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008222", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008222", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008222", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008222", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008222", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008222", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008222")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008223")
    void case_UTAPI_008223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008223",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008223", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008223", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008223", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008223", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008223", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008223", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008223")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008224")
    void case_UTAPI_008224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008224",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008224", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008224", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008224", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008224", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008224", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008224", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008224")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008225")
    void case_UTAPI_008225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008225",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008225", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008225", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008225", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008225", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008225", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008225", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008225")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008226")
    void case_UTAPI_008226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008226",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008226", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008226", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008226", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008226", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008226", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008226", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008226", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008226")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008227")
    void case_UTAPI_008227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008227",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008227", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008227", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008227", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008227", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008227", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008227", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008227", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008227", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008227")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008228")
    void case_UTAPI_008228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008228",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008228", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008228", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008228", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008228", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008228", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008228", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008228", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008228")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008229")
    void case_UTAPI_008229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008229",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008229", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008229", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008229", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008229", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008229", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008229", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008229", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008229")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008230")
    void case_UTAPI_008230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008230",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008230", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008230", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008230", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008230", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008230", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008230", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008230", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008230")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008231")
    void case_UTAPI_008231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008231",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008231", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008231", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008231", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008231", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008231", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008231", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008231", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008231")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008232")
    void case_UTAPI_008232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008232",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008232", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008232", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008232", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008232", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008232", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008232", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008232", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008232")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008233")
    void case_UTAPI_008233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008233",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008233", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008233", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008233", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008233", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008233", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008233", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008233", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008233")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008234")
    void case_UTAPI_008234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008234",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008234", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008234", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008234", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008234", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008234", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008234", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008234", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008234")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008235")
    void case_UTAPI_008235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008235",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008235", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008235", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008235", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008235", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008235", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008235", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008235", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008235")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008236")
    void case_UTAPI_008236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008236",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008236", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008236", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008236", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008236", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008236", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008236", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008236", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008236")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008237")
    void case_UTAPI_008237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008237",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008237", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008237", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008237", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008237", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008237", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008237", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008237", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008237")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008238")
    void case_UTAPI_008238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008238",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008238", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008238", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008238", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008238", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008238", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008238", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008238", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008238")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008239")
    void case_UTAPI_008239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008239",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008239", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008239", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008239", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008239", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008239", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008239", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008239", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008239")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008240")
    void case_UTAPI_008240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008240",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008240", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008240", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008240", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008240", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008240", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008240", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008240")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008241")
    void case_UTAPI_008241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008241",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008241", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008241", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008241", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008241", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008241", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008241")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008242")
    void case_UTAPI_008242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008242",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008242", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008242", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008242", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008242", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008242", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008242")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008243")
    void case_UTAPI_008243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008243",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008243", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008243", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008243", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008243", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008243", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008243")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008244")
    void case_UTAPI_008244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008244",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008244", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008244", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008244", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008244", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008244", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008244", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008244")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008245")
    void case_UTAPI_008245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008245",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008245", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008245", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008245", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008245", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008245", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008245", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008245", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008245", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008245", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008245", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008245", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008245", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008245")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008246")
    void case_UTAPI_008246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008246",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008246", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008246", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008246", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008246", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008246", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008246", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008246", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008246", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008246", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008246", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008246", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008246", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008246")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008247")
    void case_UTAPI_008247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008247",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008247", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008247", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008247", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008247", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008247", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008247", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008247", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008247", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008247", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008247", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008247", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008247", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008247")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008248")
    void case_UTAPI_008248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008248",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008248", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008248", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008248", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008248", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008248", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008248", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008248", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008248", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008248", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008248", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008248", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008248", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008248")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008249")
    void case_UTAPI_008249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008249",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008249", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008249", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008249", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008249", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008249", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008249", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008249", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008249", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008249", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008249", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008249", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008249", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008249")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008250")
    void case_UTAPI_008250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008250",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008250", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008250", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008250", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008250", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008250", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008250", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008250", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008250", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008250", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008250", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008250", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008250", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008250")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008251")
    void case_UTAPI_008251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008251",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008251", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008251", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008251", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008251", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008251", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008251", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008251", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008251", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008251", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008251", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008251", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008251", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008251")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008252")
    void case_UTAPI_008252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008252",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008252", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008252", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008252", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008252", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008252", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008252", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008252", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008252", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008252", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008252", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008252", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008252", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008252")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008253")
    void case_UTAPI_008253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008253",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008253", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008253", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008253", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008253", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008253", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008253", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008253", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008253", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008253", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008253", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008253", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008253", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008253", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008253")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008254")
    void case_UTAPI_008254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008254",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008254", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008254", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008254", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008254", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008254", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008254", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008254", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008254", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008254", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008254", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008254", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008254", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008254", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008254")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008255")
    void case_UTAPI_008255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008255",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008255", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008255", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008255", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008255", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008255", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008255", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008255", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008255", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008255", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008255", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008255", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008255", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008255", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008255")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008256")
    void case_UTAPI_008256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008256",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008256", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008256", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008256", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008256", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008256", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008256", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008256", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008256", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008256", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008256", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008256", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008256", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008256", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008256")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008257")
    void case_UTAPI_008257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008257",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008257", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008257", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008257", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008257", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008257", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008257", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008257", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008257", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008257", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008257", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008257", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008257", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008257", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008257")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008258")
    void case_UTAPI_008258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008258",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008258", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008258", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008258", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008258", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008258", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008258", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008258", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008258", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008258", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008258", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008258", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008258", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008258", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008258")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008259")
    void case_UTAPI_008259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008259",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008259", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008259", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008259", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008259", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008259", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008259", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008259", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008259", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008259", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008259", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008259", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008259", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008259", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008259")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008260")
    void case_UTAPI_008260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008260",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008260", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008260", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008260", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008260", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008260", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008260", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008260", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008260", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008260", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008260", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008260", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008260", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008260", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008260")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008261")
    void case_UTAPI_008261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008261",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008261", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008261", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008261", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008261", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008261", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008261", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008261", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008261", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008261", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008261", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008261", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008261", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008261", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008261")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008262")
    void case_UTAPI_008262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008262",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008262", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008262", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008262", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008262", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008262", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008262", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008262", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008262", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008262", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008262", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008262", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008262", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008262", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008262")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008263")
    void case_UTAPI_008263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008263",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008263", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008263", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008263", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008263", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008263", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008263", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008263", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008263", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008263", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008263", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008263", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008263", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008263", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008263")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008264")
    void case_UTAPI_008264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008264",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008264", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008264", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008264", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008264", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008264", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008264", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008264", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008264", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008264", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008264", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008264", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008264", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008264", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008264")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008265")
    void case_UTAPI_008265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008265",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008265", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008265", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008265", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008265", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008265", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008265", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008265", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008265", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008265", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008265", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008265", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008265", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008265", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008265")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008266")
    void case_UTAPI_008266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008266",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008266", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008266", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008266", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008266", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008266", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008266", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008266", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008266", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008266", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008266", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008266", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008266", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008266", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008266")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008267")
    void case_UTAPI_008267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008267",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008267", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008267", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008267", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008267", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008267", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008267", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008267", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008267", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008267", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008267", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008267", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008267", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008267", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008267")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008268")
    void case_UTAPI_008268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008268",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008268", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008268", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008268", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008268", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008268", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008268", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008268", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008268", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008268", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008268", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008268", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008268", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008268", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008268")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008269")
    void case_UTAPI_008269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008269",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008269", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008269", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008269", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008269", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008269", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008269", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008269", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008269", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008269", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008269", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008269", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008269", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008269", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008269")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008270")
    void case_UTAPI_008270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008270",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008270", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008270", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008270", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008270", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008270", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008270", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008270", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008270", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008270", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008270", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008270", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008270", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008270", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008270")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008271")
    void case_UTAPI_008271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008271",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008271", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008271", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008271", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008271", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008271", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008271", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008271", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008271", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008271", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008271", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008271", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008271", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008271", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008271")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008272")
    void case_UTAPI_008272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008272",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008272", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008272", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008272", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008272", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008272", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008272", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008272", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008272", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008272", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008272", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008272", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008272", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008272", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008272")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008273")
    void case_UTAPI_008273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008273",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008273", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008273", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008273", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008273", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008273", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008273", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008273", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008273", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008273", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008273", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008273", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008273", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008273", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008273")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008274")
    void case_UTAPI_008274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008274",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008274", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008274", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008274", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008274", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008274", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008274", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008274", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008274", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008274", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008274", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008274", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008274", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008274", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008274")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008275")
    void case_UTAPI_008275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008275",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008275", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008275", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008275", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008275", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008275", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008275", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008275", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008275", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008275", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008275", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008275", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008275", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008275", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008275")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008276")
    void case_UTAPI_008276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008276",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008276", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008276", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008276", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008276", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008276", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008276", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008276", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008276", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008276", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008276", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008276", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008276", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008276", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008276")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008277")
    void case_UTAPI_008277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008277",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008277", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008277", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008277", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008277", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008277", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008277", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008277", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008277", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008277", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008277", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008277", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008277", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008277", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008277")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008278")
    void case_UTAPI_008278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008278",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008278", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008278", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008278", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008278", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008278", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008278", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008278", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008278", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008278", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008278", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008278", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008278", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008278", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008278")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008279")
    void case_UTAPI_008279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008279",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008279", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008279", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008279", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008279", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008279", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008279", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008279", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008279", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008279", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008279", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008279", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008279", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008279", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008279")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008280")
    void case_UTAPI_008280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008280",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008280", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008280", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008280", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008280", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008280", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008280", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008280", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008280", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008280", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008280", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008280", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008280", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008280", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008280")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008281")
    void case_UTAPI_008281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008281",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008281", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008281", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008281", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008281", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008281", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008281", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008281", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008281", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008281", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008281", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008281", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008281", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008281", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008281")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008282")
    void case_UTAPI_008282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008282",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008282", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008282", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008282", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008282", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008282", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008282", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008282", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008282", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008282", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008282", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008282", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008282", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008282", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008282")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008283")
    void case_UTAPI_008283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008283",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008283", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008283", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008283", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008283", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008283", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008283")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008284")
    void case_UTAPI_008284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008284",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008284", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008284", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008284", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008284", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008284", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008284")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008285")
    void case_UTAPI_008285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008285",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008285", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008285", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008285", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008285", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008285", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008285")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008286")
    void case_UTAPI_008286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008286",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008286", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008286", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008286", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008286", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008286", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008286")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008287")
    void case_UTAPI_008287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008287",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008287", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008287", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008287", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008287", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008287", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008287")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008288")
    void case_UTAPI_008288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008288",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008288", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008288", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008288", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008288", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008288")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008289")
    void case_UTAPI_008289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008289",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008289", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008289", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008289", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008289", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008289")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008290")
    void case_UTAPI_008290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008290",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008290", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008290", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008290", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008290", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008290")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008291")
    void case_UTAPI_008291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008291",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008291", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008291", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008291", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008291")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008292")
    void case_UTAPI_008292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008292",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008292", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008292", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008292", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008292")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008293")
    void case_UTAPI_008293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008293",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008293", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008293", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008293", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008293")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008294")
    void case_UTAPI_008294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008294",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008294", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008294", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008294", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008294")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008295")
    void case_UTAPI_008295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008295",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008295", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008295", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008295", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008295")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008296")
    void case_UTAPI_008296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008296",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008296", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008296", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008296", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008296")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008297")
    void case_UTAPI_008297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008297",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008297", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008297", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008297", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008297")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008298")
    void case_UTAPI_008298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008298",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008298", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008298", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008298", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008298")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008299")
    void case_UTAPI_008299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008299",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008299", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008299", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008299", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008299", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008299", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008299", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008299")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008300")
    void case_UTAPI_008300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008300",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008300", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008300", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008300", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008300", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008300", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008300", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008300", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008300")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008301")
    void case_UTAPI_008301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008301",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008301", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008301", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008301", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008301", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008301", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008301", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008301")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008302")
    void case_UTAPI_008302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008302",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008302", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008302", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008302", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008302", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008302", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008302", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008302")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008303")
    void case_UTAPI_008303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008303",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008303", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008303", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008303", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008303", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008303", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008303")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008304")
    void case_UTAPI_008304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008304",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008304", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008304", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008304", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008304", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008304", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008304")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008305")
    void case_UTAPI_008305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008305",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008305", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008305", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008305", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008305", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008305", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008305", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008305", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008305")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008306")
    void case_UTAPI_008306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008306",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008306", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008306", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008306", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008306", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008306", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008306", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008306", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008306")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008307")
    void case_UTAPI_008307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008307",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008307", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008307", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008307", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008307", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008307", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008307", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008307", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008307")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008308")
    void case_UTAPI_008308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008308",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008308", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008308", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008308", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008308", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008308", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008308", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008308", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008308")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008309")
    void case_UTAPI_008309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008309",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008309", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008309", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008309", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008309", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008309", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008309", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008309", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008309", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008309")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008310")
    void case_UTAPI_008310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008310",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008310", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008310", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008310", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008310", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008310", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008310", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008310", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008310", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008310")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008311")
    void case_UTAPI_008311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008311",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008311", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008311", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008311", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008311", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008311", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008311", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008311", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008311", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008311")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008312")
    void case_UTAPI_008312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008312",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008312", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008312", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008312", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008312", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008312", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008312", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008312", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008312")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008313")
    void case_UTAPI_008313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008313",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008313", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008313", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008313", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008313", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008313", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008313", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008313", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008313")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008314")
    void case_UTAPI_008314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008314",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008314", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008314", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008314", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008314", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008314", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008314", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008314", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008314")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008315")
    void case_UTAPI_008315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008315",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008315", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008315", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008315", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008315", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008315", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008315", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008315", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008315")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008316")
    void case_UTAPI_008316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008316",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008316", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008316", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008316", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008316", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008316", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008316", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008316", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008316")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008317")
    void case_UTAPI_008317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008317",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008317", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008317", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008317", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008317", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008317", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008317", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008317", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008317")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008318")
    void case_UTAPI_008318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008318",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008318", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008318", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008318", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008318", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008318", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008318", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008318")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008319")
    void case_UTAPI_008319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008319",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008319", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008319", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008319", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008319", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008319", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008319", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008319")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008320")
    void case_UTAPI_008320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008320",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008320", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008320", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008320", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008320", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008320")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008321")
    void case_UTAPI_008321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008321",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008321", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008321", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008321", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008321", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008321")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008322")
    void case_UTAPI_008322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008322",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008322", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008322", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008322", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008322", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008322")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008323")
    void case_UTAPI_008323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008323",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008323", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008323", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008323", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008323", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008323")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008324")
    void case_UTAPI_008324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008324",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008324", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008324", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008324", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008324", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008324")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008325")
    void case_UTAPI_008325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008325",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008325", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008325", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008325", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008325", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008325")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008326")
    void case_UTAPI_008326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008326",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008326", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008326", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008326", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008326", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008326")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008327")
    void case_UTAPI_008327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008327",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008327", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008327", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008327", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008327", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008327")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008328")
    void case_UTAPI_008328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008328",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008328", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008328", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008328", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008328", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008328")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008329")
    void case_UTAPI_008329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008329",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008329", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008329", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008329", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008329", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008329")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008330")
    void case_UTAPI_008330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008330",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008330", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008330", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008330", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008330", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008330")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008331")
    void case_UTAPI_008331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008331",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008331", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008331", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008331", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008331", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008331", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008331")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008332")
    void case_UTAPI_008332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008332",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008332", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008332", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008332", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008332", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008332", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008332")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008333")
    void case_UTAPI_008333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008333",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008333", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008333", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008333", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008333", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008333")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008334")
    void case_UTAPI_008334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008334",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008334", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008334", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008334", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008334", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008334")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008335")
    void case_UTAPI_008335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008335",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008335", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008335", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008335", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008335", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008335")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008336")
    void case_UTAPI_008336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008336",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008336", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008336", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008336", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008336", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008336")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008337")
    void case_UTAPI_008337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008337",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008337", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008337", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008337", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008337", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008337")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008338")
    void case_UTAPI_008338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008338",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008338", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008338", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008338", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008338", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008338")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008339")
    void case_UTAPI_008339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008339",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008339", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008339", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008339", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008339", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008339", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008339", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008339")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008340")
    void case_UTAPI_008340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008340",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008340", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008340", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008340", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008340", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008340", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008340", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008340")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008341")
    void case_UTAPI_008341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008341",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008341", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008341", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008341", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008341", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008341", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008341", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008341")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008342")
    void case_UTAPI_008342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008342",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008342", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008342", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008342", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008342", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008342", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008342", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008342")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008343")
    void case_UTAPI_008343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008343",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008343", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008343", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008343", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008343", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008343", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008343", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008343", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008343")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008344")
    void case_UTAPI_008344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008344",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008344", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008344", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008344", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008344", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008344", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008344", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008344")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008345")
    void case_UTAPI_008345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008345",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008345", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008345", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008345", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008345", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008345", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008345", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008345")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008346")
    void case_UTAPI_008346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008346",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008346", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008346", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008346", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008346", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008346", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008346", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008346")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008347")
    void case_UTAPI_008347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008347",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008347", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008347", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008347", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008347", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008347", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008347", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008347")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008348")
    void case_UTAPI_008348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008348",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008348", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008348", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008348", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008348", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008348", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008348", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008348")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008349")
    void case_UTAPI_008349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008349",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008349", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008349", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008349", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008349", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008349", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008349", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008349")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008350")
    void case_UTAPI_008350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008350",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008350", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008350", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008350", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008350", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008350", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008350", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008350", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008350")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008351")
    void case_UTAPI_008351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008351",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008351", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008351", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008351", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008351", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008351", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008351", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008351", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008351", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008351")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008352")
    void case_UTAPI_008352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008352",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008352", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008352", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008352", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008352", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008352", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008352", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008352", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008352")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008353")
    void case_UTAPI_008353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008353",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008353", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008353", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008353", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008353", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008353", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008353", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008353", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008353")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008354")
    void case_UTAPI_008354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008354",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008354", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008354", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008354", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008354", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008354", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008354", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008354", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008354")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008355")
    void case_UTAPI_008355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008355",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008355", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008355", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008355", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008355", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008355", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008355", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008355", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008355")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008356")
    void case_UTAPI_008356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008356",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008356", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008356", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008356", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008356", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008356", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008356", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008356", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008356")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008357")
    void case_UTAPI_008357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008357",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008357", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008357", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008357", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008357", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008357", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008357", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008357", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008357")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008358")
    void case_UTAPI_008358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008358",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008358", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008358", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008358", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008358", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008358", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008358", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008358", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008358")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008359")
    void case_UTAPI_008359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008359",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008359", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008359", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008359", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008359", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008359", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008359", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008359")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008360")
    void case_UTAPI_008360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008360",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008360", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008360", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008360", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008360", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008360", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008360", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008360")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008361")
    void case_UTAPI_008361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008361",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008361", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008361", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008361", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008361", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008361", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008361", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008361")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008362")
    void case_UTAPI_008362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008362",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008362", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008362", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008362", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008362", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008362", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008362", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008362")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008363")
    void case_UTAPI_008363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008363",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008363", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008363", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008363", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008363", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008363", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008363", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008363")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008364")
    void case_UTAPI_008364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008364",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008364", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008364", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008364", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008364", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008364", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008364", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008364")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008365")
    void case_UTAPI_008365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008365",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008365", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008365", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008365", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008365", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008365", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008365", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008365")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008366")
    void case_UTAPI_008366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008366",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008366", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008366", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008366", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008366", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008366", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008366", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008366")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008367")
    void case_UTAPI_008367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008367",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008367", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008367", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008367", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008367", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008367", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008367", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008367")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008368")
    void case_UTAPI_008368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008368",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008368", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008368", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008368", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008368", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008368", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008368", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008368")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008369")
    void case_UTAPI_008369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008369",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008369", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008369", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008369", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008369", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008369", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008369", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008369")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008370")
    void case_UTAPI_008370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008370",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008370", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008370", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008370", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008370", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008370", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008370", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008370", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008370")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008371")
    void case_UTAPI_008371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008371",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008371", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008371", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008371", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008371", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008371", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008371", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008371", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008371")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008372")
    void case_UTAPI_008372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008372",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008372", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008372", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008372", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008372", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008372", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008372", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008372", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008372")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008373")
    void case_UTAPI_008373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008373",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008373", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008373", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008373", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008373", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008373", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008373", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008373", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008373")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008374")
    void case_UTAPI_008374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008374",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008374", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008374", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008374", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008374", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008374", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008374", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008374", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008374")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008375")
    void case_UTAPI_008375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008375",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008375", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008375", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008375", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008375", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008375", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008375", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008375", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008375")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008376")
    void case_UTAPI_008376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008376",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008376", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008376", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008376", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008376", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008376", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008376", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008376", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008376")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008377")
    void case_UTAPI_008377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008377",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008377", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008377", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008377", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008377", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008377", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008377", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008377", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008377")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008378")
    void case_UTAPI_008378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008378",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008378", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008378", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008378", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008378", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008378", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008378", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008378", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008378")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008379")
    void case_UTAPI_008379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008379",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008379", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008379", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008379", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008379", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008379", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008379", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008379", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008379")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008380")
    void case_UTAPI_008380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008380",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008380", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008380", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008380", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008380", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008380", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008380", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008380")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008381")
    void case_UTAPI_008381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008381",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008381", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008381", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008381", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008381")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008382")
    void case_UTAPI_008382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008382",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008382", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008382", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008382", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008382")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008383")
    void case_UTAPI_008383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008383",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008383", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008383", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008383", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008383")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008384")
    void case_UTAPI_008384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008384",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008384", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008384", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008384", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008384")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008385")
    void case_UTAPI_008385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008385",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008385", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008385", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008385", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008385")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008386")
    void case_UTAPI_008386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008386",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008386", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008386", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008386", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008386")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008387")
    void case_UTAPI_008387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008387",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008387", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008387", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008387", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008387")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008388")
    void case_UTAPI_008388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008388",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008388", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008388", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008388", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008388")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008389")
    void case_UTAPI_008389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008389",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008389", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008389", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008389", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008389")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008390")
    void case_UTAPI_008390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008390",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008390", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008390", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008390", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008390")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008391")
    void case_UTAPI_008391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008391",
                "com.matsushita.dbeditor.domain.repository.TableHistoryRepository",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-008391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008391", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008391", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008391", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-008391")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableHistoryRepository.java::TableHistoryRepository::findHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryRepositoryWrapper());
    }

}

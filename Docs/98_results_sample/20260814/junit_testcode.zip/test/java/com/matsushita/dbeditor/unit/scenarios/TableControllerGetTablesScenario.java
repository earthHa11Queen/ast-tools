package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#getTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerGetTablesScenario {

    @Test
    @DisplayName("UTAPI-001555")
    void case_UTAPI_001555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001555",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001555", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001555")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001556")
    void case_UTAPI_001556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001556",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001556", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001556")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001557")
    void case_UTAPI_001557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001557",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001557", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001557")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001558")
    void case_UTAPI_001558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001558",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001558", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001558")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001559")
    void case_UTAPI_001559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001559",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001559", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001559")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001560")
    void case_UTAPI_001560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001560",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001560", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001560")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001561")
    void case_UTAPI_001561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001561",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001561", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001561")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001562")
    void case_UTAPI_001562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001562",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001562", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001562")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001563")
    void case_UTAPI_001563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001563",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001563", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001563")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001564")
    void case_UTAPI_001564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001564",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001564", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001564")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001565")
    void case_UTAPI_001565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001565",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getTables",
                "ResponseEntity<List<TableMetadataResponse>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001565", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-001565")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getTables::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of getTableListUseCase.execute")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through getTableListUseCase.execute", "getTableListUseCase", "execute")
                    .check(CheckType.ARG_EQUALS, "argument 0 of getTableListUseCase.execute must carry the value generated for connectionId", "getTableListUseCase", "execute", "0", "data:connectionId")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

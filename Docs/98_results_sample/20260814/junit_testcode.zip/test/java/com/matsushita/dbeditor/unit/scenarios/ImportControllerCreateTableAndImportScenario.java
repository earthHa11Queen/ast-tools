package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportController#createTableAndImport.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportControllerCreateTableAndImportScenario {

    @Test
    @DisplayName("UTAPI-000612")
    void case_UTAPI_000612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000612",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000612", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000612", "request.columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000612", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000612", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000612", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000612", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000612", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000612", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000612", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000612", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000612", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000612", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000612")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columnTypes")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.columnTypes", "NewTableImportRequest.columnTypes")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columnTypes classifies this input condition", "NewTableImportRequest", "columnTypes", "NotNull", "data:request.columnTypes")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000613")
    void case_UTAPI_000613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000613",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000613", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000613", "request.columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000613", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000613", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000613", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000613", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000613", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000613", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000613", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000613", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000613", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000613", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000613")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columnTypes")
                    .mirror("-", "3:length_min", "-")
                    .target("request.columnTypes", "NewTableImportRequest.columnTypes")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columnTypes classifies this input condition", "NewTableImportRequest", "columnTypes", "NotNull", "data:request.columnTypes")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000614")
    void case_UTAPI_000614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000614",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000614", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000614", "request.columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000614", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000614", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000614", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000614", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000614", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000614", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000614", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000614", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000614", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000614", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000614")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columnTypes")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.columnTypes", "NewTableImportRequest.columnTypes")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columnTypes classifies this input condition", "NewTableImportRequest", "columnTypes", "NotNull", "data:request.columnTypes")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000615")
    void case_UTAPI_000615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000615",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000615", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000615", "request.columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000615", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000615", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000615", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000615", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000615", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000615", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000615", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000615", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000615", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000615", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000615")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columnTypes")
                    .mirror("-", "5:length_max", "-")
                    .target("request.columnTypes", "NewTableImportRequest.columnTypes")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columnTypes classifies this input condition", "NewTableImportRequest", "columnTypes", "NotNull", "data:request.columnTypes")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000616")
    void case_UTAPI_000616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000616",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000616", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000616", "request.columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000616", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000616", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000616", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000616", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000616", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000616", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000616", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000616", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000616", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000616", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000616")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columnTypes")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.columnTypes", "NewTableImportRequest.columnTypes")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columnTypes classifies this input condition", "NewTableImportRequest", "columnTypes", "NotNull", "data:request.columnTypes")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000617")
    void case_UTAPI_000617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000617",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000617", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000617", "request.columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000617", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000617", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000617", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000617", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000617", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000617", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000617", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000617", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000617", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000617", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000617")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columnTypes")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.columnTypes", "NewTableImportRequest.columnTypes")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columnTypes classifies this input condition", "NewTableImportRequest", "columnTypes", "NotNull", "data:request.columnTypes")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000618")
    void case_UTAPI_000618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000618",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000618", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000618", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000618", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000618", "request.columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000618", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000618", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000618", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000618", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000618", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000618", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000618", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000618", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000618")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columns")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.columns", "NewTableImportRequest.columns")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columns classifies this input condition", "NewTableImportRequest", "columns", "NotNull", "data:request.columns")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000619")
    void case_UTAPI_000619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000619",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000619", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000619", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000619", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000619", "request.columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000619", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000619", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000619", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000619", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000619", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000619", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000619", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000619", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000619")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columns")
                    .mirror("-", "3:length_min", "-")
                    .target("request.columns", "NewTableImportRequest.columns")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columns classifies this input condition", "NewTableImportRequest", "columns", "NotNull", "data:request.columns")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000620")
    void case_UTAPI_000620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000620",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000620", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000620", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000620", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000620", "request.columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000620", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000620", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000620", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000620", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000620", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000620", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000620", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000620", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000620")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columns")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.columns", "NewTableImportRequest.columns")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columns classifies this input condition", "NewTableImportRequest", "columns", "NotNull", "data:request.columns")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000621")
    void case_UTAPI_000621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000621",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000621", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000621", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000621", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000621", "request.columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000621", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000621", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000621", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000621", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000621", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000621", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000621", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000621", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000621")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columns")
                    .mirror("-", "5:length_max", "-")
                    .target("request.columns", "NewTableImportRequest.columns")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columns classifies this input condition", "NewTableImportRequest", "columns", "NotNull", "data:request.columns")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000622")
    void case_UTAPI_000622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000622",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000622", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000622", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000622", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000622", "request.columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000622", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000622", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000622", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000622", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000622", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000622", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000622", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000622", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000622")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columns")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.columns", "NewTableImportRequest.columns")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columns classifies this input condition", "NewTableImportRequest", "columns", "NotNull", "data:request.columns")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000623")
    void case_UTAPI_000623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000623",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000623", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000623", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000623", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000623", "request.columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000623", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000623", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000623", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000623", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000623", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000623", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000623", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000623", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000623")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::columns")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.columns", "NewTableImportRequest.columns")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.columns classifies this input condition", "NewTableImportRequest", "columns", "NotNull", "data:request.columns")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000624")
    void case_UTAPI_000624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000624",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000624", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000624", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000624", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000624", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000624", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000624", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000624", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000624", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000624", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000624", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000624", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000624", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000624")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.connectionId classifies this input condition", "NewTableImportRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000625")
    void case_UTAPI_000625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000625",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000625", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000625", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000625", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000625", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000625", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000625", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000625", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000625", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000625", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000625", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000625", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000625", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000625")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.connectionId classifies this input condition", "NewTableImportRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000626")
    void case_UTAPI_000626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000626",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000626", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000626", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000626", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000626", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000626", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000626", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000626", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000626", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000626", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000626", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000626", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000626", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000626")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.connectionId classifies this input condition", "NewTableImportRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000627")
    void case_UTAPI_000627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000627",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000627", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000627", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000627", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000627", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000627", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000627", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000627", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000627", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000627", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000627", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000627", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000627", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000627")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.connectionId classifies this input condition", "NewTableImportRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000628")
    void case_UTAPI_000628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000628",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000628", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000628", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000628", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000628", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000628", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000628", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000628", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000628", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000628", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000628", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000628", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000628", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000628")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.connectionId classifies this input condition", "NewTableImportRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000629")
    void case_UTAPI_000629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000629",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000629", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000629", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000629", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000629", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000629", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000629", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000629", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000629", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000629", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000629", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000629", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000629", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000629")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.connectionId classifies this input condition", "NewTableImportRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000630")
    void case_UTAPI_000630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000630",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000630", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000630", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000630", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000630", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000630", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000630", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000630", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000630", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000630", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000630", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000630", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000630", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000630")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000631")
    void case_UTAPI_000631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000631",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000631", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000631", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000631", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000631", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000631", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000631", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000631", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000631", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000631", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000631", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000631", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000631", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000631")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000632")
    void case_UTAPI_000632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000632",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000632", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000632", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000632", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000632", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000632", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000632", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000632", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000632", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000632", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000632", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000632", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000632", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000632")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000633")
    void case_UTAPI_000633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000633",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000633", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000633", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000633", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000633", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000633", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000633", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000633", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000633", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000633", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000633", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000633", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000633", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000633")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "NewTableImportRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000634")
    void case_UTAPI_000634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000634",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000634", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000634", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000634", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000634", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000634", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000634", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000634", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000634", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000634", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000634", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000634", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000634", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000634")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.rows", "NewTableImportRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.rows classifies this input condition", "NewTableImportRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000635")
    void case_UTAPI_000635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000635",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000635", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000635", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000635", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000635", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000635", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000635", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000635", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000635", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000635", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000635", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000635", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000635", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000635")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("request.rows", "NewTableImportRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.rows classifies this input condition", "NewTableImportRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000636")
    void case_UTAPI_000636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000636",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000636", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000636", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000636", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000636", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000636", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000636", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000636", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000636", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000636", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000636", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000636", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000636", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000636")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.rows", "NewTableImportRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.rows classifies this input condition", "NewTableImportRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000637")
    void case_UTAPI_000637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000637",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000637", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000637", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000637", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000637", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000637", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000637", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000637", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000637", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000637", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000637", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000637", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000637", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000637")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("request.rows", "NewTableImportRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.rows classifies this input condition", "NewTableImportRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000638")
    void case_UTAPI_000638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000638",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000638", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000638", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000638", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000638", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000638", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000638", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000638", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000638", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000638", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000638", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000638", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000638", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000638")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.rows", "NewTableImportRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.rows classifies this input condition", "NewTableImportRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000639")
    void case_UTAPI_000639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000639",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000639", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000639", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000639", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000639", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000639", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000639", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000639", "request.rows", "TARGET", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000639", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000639", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000639", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000639", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000639", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000639")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.rows", "NewTableImportRequest.rows")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of NewTableImportRequest.rows classifies this input condition", "NewTableImportRequest", "rows", "NotNull", "data:request.rows")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000640")
    void case_UTAPI_000640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000640",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000640", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000640", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000640", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000640", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000640", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000640", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000640", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000640", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000640", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000640", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000640", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000640", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000640")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000641")
    void case_UTAPI_000641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000641",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000641", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000641", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000641", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000641", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000641", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000641", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000641", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000641", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000641", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000641", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000641", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000641", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000641")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000642")
    void case_UTAPI_000642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000642",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000642", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000642", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000642", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000642", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000642", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000642", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000642", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000642", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000642", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000642", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000642", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000642", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000642")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000643")
    void case_UTAPI_000643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000643",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000643", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000643", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000643", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000643", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000643", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000643", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000643", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000643", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000643", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000643", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000643", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000643", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000643")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000644")
    void case_UTAPI_000644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000644",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000644", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000644", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000644", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000644", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000644", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000644", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000644", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000644", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000644", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000644", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000644", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000644", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000644")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000645")
    void case_UTAPI_000645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000645",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000645", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000645", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000645", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000645", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000645", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000645", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000645", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000645", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000645", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000645", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000645", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000645", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000645")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000646")
    void case_UTAPI_000646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000646",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000646", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000646", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000646", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000646", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000646", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000646", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000646", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000646", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000646", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000646", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000646", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000646", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000646")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000647")
    void case_UTAPI_000647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000647",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000647", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000647", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000647", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000647", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000647", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000647", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000647", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000647", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000647", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000647", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000647", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000647", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000647")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000648")
    void case_UTAPI_000648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000648",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000648", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000648", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000648", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000648", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000648", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000648", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000648", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000648", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000648", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000648", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000648", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000648", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000648")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000649")
    void case_UTAPI_000649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000649",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000649", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000649", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000649", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000649", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000649", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000649", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000649", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000649", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000649", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000649", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000649", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000649", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000649")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000650")
    void case_UTAPI_000650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000650",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000650", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000650", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000650", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000650", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000650", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000650", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000650", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000650", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000650", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000650", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000650", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000650", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000650")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000651")
    void case_UTAPI_000651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000651",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000651", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000651", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000651", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000651", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000651", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000651", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000651", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000651", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000651", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000651", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000651", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000651", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000651")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000652")
    void case_UTAPI_000652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000652",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000652", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000652", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000652", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000652", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000652", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000652", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000652", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000652", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000652", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000652", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000652", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000652", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000652")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000653")
    void case_UTAPI_000653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000653",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000653", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000653", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000653", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000653", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000653", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000653", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000653", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000653", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000653", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000653", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000653", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000653", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000653")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000654")
    void case_UTAPI_000654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000654",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000654", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000654", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000654", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000654", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000654", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000654", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000654", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000654", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000654", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000654", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000654", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000654", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000654")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000655")
    void case_UTAPI_000655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000655",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000655", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000655", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000655", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000655", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000655", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000655", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000655", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000655", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000655", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000655", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000655", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000655", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000655")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000656")
    void case_UTAPI_000656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000656",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000656", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000656", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000656", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000656", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000656", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000656", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000656", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000656", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000656", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000656", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000656", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000656", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000656")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000657")
    void case_UTAPI_000657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000657",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000657", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000657", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000657", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000657", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000657", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000657", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000657", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000657", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000657", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000657", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000657", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000657", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000657")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000658")
    void case_UTAPI_000658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000658",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000658", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000658", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000658", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000658", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000658", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000658", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000658", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000658", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000658", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000658", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000658", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000658", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000658")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000659")
    void case_UTAPI_000659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000659",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000659", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000659", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000659", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000659", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000659", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000659", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000659", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000659", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000659", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000659", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000659", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000659", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000659")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000660")
    void case_UTAPI_000660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000660",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000660", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000660", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000660", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000660", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000660", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000660", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000660", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000660", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000660", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000660", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000660", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000660", "request.tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000660")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "NewTableImportRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000661")
    void case_UTAPI_000661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000661",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000661", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000661", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000661", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000661", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000661", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000661", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000661", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000661", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000661", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000661", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000661", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000661", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000661")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of NewTableImportRequest.tableName classifies this input condition", "NewTableImportRequest", "tableName", "NotBlank", "data:request.tableName")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000662")
    void case_UTAPI_000662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000662",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000662", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000662", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000662", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000662", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000662", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000662", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000662", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000662", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000662", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000662", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000662", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000662", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000662")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000663")
    void case_UTAPI_000663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000663",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000663", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000663", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000663", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000663", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000663", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000663", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000663", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000663", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000663", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000663", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000663", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000663", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000663")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000664")
    void case_UTAPI_000664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000664",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000664", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000664", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000664", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000664", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000664", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000664", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000664", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000664", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000664", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000664", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000664", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000664", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000664")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000665")
    void case_UTAPI_000665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000665",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000665", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000665", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000665", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000665", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000665", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000665", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000665", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000665", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000665", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000665", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000665", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000665", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000665")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000666")
    void case_UTAPI_000666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000666",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000666", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000666", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000666", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000666", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000666", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000666", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000666", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000666", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000666", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000666", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000666", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000666", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000666")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000667")
    void case_UTAPI_000667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000667",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000667", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000667", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000667", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000667", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000667", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000667", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000667", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000667", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000667", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000667", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000667", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000667", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000667")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000668")
    void case_UTAPI_000668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000668",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000668", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000668", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000668", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000668", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000668", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000668", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000668", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000668", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000668", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000668", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000668", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000668", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000668")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000669")
    void case_UTAPI_000669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000669",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000669", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000669", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000669", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000669", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000669", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000669", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000669", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000669", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000669", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000669", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000669", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000669", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000669")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000670")
    void case_UTAPI_000670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000670",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000670", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000670", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000670", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000670", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000670", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000670", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000670", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000670", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000670", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000670", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000670", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000670", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000670")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000671")
    void case_UTAPI_000671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000671",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000671", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000671", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000671", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000671", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000671", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000671", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000671", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000671", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000671", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000671", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000671", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000671", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000671")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000672")
    void case_UTAPI_000672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000672",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000672", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000672", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000672", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000672", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000672", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000672", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000672", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000672", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000672", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000672", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000672", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000672", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000672")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000673")
    void case_UTAPI_000673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000673",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000673", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000673", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000673", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000673", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000673", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000673", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000673", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000673", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000673", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000673", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000673", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000673", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000673")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "56:space")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000674")
    void case_UTAPI_000674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000674",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000674", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000674", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000674", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000674", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000674", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000674", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000674", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000674", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000674", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000674", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000674", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000674", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000674")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000675")
    void case_UTAPI_000675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000675",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000675", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000675", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000675", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000675", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000675", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000675", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000675", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000675", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000675", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000675", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000675", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000675", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000675")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000676")
    void case_UTAPI_000676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000676",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000676", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000676", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000676", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000676", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000676", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000676", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000676", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000676", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000676", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000676", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000676", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000676", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000676")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000677")
    void case_UTAPI_000677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000677",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000677", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000677", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000677", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000677", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000677", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000677", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000677", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000677", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000677", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000677", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000677", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000677", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000677")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000678")
    void case_UTAPI_000678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000678",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000678", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000678", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000678", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000678", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000678", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000678", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000678", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000678", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000678", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000678", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000678", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000678", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000678")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000679")
    void case_UTAPI_000679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000679",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000679", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000679", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000679", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000679", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000679", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000679", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000679", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000679", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000679", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000679", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000679", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000679", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000679")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000680")
    void case_UTAPI_000680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000680",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "createTableAndImport",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("request", "NewTableImportRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000680", "request", "NORMAL", "OBJECT", "NewTableImportRequest"),
                    new DataRef("UTAPI-000680", "request.columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000680", "request.columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000680", "request.columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-000680", "request.columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000680", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000680", "request.rows", "NORMAL", "COLLECTION", "List<Map<String,String>>"),
                    new DataRef("UTAPI-000680", "request.rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-000680", "request.rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000680", "request.rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000680", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000680", "request.tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000680")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::createTableAndImport::4::FIELD::1::NewTableImportRequest::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.tableName", "NewTableImportRequest.tableName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.createTableAndImport")
                    .expected("the value generated for request.tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.createTableAndImport", "importUseCase", "createTableAndImport")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.createTableAndImport must carry the value generated for request.connectionId", "importUseCase", "createTableAndImport", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.createTableAndImport must carry the value generated for request.tableName", "importUseCase", "createTableAndImport", "1", "data:request.tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.createTableAndImport must carry the value generated for request.schemaName", "importUseCase", "createTableAndImport", "2", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.createTableAndImport must carry the value generated for request.columns", "importUseCase", "createTableAndImport", "3", "data:request.columns")
                    .check(CheckType.ARG_EQUALS, "argument 4 of importUseCase.createTableAndImport must carry the value generated for request.columnTypes", "importUseCase", "createTableAndImport", "4", "data:request.columnTypes")
                    .check(CheckType.ARG_EQUALS, "argument 5 of importUseCase.createTableAndImport must carry the value generated for request.rows", "importUseCase", "createTableAndImport", "5", "data:request.rows")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

}

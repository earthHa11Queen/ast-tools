package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ConnectionUseCase.
 */
public final class ConnectionUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase";
    private static final String[] DEP_NAMES = new String[] {"connectionSettingRepository"};
    private static final String[] DEP_TYPES = new String[] {"ConnectionSettingRepository"};
    private static final String[] TYPES_create = new String[] {"ConnectionSettingRequest"};
    private static final String[] TYPES_delete = new String[] {"Integer"};
    private static final String[] TYPES_getAll = new String[] {};
    private static final String[] TYPES_getById = new String[] {"Integer"};
    private static final String[] TYPES_testConnection = new String[] {"ConnectionTestRequest"};
    private static final String[] TYPES_update = new String[] {"Integer", "ConnectionSettingRequest"};

    public ConnectionUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ConnectionSetting create(request) */
    public ExecutionResult create(Object[] args) {
        return invoke("create", TYPES_create, args);
    }

    /** void delete(n) */
    public ExecutionResult delete(Object[] args) {
        return invoke("delete", TYPES_delete, args);
    }

    /** List<ConnectionSetting> getAll() */
    public ExecutionResult getAll(Object[] args) {
        return invoke("getAll", TYPES_getAll, args);
    }

    /** ConnectionSetting getById(n) */
    public ExecutionResult getById(Object[] args) {
        return invoke("getById", TYPES_getById, args);
    }

    /** boolean testConnection(request) */
    public ExecutionResult testConnection(Object[] args) {
        return invoke("testConnection", TYPES_testConnection, args);
    }

    /** ConnectionSetting update(n, request) */
    public ExecutionResult update(Object[] args) {
        return invoke("update", TYPES_update, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("create".equals(operation)) {
            return create(args);
        } else if ("delete".equals(operation)) {
            return delete(args);
        } else if ("getAll".equals(operation)) {
            return getAll(args);
        } else if ("getById".equals(operation)) {
            return getById(args);
        } else if ("testConnection".equals(operation)) {
            return testConnection(args);
        } else if ("update".equals(operation)) {
            return update(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

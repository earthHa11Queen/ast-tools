package com.matsushita.dbeditor.utils;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import com.matsushita.dbeditor.constants.TestRunConstants;

/**
 * Connects generated JUnit code to the existing TestDataRuntime.
 *
 * <p>No test value is produced here. Concrete values for STRING / NUMBER / DECIMAL /
 * BOOLEAN / DATE / DATETIME / ENUM / COLLECTION / ARRAY / MAP and every Mirror X/Y/Z
 * condition are produced by TestDataRuntime, which also records Evidence keyed by
 * CaseNo + dataId + elementIndex and supports Replay. The generated code only supplies
 * the CaseNo and the dataId taken from test-data-instruction.</p>
 */
public final class TestDataAccess {

    private TestDataAccess() {
    }

    private static final String[] CANDIDATES = new String[] {
        "com.matsushita.dbeditor.runtime.TestDataRuntime",
        "com.matsushita.dbeditor.testdata.TestDataRuntime",
        "com.matsushita.dbeditor.utils.TestDataRuntime",
        "com.matsushita.dbeditor.unit.runtime.TestDataRuntime",
        "com.matsushita.dbeditor.TestDataRuntime",
        "runtime.TestDataRuntime",
        "TestDataRuntime"
    };

    private static volatile Class<?> runtimeClass;
    private static volatile Method getValueMethod;
    private static volatile Object runtimeInstance;
    private static volatile boolean runModeApplied;

    private static synchronized void resolve() {
        if (getValueMethod != null) {
            return;
        }
        String configured = System.getProperty(TestRunConstants.RUNTIME_CLASS_PROPERTY);
        Class<?> found = null;
        if (configured != null && !configured.trim().isEmpty()) {
            found = loadOrNull(configured.trim());
            if (found == null) {
                throw new HarnessException("TestDataRuntime class not found: " + configured);
            }
        } else {
            for (int i = 0; i < CANDIDATES.length; i++) {
                found = loadOrNull(CANDIDATES[i]);
                if (found != null) {
                    break;
                }
            }
        }
        if (found == null) {
            throw new HarnessException("TestDataRuntime could not be located. Set -D"
                    + TestRunConstants.RUNTIME_CLASS_PROPERTY + "=<fully qualified class name>.");
        }
        Method method = findGetValue(found);
        if (method == null) {
            throw new HarnessException("TestDataRuntime.getValue(String,String,Class) not found on " + found.getName());
        }
        method.setAccessible(true);
        runtimeClass = found;
        getValueMethod = method;
        if (!Modifier.isStatic(method.getModifiers())) {
            runtimeInstance = instantiate(found);
        }
        applyRunMode(found);
    }

    private static void applyRunMode(Class<?> type) {
        if (runModeApplied) {
            return;
        }
        runModeApplied = true;
        try {
            Method setter = type.getMethod("setRunMode", String.class);
            setter.setAccessible(true);
            if (Modifier.isStatic(setter.getModifiers())) {
                setter.invoke(null, TestRunConstants.runMode());
            } else {
                setter.invoke(runtimeInstance, TestRunConstants.runMode());
            }
        } catch (NoSuchMethodException ignored) {
            // The runtime owns run mode configuration; nothing to connect here.
        } catch (Exception e) {
            throw new HarnessException("Failed to forward runMode to TestDataRuntime", e);
        }
    }

    private static Object instantiate(Class<?> type) {
        try {
            Method factory = type.getMethod("getInstance");
            factory.setAccessible(true);
            return factory.invoke(null);
        } catch (NoSuchMethodException e) {
            try {
                java.lang.reflect.Constructor<?> ctor = type.getDeclaredConstructor();
                ctor.setAccessible(true);
                return ctor.newInstance();
            } catch (Exception inner) {
                throw new HarnessException("Cannot instantiate TestDataRuntime " + type.getName(), inner);
            }
        } catch (Exception e) {
            throw new HarnessException("Cannot obtain TestDataRuntime instance", e);
        }
    }

    private static Method findGetValue(Class<?> type) {
        Method[] methods = type.getMethods();
        for (int i = 0; i < methods.length; i++) {
            Method m = methods[i];
            if ("getValue".equals(m.getName()) && m.getParameterCount() == 3
                    && m.getParameterTypes()[0] == String.class
                    && m.getParameterTypes()[1] == String.class
                    && m.getParameterTypes()[2] == Class.class) {
                return m;
            }
        }
        Method[] declared = type.getDeclaredMethods();
        for (int i = 0; i < declared.length; i++) {
            Method m = declared[i];
            if ("getValue".equals(m.getName()) && m.getParameterCount() == 3) {
                return m;
            }
        }
        return null;
    }

    private static Class<?> loadOrNull(String name) {
        try {
            return Class.forName(name);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Obtains the executable value for CaseNo + dataId from TestDataRuntime. */
    public static Object getValue(String caseNo, String dataId, Class<?> receivingType) {
        resolve();
        try {
            if (runtimeInstance == null) {
                return getValueMethod.invoke(null, caseNo, dataId, receivingType);
            } else {
                return getValueMethod.invoke(runtimeInstance, caseNo, dataId, receivingType);
            }
        } catch (Exception e) {
            Throwable cause = e.getCause() == null ? e : e.getCause();
            throw new HarnessException("TestDataRuntime.getValue failed for " + caseNo + " / " + dataId, cause);
        }
    }

    public static String runtimeClassName() {
        resolve();
        return runtimeClass.getName();
    }
}

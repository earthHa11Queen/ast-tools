package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportController#downloadHeaders.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportControllerDownloadHeadersScenario {

    @Test
    @DisplayName("UTAPI-000383")
    void case_UTAPI_000383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000383",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000383", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000383", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000383")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "1:length_null", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000384")
    void case_UTAPI_000384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000384",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000384", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000384", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000384")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "2:length_empty", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000385")
    void case_UTAPI_000385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000385",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000385", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000385", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000385")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "3:length_min", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000386")
    void case_UTAPI_000386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000386",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000386", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000386", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000386")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000387")
    void case_UTAPI_000387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000387",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000387", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000387", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000387")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "5:length_max", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000388")
    void case_UTAPI_000388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000388",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000388", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000388", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000388")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000389")
    void case_UTAPI_000389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000389",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000389", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000389", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000389")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000390")
    void case_UTAPI_000390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000390",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000390", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000390", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000390")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000391")
    void case_UTAPI_000391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000391",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000391", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000391", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000391")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000392")
    void case_UTAPI_000392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000392",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000392", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000392", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000392")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000393")
    void case_UTAPI_000393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000393",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000393", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000393", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000393")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000394")
    void case_UTAPI_000394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000394",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000394", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000394", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000394")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000395")
    void case_UTAPI_000395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000395",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000395", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000395", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000395")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000396")
    void case_UTAPI_000396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000396",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000396", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000396", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000396")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "56:space")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000397")
    void case_UTAPI_000397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000397",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000397", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000397", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000397")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000398")
    void case_UTAPI_000398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000398",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000398", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000398", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000398")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000399")
    void case_UTAPI_000399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000399",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000399", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000399", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000399")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "59:tab")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000400")
    void case_UTAPI_000400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000400",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000400", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000400", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000400")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "60:control_character_null")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000401")
    void case_UTAPI_000401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000401",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000401", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000401", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000401")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000402")
    void case_UTAPI_000402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000402",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000402", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000402", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000402")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000403")
    void case_UTAPI_000403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000403",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000403", "filename", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000403", "contentType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000403")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::1::-::filename")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000404")
    void case_UTAPI_000404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000404",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000404", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000404", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000404")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "1:length_null", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000405")
    void case_UTAPI_000405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000405",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000405", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000405", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000405")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "2:length_empty", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000406")
    void case_UTAPI_000406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000406",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000406", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000406", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000406")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "3:length_min", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000407")
    void case_UTAPI_000407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000407",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000407", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000407", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000407")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000408")
    void case_UTAPI_000408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000408",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000408", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000408", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000408")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "5:length_max", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000409")
    void case_UTAPI_000409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000409",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000409", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000409", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000409")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000410")
    void case_UTAPI_000410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000410",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000410", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000410", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000410")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000411")
    void case_UTAPI_000411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000411",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000411", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000411", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000411")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000412")
    void case_UTAPI_000412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000412",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000412", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000412", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000412")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000413")
    void case_UTAPI_000413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000413",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000413", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000413", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000413")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000414")
    void case_UTAPI_000414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000414",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000414", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000414", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000414")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000415")
    void case_UTAPI_000415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000415",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000415", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000415", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000415")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000416")
    void case_UTAPI_000416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000416",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000416", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000416", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000416")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "56:space")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000417")
    void case_UTAPI_000417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000417",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000417", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000417", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000417")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000418")
    void case_UTAPI_000418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000418",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000418", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000418", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000418")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000419")
    void case_UTAPI_000419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000419",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000419", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000419", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000419")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "59:tab")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000420")
    void case_UTAPI_000420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000420",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000420", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000420", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000420")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "60:control_character_null")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000421")
    void case_UTAPI_000421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000421",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000421", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000421", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000421")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000422")
    void case_UTAPI_000422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000422",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000422", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000422", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000422")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000423")
    void case_UTAPI_000423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000423",
                "com.matsushita.dbeditor.adapter.controller.ExportController",
                "downloadHeaders",
                "HttpHeaders",
                new ParamSpec[] {
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("contentType", "String", "contentType")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000423", "filename", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000423", "contentType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000423")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ExportController.java::ExportController::downloadHeaders::3::ARG::2::-::contentType")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("contentType", "contentType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("the HttpHeaders produced for the download")
                    .expected("the supplied file name and content type appear in the produced headers")
                    .failure("the file name or the content type is dropped or replaced by a fixed value")
                    .assertion("assertTrue(headers.toString().contains(value)) per supplied value")
                    .check(CheckType.RETURN_NOT_NULL, "the download headers must be produced")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied file name", "data:filename")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the headers must carry the supplied content type", "data:contentType")
                    .check(CheckType.NO_EXCEPTION, "the headers must be produced for this input condition")
                    .build()),
            new ExportControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportRepository#insertIntoCopyTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportRepositoryInsertIntoCopyTableScenario {

    @Test
    @DisplayName("UTAPI-006808")
    void case_UTAPI_006808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006808",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006808", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006808", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006808", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006808", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006808", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006808", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006808", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006808", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006808", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006808")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006809")
    void case_UTAPI_006809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006809",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006809", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006809", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006809", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006809", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006809", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006809", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006809", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006809", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006809", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006809")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006810")
    void case_UTAPI_006810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006810",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006810", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006810", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006810", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006810", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006810", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006810", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006810", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006810", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006810", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006810")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006811")
    void case_UTAPI_006811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006811",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006811", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006811", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006811", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006811", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006811", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006811", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006811", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006811", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006811", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006811")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006812")
    void case_UTAPI_006812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006812",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006812", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006812", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006812", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006812", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006812", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006812", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006812", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006812", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006812", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006812")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006813")
    void case_UTAPI_006813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006813",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006813", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006813", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006813", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006813", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006813", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006813", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006813", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006813", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006813", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006813")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006814")
    void case_UTAPI_006814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006814",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006814", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006814", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006814", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006814", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006814", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006814", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006814", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006814", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006814", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006814")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006815")
    void case_UTAPI_006815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006815",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006815", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006815", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006815", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006815", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006815", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006815", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006815", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006815", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006815", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006815")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006816")
    void case_UTAPI_006816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006816",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006816", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006816", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006816", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006816", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006816", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006816", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006816", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006816", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006816")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006817")
    void case_UTAPI_006817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006817",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006817", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006817", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006817", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006817", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006817", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006817", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006817", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006817")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006818")
    void case_UTAPI_006818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006818",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006818", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006818", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006818", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006818", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006818", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006818", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006818", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006818")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006819")
    void case_UTAPI_006819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006819",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006819", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006819", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006819", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006819", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006819", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006819", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006819", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006819")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006820")
    void case_UTAPI_006820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006820",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006820", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006820", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006820", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006820", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006820", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006820", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006820", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006820")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006821")
    void case_UTAPI_006821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006821",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006821", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006821", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006821", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006821", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006821", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006821", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006821", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006821")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006822")
    void case_UTAPI_006822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006822",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006822", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006822", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006822", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006822", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006822", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006822", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006822", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006822")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006823")
    void case_UTAPI_006823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006823",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006823", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006823", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006823", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006823", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006823", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006823", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006823", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006823")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006824")
    void case_UTAPI_006824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006824",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006824", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006824", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006824", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006824", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006824", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006824", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006824", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006824")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006825")
    void case_UTAPI_006825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006825",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006825", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006825", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006825", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006825", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006825", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006825", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006825", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006825")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006826")
    void case_UTAPI_006826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006826",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006826", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006826", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006826", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006826", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006826", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006826", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006826", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006826")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006827")
    void case_UTAPI_006827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006827",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006827", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006827", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006827", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006827", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006827", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006827", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006827", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006827", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006827")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006828")
    void case_UTAPI_006828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006828",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006828", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006828", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006828", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006828", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006828", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006828", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006828", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006828", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006828")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006829")
    void case_UTAPI_006829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006829",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006829", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006829", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006829", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006829", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006829", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006829", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006829", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006829", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006829", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006829", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006829", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006829", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006829")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006830")
    void case_UTAPI_006830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006830",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006830", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006830", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006830", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006830", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006830", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006830", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006830", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006830", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006830", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006830", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006830", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006830", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006830")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006831")
    void case_UTAPI_006831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006831",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006831", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006831", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006831", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006831", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006831", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006831", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006831", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006831", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006831", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006831", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006831", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006831", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006831")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006832")
    void case_UTAPI_006832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006832",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006832", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006832", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006832", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006832", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006832", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006832", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006832", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006832", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006832", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006832", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006832", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006832", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006832")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006833")
    void case_UTAPI_006833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006833",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006833", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006833", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006833", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006833", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006833", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006833", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006833", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006833", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006833", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006833", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006833", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006833", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006833")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006834")
    void case_UTAPI_006834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006834",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006834", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006834", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006834", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006834", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006834", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006834", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006834", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006834", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006834", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006834", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006834", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006834", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006834")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006835")
    void case_UTAPI_006835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006835",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006835", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006835", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006835", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006835", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006835", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006835", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006835", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006835", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006835", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006835", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006835", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006835", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006835")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006836")
    void case_UTAPI_006836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006836",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006836", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006836", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006836", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006836", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006836", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006836", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006836", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006836", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006836", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006836", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006836", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006836", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006836")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006837")
    void case_UTAPI_006837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006837",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006837", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006837", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006837", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006837", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006837", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006837", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006837", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006837", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006837", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006837", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006837", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006837", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006837")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006838")
    void case_UTAPI_006838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006838",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006838", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006838", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006838", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006838", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006838", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006838", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006838", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006838", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006838", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006838", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006838", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006838", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006838")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006839")
    void case_UTAPI_006839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006839",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006839", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006839", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006839", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006839", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006839", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006839", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006839", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006839", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006839", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006839", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006839", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006839", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006839")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006840")
    void case_UTAPI_006840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006840",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006840", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006840", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006840", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006840", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006840", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006840", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006840", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006840", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006840", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006840", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006840", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006840", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006840")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006841")
    void case_UTAPI_006841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006841",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006841", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006841", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006841", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006841", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006841", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006841", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006841", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006841", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006841", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006841", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006841", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006841", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006841")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006842")
    void case_UTAPI_006842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006842",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006842", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006842", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006842", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006842", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006842", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006842", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006842", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006842", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006842", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006842", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006842", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006842", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006842")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006843")
    void case_UTAPI_006843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006843",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006843", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006843", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006843", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006843", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006843", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006843", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006843", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006843", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006843", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006843", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006843", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006843", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006843")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006844")
    void case_UTAPI_006844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006844",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006844", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006844", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006844", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006844", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006844", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006844", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006844", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006844", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006844", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006844", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006844", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006844", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006844")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006845")
    void case_UTAPI_006845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006845",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006845", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006845", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006845", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006845", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006845", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006845", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006845", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006845", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006845", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006845", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006845", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006845", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006845")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006846")
    void case_UTAPI_006846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006846",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006846", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006846", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006846", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006846", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006846", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006846", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006846", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006846", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006846", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006846", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006846", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006846", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006846")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006847")
    void case_UTAPI_006847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006847",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006847", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006847", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006847", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006847", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006847", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006847", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006847", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006847", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006847", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006847", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006847", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006847", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006847")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006848")
    void case_UTAPI_006848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006848",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006848", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006848", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006848", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006848", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006848", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006848", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006848", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006848", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006848", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006848", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006848", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006848", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006848")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006849")
    void case_UTAPI_006849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006849",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006849", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006849", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006849", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006849", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006849", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006849", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006849", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006849", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006849", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006849", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006849", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006849", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006849")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006850")
    void case_UTAPI_006850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006850",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006850", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006850", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006850", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006850", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006850", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006850", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006850", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006850", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006850", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006850", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006850", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006850", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006850")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006851")
    void case_UTAPI_006851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006851",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006851", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006851", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006851", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006851", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006851", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006851", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006851", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006851", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006851", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006851", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006851", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006851", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006851")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006852")
    void case_UTAPI_006852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006852",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006852", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006852", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006852", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006852", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006852", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006852", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006852", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006852", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006852", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006852", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006852", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006852", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006852")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006853")
    void case_UTAPI_006853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006853",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006853", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006853", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006853", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006853", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006853", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006853", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006853", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006853", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006853", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006853", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006853", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006853", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006853")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006854")
    void case_UTAPI_006854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006854",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006854", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006854", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006854", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006854", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006854", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006854", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006854", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006854", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006854", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006854", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006854", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006854", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006854")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006855")
    void case_UTAPI_006855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006855",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006855", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006855", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006855", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006855", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006855", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006855", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006855", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006855", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006855", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006855", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006855", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006855", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006855")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006856")
    void case_UTAPI_006856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006856",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006856", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006856", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006856", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006856", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006856", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006856", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006856", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006856", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006856", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006856", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006856", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006856", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006856")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006857")
    void case_UTAPI_006857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006857",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006857", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006857", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006857", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006857", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006857", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006857", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006857", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006857", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006857", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006857", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006857", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006857", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006857")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006858")
    void case_UTAPI_006858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006858",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006858", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006858", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006858", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006858", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006858", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006858", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006858", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006858", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006858", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006858", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006858", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006858", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006858")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006859")
    void case_UTAPI_006859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006859",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006859", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006859", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006859", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006859", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006859", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006859", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006859", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006859", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006859", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006859", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006859", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006859", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006859")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006860")
    void case_UTAPI_006860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006860",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006860", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006860", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006860", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006860", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006860", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006860", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006860", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006860", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006860", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006860", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006860", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006860", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006860")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006861")
    void case_UTAPI_006861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006861",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006861", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006861", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006861", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006861", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006861", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006861", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006861", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006861", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006861", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006861", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006861", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006861", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006861")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006862")
    void case_UTAPI_006862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006862",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006862", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006862", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006862", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006862", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006862", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006862", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006862", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006862", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006862", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006862", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006862", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006862", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006862")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006863")
    void case_UTAPI_006863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006863",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006863", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006863", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006863", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006863", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006863", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006863", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006863", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006863", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006863", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006863", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006863", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006863", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006863")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006864")
    void case_UTAPI_006864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006864",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006864", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006864", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006864", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006864", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006864", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006864", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006864", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006864", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006864", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006864", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006864", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006864", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006864")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006865")
    void case_UTAPI_006865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006865",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006865", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006865", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006865", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006865", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006865", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006865", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006865", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006865", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006865", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006865", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006865", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006865", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006865")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006866")
    void case_UTAPI_006866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006866",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006866", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006866", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006866", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006866", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006866", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006866", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006866", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006866", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006866", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006866", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006866", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006866", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006866")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006867")
    void case_UTAPI_006867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006867",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006867", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006867", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006867", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006867", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006867", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006867", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006867", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006867", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006867", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006867", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006867", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006867", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006867")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006868")
    void case_UTAPI_006868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006868",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006868", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006868", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006868", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006868", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006868", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006868", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006868", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006868", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006868", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006868", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006868", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006868", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006868")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006869")
    void case_UTAPI_006869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006869",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006869", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006869", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006869", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006869", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006869", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006869", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006869", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006869", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006869", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006869", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006869", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006869", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006869")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006870")
    void case_UTAPI_006870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006870",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006870", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006870", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006870", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006870", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006870", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006870", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006870", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006870", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006870", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006870", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006870", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006870", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006870")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006871")
    void case_UTAPI_006871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006871",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006871", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006871", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006871", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006871", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006871", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006871", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006871", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006871", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006871", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006871", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006871", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006871", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006871")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006872")
    void case_UTAPI_006872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006872",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006872", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006872", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006872", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006872", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006872", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006872", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006872", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006872", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006872", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006872", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006872", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006872", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006872")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006873")
    void case_UTAPI_006873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006873",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006873", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006873", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006873", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006873", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006873", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006873", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006873", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006873", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006873", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006873", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006873", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006873", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006873")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006874")
    void case_UTAPI_006874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006874",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006874", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006874", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006874", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006874", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006874", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006874", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006874", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006874", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006874", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006874", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006874", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006874", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006874")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006875")
    void case_UTAPI_006875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006875",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006875", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006875", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006875", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006875", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006875", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006875", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006875", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006875", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006875", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006875", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006875", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006875", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006875")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006876")
    void case_UTAPI_006876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006876",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006876", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006876", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006876", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006876", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006876", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006876", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006876", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006876", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006876", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006876", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006876", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006876", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006876")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006877")
    void case_UTAPI_006877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006877",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006877", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006877", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006877", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006877", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006877", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006877", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006877", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006877", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006877", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006877", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006877", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006877", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006877")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006878")
    void case_UTAPI_006878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006878",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006878", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006878", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006878", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006878", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006878", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006878", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006878", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006878", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006878", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006878", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006878", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006878", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006878")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006879")
    void case_UTAPI_006879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006879",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006879", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006879", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006879", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006879", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006879", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006879", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006879", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006879", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006879", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006879", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006879", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006879", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006879")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006880")
    void case_UTAPI_006880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006880",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006880", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006880", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006880", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006880", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006880", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006880", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006880", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006880", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006880", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006880", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006880", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006880", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006880")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006881")
    void case_UTAPI_006881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006881",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006881", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006881", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006881", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006881", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006881", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006881", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006881", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006881", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006881", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006881", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006881", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006881", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006881")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006882")
    void case_UTAPI_006882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006882",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006882", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006882", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006882", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006882", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006882", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006882", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006882", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006882", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006882", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006882", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006882", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006882", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006882")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006883")
    void case_UTAPI_006883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006883",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006883", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006883", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006883", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006883", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006883", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006883", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006883", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006883", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006883", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006883", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006883", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006883", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006883")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006884")
    void case_UTAPI_006884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006884",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006884", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006884", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006884", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006884", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006884", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006884", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006884", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006884", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006884", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006884", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006884", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006884", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006884")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006885")
    void case_UTAPI_006885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006885",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006885", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006885", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006885", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006885", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006885", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006885", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006885", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006885", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006885", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006885", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006885", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006885", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006885")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006886")
    void case_UTAPI_006886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006886",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006886", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006886", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006886", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006886", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006886", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006886", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006886", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006886", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006886", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006886", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006886", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006886", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006886")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006887")
    void case_UTAPI_006887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006887",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006887", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006887", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006887", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006887", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006887", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006887", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006887", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006887", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006887", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006887", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006887", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006887", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006887")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006888")
    void case_UTAPI_006888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006888",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006888", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006888", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006888", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006888", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006888", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006888", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006888", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006888", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006888", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006888", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006888", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006888", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006888")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006889")
    void case_UTAPI_006889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006889",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006889", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006889", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006889", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006889", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006889", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006889", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006889", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006889", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006889", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006889", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006889", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006889", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006889")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006890")
    void case_UTAPI_006890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006890",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006890", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006890", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006890", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006890", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006890", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006890", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006890", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006890", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006890", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006890", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006890", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006890", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006890")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006891")
    void case_UTAPI_006891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006891",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006891", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006891", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006891", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006891", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006891", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006891", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006891", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006891", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006891", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006891", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006891", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006891", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006891")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006892")
    void case_UTAPI_006892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006892",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006892", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006892", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006892", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006892", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006892", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006892", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006892", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006892", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006892", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006892", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006892", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006892", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006892")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006893")
    void case_UTAPI_006893() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006893",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006893", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006893", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006893", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006893", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006893", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006893", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006893", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006893", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006893", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006893", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006893", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006893", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006893")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006894")
    void case_UTAPI_006894() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006894",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006894", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006894", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006894", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006894", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006894", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006894", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006894", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006894", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006894", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006894", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006894", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006894", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006894")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006895")
    void case_UTAPI_006895() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006895",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006895", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006895", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006895", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006895", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006895", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006895", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006895", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006895", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006895", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006895", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006895", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006895", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006895")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006896")
    void case_UTAPI_006896() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006896",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006896", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006896", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006896", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006896", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006896", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006896", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006896", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006896", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006896", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006896", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006896", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006896", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006896")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006897")
    void case_UTAPI_006897() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006897",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006897", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006897", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006897", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006897", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006897", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006897", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006897", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006897", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006897", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006897", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006897", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006897", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006897")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006898")
    void case_UTAPI_006898() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006898",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006898", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006898", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006898", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006898", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006898", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006898", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006898", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006898", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006898", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006898", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006898", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006898")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006899")
    void case_UTAPI_006899() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006899",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006899", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006899", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006899", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006899", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006899", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006899", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006899", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006899", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006899", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006899", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006899", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006899")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006900")
    void case_UTAPI_006900() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006900",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006900", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006900", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006900", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006900", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006900", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006900", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006900", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006900", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006900", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006900", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006900", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006900")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006901")
    void case_UTAPI_006901() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006901",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006901", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006901", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006901", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006901", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006901", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006901", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006901", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006901", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006901", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006901", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006901", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006901")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006902")
    void case_UTAPI_006902() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006902",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006902", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006902", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006902", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006902", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006902", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006902", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006902", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006902", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006902", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006902", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006902", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006902")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006903")
    void case_UTAPI_006903() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006903",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006903", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006903", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006903", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006903", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006903", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006903", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006903", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006903", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006903", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006903", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006903", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006903")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006904")
    void case_UTAPI_006904() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006904",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006904", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006904", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006904", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006904", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006904", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006904", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006904", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006904", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006904", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006904", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006904", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006904")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006905")
    void case_UTAPI_006905() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006905",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006905", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006905", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006905", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006905", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006905", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006905", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006905", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006905", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006905", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006905", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006905", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006905")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006906")
    void case_UTAPI_006906() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006906",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006906", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006906", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006906", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006906", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006906", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006906", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006906", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006906", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006906", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006906", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006906", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006906")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006907")
    void case_UTAPI_006907() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006907",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006907", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006907", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006907", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006907", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006907", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006907", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006907", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006907", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006907", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006907", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006907", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006907")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006908")
    void case_UTAPI_006908() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006908",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006908", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006908", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006908", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006908", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006908", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006908", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006908", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006908", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006908", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006908", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006908", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006908")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006909")
    void case_UTAPI_006909() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006909",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006909", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006909", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006909", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006909", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006909", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006909", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006909", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006909", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006909", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006909", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006909", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006909", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006909")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006910")
    void case_UTAPI_006910() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006910",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006910", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006910", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006910", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006910", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006910", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006910", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006910", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006910", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006910", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006910", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006910", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006910", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006910")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006911")
    void case_UTAPI_006911() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006911",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006911", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006911", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006911", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006911", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006911", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006911", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006911", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006911", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006911", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006911", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006911", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006911", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006911")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006912")
    void case_UTAPI_006912() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006912",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006912", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006912", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006912", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006912", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006912", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006912", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006912", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006912", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006912", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006912", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006912", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006912", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006912")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006913")
    void case_UTAPI_006913() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006913",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006913", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006913", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006913", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006913", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006913", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006913", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006913", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006913", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006913", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006913", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006913", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006913", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006913")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006914")
    void case_UTAPI_006914() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006914",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006914", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006914", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006914", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006914", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006914", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006914", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006914", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006914", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006914", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006914", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006914", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006914", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006914")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006915")
    void case_UTAPI_006915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006915",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006915", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006915", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006915", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006915", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006915", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006915", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006915", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006915", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006915", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006915", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006915", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006915", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006915")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006916")
    void case_UTAPI_006916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006916",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006916", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006916", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006916", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006916", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006916", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006916", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006916", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006916", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006916", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006916", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006916", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006916", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006916")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006917")
    void case_UTAPI_006917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006917",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006917", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006917", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006917", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006917", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006917", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006917", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006917", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006917", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006917", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006917", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006917", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006917", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006917")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006918")
    void case_UTAPI_006918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006918",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006918", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006918", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006918", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006918", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006918", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006918", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006918", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006918", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006918", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006918", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006918", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006918", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006918")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006919")
    void case_UTAPI_006919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006919",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006919", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006919", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006919", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006919", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006919", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006919", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006919", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006919", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006919", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006919", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006919", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006919", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006919")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006920")
    void case_UTAPI_006920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006920",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006920", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006920", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006920", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006920", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006920", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006920", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006920", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006920", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006920", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006920", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006920", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006920", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006920")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006921")
    void case_UTAPI_006921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006921",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006921", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006921", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006921", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006921", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006921", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006921", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006921", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006921", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006921", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006921", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006921", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006921", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006921")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006922")
    void case_UTAPI_006922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006922",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006922", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006922", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006922", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006922", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006922", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006922", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006922", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006922", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006922")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006923")
    void case_UTAPI_006923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006923",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006923", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006923", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006923", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006923", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006923", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006923", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006923", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006923", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006923")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006924")
    void case_UTAPI_006924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006924",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006924", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006924", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006924", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006924", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006924", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006924", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006924", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006924", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006924")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006925")
    void case_UTAPI_006925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006925",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006925", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006925", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006925", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006925", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006925", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006925", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006925", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006925", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006925")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006926")
    void case_UTAPI_006926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006926",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006926", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006926", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006926", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006926", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006926", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006926", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006926", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006926", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006926")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006927")
    void case_UTAPI_006927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006927",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006927", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006927", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006927", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006927", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006927", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006927", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006927", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006927", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006927")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006928")
    void case_UTAPI_006928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006928",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006928", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006928", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006928", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006928", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006928", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006928", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006928", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006928", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006928")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006929")
    void case_UTAPI_006929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006929",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006929", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006929", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006929", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006929", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006929", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006929", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006929", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006929", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006929")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006930")
    void case_UTAPI_006930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006930",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006930", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006930", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006930", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006930", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006930", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006930", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006930", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006930")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006931")
    void case_UTAPI_006931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006931",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006931", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006931", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006931", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006931", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006931", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006931", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006931", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006931")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006932")
    void case_UTAPI_006932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006932",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006932", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006932", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006932", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006932", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006932", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006932", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006932", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006932")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006933")
    void case_UTAPI_006933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006933",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006933", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006933", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006933", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006933", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006933", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006933", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006933", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006933")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006934")
    void case_UTAPI_006934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006934",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006934", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006934", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006934", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006934", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006934", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006934", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006934", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006934", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006934")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006935")
    void case_UTAPI_006935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006935",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006935", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006935", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006935", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006935", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006935", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006935", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006935", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006935", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006935")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006936")
    void case_UTAPI_006936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006936",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006936", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006936", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006936", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006936", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006936", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006936", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006936", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006936", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006936")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006937")
    void case_UTAPI_006937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006937",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006937", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006937", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006937", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006937", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006937", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006937", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006937", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006937", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006937")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006938")
    void case_UTAPI_006938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006938",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006938", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006938", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006938", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006938", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006938", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006938", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006938", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006938", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006938")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006939")
    void case_UTAPI_006939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006939",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006939", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006939", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006939", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006939", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006939", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006939", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006939", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006939")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006940")
    void case_UTAPI_006940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006940",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006940", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006940", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006940", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006940", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006940", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006940", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006940", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006940")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006941")
    void case_UTAPI_006941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006941",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006941", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006941", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006941", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006941", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006941", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006941", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006941", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006941", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006941")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006942")
    void case_UTAPI_006942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006942",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006942", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006942", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006942", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006942", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006942", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006942", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006942", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006942", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006942")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006943")
    void case_UTAPI_006943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006943",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006943", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006943", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006943", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006943", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006943", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006943", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006943", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006943", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006943")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006944")
    void case_UTAPI_006944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006944",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006944", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006944", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006944", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006944", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006944", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006944", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006944", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006944", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006944")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006945")
    void case_UTAPI_006945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006945",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006945", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006945", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006945", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006945", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006945", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006945", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006945", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006945", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006945")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006946")
    void case_UTAPI_006946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006946",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006946", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006946", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006946", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006946", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006946", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006946", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006946", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006946", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006946")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006947")
    void case_UTAPI_006947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006947",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006947", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006947", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006947", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006947", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006947", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006947", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006947", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006947", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006947")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006948")
    void case_UTAPI_006948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006948",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006948", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006948", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006948", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006948", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006948", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006948", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006948", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006948", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006948")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006949")
    void case_UTAPI_006949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006949",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006949", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006949", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006949", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006949", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006949", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006949", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006949", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006949", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006949")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006950")
    void case_UTAPI_006950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006950",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006950", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006950", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006950", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006950", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006950", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006950", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006950", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006950", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006950")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006951")
    void case_UTAPI_006951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006951",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006951", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006951", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006951", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006951", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006951", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006951", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006951", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006951")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006952")
    void case_UTAPI_006952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006952",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006952", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006952", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006952", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006952", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006952", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006952", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006952", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006952")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006953")
    void case_UTAPI_006953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006953",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006953", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006953", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006953", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006953", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006953", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006953", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006953", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006953")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006954")
    void case_UTAPI_006954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006954",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006954", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006954", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006954", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006954", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006954", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006954", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006954")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006955")
    void case_UTAPI_006955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006955",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006955", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006955", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006955", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006955", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006955", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006955", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006955")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006956")
    void case_UTAPI_006956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006956",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006956", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006956", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006956", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006956", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006956", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006956", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006956")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006957")
    void case_UTAPI_006957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006957",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006957", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006957", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006957", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006957", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006957", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006957", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006957")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006958")
    void case_UTAPI_006958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006958",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006958", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006958", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006958", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006958", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006958", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006958", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006958")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006959")
    void case_UTAPI_006959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006959",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006959", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006959", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006959", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006959", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006959", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006959", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006959")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006960")
    void case_UTAPI_006960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006960",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006960", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006960", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006960", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006960", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006960", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006960", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006960")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006961")
    void case_UTAPI_006961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006961",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006961", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006961", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006961", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006961", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006961", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006961", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006961", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006961")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006962")
    void case_UTAPI_006962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006962",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006962", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006962", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006962", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006962", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006962", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006962", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006962", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006962")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006963")
    void case_UTAPI_006963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006963",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006963", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006963", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006963", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006963", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006963", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006963", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006963", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006963")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006964")
    void case_UTAPI_006964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006964",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006964", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006964", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006964", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006964", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006964", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006964", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006964", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006964")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006965")
    void case_UTAPI_006965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006965",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006965", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006965", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006965", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006965", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006965", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006965", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006965", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006965")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006966")
    void case_UTAPI_006966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006966",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006966", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006966", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006966", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006966", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006966", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006966", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006966", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006966", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006966")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006967")
    void case_UTAPI_006967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006967",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006967", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006967", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006967", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006967", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006967", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006967", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006967", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006967", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006967")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006968")
    void case_UTAPI_006968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006968",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006968", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006968", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006968", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006968", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006968", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006968", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006968", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006968", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006968")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006969")
    void case_UTAPI_006969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006969",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006969", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006969", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006969", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006969", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006969", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006969", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006969", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006969", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006969")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006970")
    void case_UTAPI_006970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006970",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006970", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006970", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006970", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006970", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006970", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006970", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006970")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006971")
    void case_UTAPI_006971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006971",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006971", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006971", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006971", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006971", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006971", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006971", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006971")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006972")
    void case_UTAPI_006972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006972",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006972", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006972", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006972", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006972", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006972", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006972", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006972")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006973")
    void case_UTAPI_006973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006973",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006973", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006973", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006973", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006973", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006973", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006973", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006973")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006974")
    void case_UTAPI_006974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006974",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006974", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006974", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006974", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006974", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006974", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006974", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006974")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006975")
    void case_UTAPI_006975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006975",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006975", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006975", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006975", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006975", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006975", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006975", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006975")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006976")
    void case_UTAPI_006976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006976",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006976", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006976", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006976", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006976", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006976", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006976", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006976")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006977")
    void case_UTAPI_006977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006977",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006977", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006977", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006977", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006977", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006977", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006977", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006977")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006978")
    void case_UTAPI_006978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006978",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006978", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006978", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006978", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006978", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006978", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006978", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006978")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006979")
    void case_UTAPI_006979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006979",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006979", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006979", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006979", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006979", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006979", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006979", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006979")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006980")
    void case_UTAPI_006980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006980",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006980", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006980", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006980", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006980", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006980", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006980", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006980")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006981")
    void case_UTAPI_006981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006981",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006981", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006981", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006981", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006981", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006981", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006981", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006981")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006982")
    void case_UTAPI_006982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006982",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006982", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006982", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006982", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006982", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006982", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006982", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006982")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006983")
    void case_UTAPI_006983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006983",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006983", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006983", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006983", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006983", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006983", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006983", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006983", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006983")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006984")
    void case_UTAPI_006984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006984",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006984", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006984", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006984", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006984", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006984", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006984", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006984", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006984")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006985")
    void case_UTAPI_006985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006985",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006985", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006985", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006985", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006985", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006985", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006985", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006985", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006985")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006986")
    void case_UTAPI_006986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006986",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006986", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006986", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006986", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006986", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006986", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006986", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006986", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006986")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006987")
    void case_UTAPI_006987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006987",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006987", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006987", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006987", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006987", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006987", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006987", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006987", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006987")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006988")
    void case_UTAPI_006988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006988",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006988", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006988", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006988", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006988", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006988", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006988", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006988", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006988")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006989")
    void case_UTAPI_006989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006989",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006989", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006989", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006989", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006989", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006989", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006989", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006989", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006989")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006990")
    void case_UTAPI_006990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006990",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006990", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006990", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006990", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006990", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006990", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006990", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006990", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006990")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006991")
    void case_UTAPI_006991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006991",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006991", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006991", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006991", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006991", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006991", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006991", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006991", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006991")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "1:length_null", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006992")
    void case_UTAPI_006992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006992",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006992", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006992", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006992", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006992", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006992", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006992", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006992", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006992")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "2:length_empty", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006993")
    void case_UTAPI_006993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006993",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006993", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006993", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006993", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006993", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006993", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006993", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006993", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006993")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "3:length_min", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006994")
    void case_UTAPI_006994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006994",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006994", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006994", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006994", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006994", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006994", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006994", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006994", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006994")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006995")
    void case_UTAPI_006995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006995",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006995", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006995", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006995", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006995", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006995", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006995", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006995")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "5:length_max", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006996")
    void case_UTAPI_006996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006996",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006996", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006996", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006996", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006996", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006996", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006996", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006996")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006997")
    void case_UTAPI_006997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006997",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006997", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006997", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006997", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "rows", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006997", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006997", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006997", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006997")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::4::-::columns")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for columns reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested rows", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.VALUE_REACHED, "the value generated for columns must reach the executed statement unchanged", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006998")
    void case_UTAPI_006998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006998",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006998", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006998", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006998", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006998", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006998", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006998", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006998")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "1:length_null", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006999")
    void case_UTAPI_006999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006999",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006999", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006999", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-006999", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-006999", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-006999", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-006999", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006999", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-006999")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007000")
    void case_UTAPI_007000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007000",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007000", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007000", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-007000", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-007000", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-007000", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-007000", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007000", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007000")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007001")
    void case_UTAPI_007001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007001",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007001", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007001", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-007001", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-007001", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-007001", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-007001", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007001", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007001")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007002")
    void case_UTAPI_007002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007002",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007002", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007002", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-007002", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-007002", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-007002", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-007002", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007002", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007002")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007003")
    void case_UTAPI_007003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007003",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007003", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007003", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-007003", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-007003", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-007003", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-007003", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007003", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007003")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007004")
    void case_UTAPI_007004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007004",
                "com.matsushita.dbeditor.domain.repository.ImportRepository",
                "insertIntoCopyTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("rows", "List<Map<String, Object>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-007004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-007004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-007004", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-007004", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "rows", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-007004", "rows[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-007004", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "rows[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-007004", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-007004", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-007004")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ImportRepository.java::ImportRepository::insertIntoCopyTable::2::ARG::5::-::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for rows reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested columns", "JdbcTemplate", "", "data:columns")
                    .check(CheckType.VALUE_REACHED, "the value generated for rows must reach the executed statement unchanged", "JdbcTemplate", "", "data:rows")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportRepositoryWrapper());
    }

}

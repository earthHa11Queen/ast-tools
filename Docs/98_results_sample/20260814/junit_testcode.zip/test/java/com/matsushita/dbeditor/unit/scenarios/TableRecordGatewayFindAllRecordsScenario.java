package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordGateway#findAllRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordGatewayFindAllRecordsScenario {

    @Test
    @DisplayName("UTAPI-005488")
    void case_UTAPI_005488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005488",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005488", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005488", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005488", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005488")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005489")
    void case_UTAPI_005489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005489",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005489", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005489", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005489", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005489")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005490")
    void case_UTAPI_005490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005490",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005490", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005490", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005490", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005490")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005491")
    void case_UTAPI_005491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005491",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005491", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005491", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005491", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005491")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005492")
    void case_UTAPI_005492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005492",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005492", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005492", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005492", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005492", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005492", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005492")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005493")
    void case_UTAPI_005493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005493",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005493", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005493", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005493", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005493", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005493", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005493", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005493")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005494")
    void case_UTAPI_005494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005494",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005494", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005494", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005494", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005494", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005494", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005494", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005494")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005495")
    void case_UTAPI_005495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005495",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005495", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005495", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005495", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005495", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005495")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005496")
    void case_UTAPI_005496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005496",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005496", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005496", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005496", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005496", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005496", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005496")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005497")
    void case_UTAPI_005497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005497",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005497", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005497", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005497", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005497", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005497")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005498")
    void case_UTAPI_005498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005498",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005498", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005498", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005498", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005498", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005498", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005498")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005499")
    void case_UTAPI_005499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005499",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005499", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005499", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005499", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005499", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005499", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005499")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005500")
    void case_UTAPI_005500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005500",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005500", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005500", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005500", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005500", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005500", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005500")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005501")
    void case_UTAPI_005501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005501",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005501", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005501", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005501", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005501", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005501", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005501")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005502")
    void case_UTAPI_005502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005502",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005502", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005502", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005502", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005502", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005502", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005502")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005503")
    void case_UTAPI_005503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005503",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005503", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005503", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005503", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005503", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005503", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005503")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005504")
    void case_UTAPI_005504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005504",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005504", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005504", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005504", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005504", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005504", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005504")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005505")
    void case_UTAPI_005505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005505",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005505", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005505", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005505", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005505", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005505")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005506")
    void case_UTAPI_005506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005506",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005506", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005506", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005506", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005506", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005506")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005507")
    void case_UTAPI_005507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005507",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005507", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005507", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005507", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005507", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005507")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005508")
    void case_UTAPI_005508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005508",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005508", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005508", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005508", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005508", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005508")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005509")
    void case_UTAPI_005509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005509",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005509", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005509", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005509", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005509", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005509")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005510")
    void case_UTAPI_005510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005510",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005510", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005510", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005510", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005510", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005510")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005511")
    void case_UTAPI_005511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005511",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005511", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005511", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005511", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005511", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005511")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005512")
    void case_UTAPI_005512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005512",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005512", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005512", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005512", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005512", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005512")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005513")
    void case_UTAPI_005513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005513",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005513", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005513", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005513", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005513", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005513")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005514")
    void case_UTAPI_005514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005514",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005514", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005514", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005514", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005514", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005514", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005514")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005515")
    void case_UTAPI_005515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005515",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005515", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005515", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005515", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005515", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005515")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005516")
    void case_UTAPI_005516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005516",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005516", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005516", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005516", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005516")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005517")
    void case_UTAPI_005517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005517",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005517", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005517", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005517", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005517", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005517")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005518")
    void case_UTAPI_005518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005518",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005518", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005518", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005518", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005518", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005518")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005519")
    void case_UTAPI_005519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005519",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005519", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005519", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005519", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005519", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005519", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005519")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005520")
    void case_UTAPI_005520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005520",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005520", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005520", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005520", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005520", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005520", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005520")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005521")
    void case_UTAPI_005521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005521",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005521", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005521", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005521", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005521", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005521", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005521")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005522")
    void case_UTAPI_005522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005522",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005522", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005522", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005522", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005522", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005522", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005522")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005523")
    void case_UTAPI_005523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005523",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005523", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005523", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005523", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005523", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005523", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005523")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005524")
    void case_UTAPI_005524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005524",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005524", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005524", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005524", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005524", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005524", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005524")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005525")
    void case_UTAPI_005525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005525",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005525", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005525", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005525", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005525", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005525", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005525", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005525")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005526")
    void case_UTAPI_005526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005526",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005526", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005526", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005526", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005526", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005526", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005526")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005527")
    void case_UTAPI_005527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005527",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005527", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005527", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005527", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005527", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005527")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005528")
    void case_UTAPI_005528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005528",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005528", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005528", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005528", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005528", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005528")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005529")
    void case_UTAPI_005529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005529",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005529", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005529", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005529", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005529", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005529")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005530")
    void case_UTAPI_005530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005530",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005530", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005530", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005530", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005530", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005530")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005531")
    void case_UTAPI_005531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005531",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005531", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005531", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005531", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005531", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005531")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005532")
    void case_UTAPI_005532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005532",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005532", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005532", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005532", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005532", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005532")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005533")
    void case_UTAPI_005533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005533",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005533", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005533", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005533", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005533", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005533")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005534")
    void case_UTAPI_005534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005534",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005534", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005534", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005534", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005534", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005534")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005535")
    void case_UTAPI_005535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005535",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005535", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005535", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005535", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005535", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005535")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005536")
    void case_UTAPI_005536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005536",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005536", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005536", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005536", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005536")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005537")
    void case_UTAPI_005537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005537",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005537", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005537", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005537", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005537", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005537")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005538")
    void case_UTAPI_005538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005538",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005538", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005538", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005538", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005538", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005538")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005539")
    void case_UTAPI_005539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005539",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005539", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005539", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005539", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005539", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005539", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005539")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005540")
    void case_UTAPI_005540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005540",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005540", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005540", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005540", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005540", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005540", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005540")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005541")
    void case_UTAPI_005541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005541",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005541", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005541", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005541", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005541", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005541", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005541")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005542")
    void case_UTAPI_005542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005542",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005542", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005542", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005542", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005542", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005542", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005542")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005543")
    void case_UTAPI_005543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005543",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005543", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005543", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005543", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005543", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005543", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005543")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005544")
    void case_UTAPI_005544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005544",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005544", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005544", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005544", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005544", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005544", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005544")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005545")
    void case_UTAPI_005545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005545",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005545", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005545", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005545", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005545", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005545", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005545")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005546")
    void case_UTAPI_005546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005546",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005546", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005546", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005546", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005546", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005546")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005547")
    void case_UTAPI_005547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005547",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005547", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005547", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005547", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005547", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005547")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005548")
    void case_UTAPI_005548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005548",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005548", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005548", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005548", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005548", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005548")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005549")
    void case_UTAPI_005549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005549",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005549", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005549", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005549", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005549", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005549")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005550")
    void case_UTAPI_005550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005550",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005550", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005550", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005550", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005550", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005550")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005551")
    void case_UTAPI_005551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005551",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005551", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005551", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005551", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005551", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005551")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005552")
    void case_UTAPI_005552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005552",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005552", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005552", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005552", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005552", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005552")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005553")
    void case_UTAPI_005553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005553",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005553", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005553", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005553", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005553", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005553")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005554")
    void case_UTAPI_005554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005554",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005554", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005554", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005554", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005554")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005555")
    void case_UTAPI_005555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005555",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005555", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005555", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005555", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005555")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005556")
    void case_UTAPI_005556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005556",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005556", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005556", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005556", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005556", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005556")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005557")
    void case_UTAPI_005557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005557",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005557", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005557", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005557", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005557", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005557")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005558")
    void case_UTAPI_005558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005558",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005558", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005558", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005558", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005558", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005558", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005558")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005559")
    void case_UTAPI_005559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005559",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005559", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005559", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005559", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005559", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005559", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005559")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005560")
    void case_UTAPI_005560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005560",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005560", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005560", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005560", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005560", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005560", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005560")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005561")
    void case_UTAPI_005561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005561",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005561", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005561", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005561", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005561", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005561", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005561")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005562")
    void case_UTAPI_005562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005562",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005562", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005562", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005562", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005562", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005562", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005562")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005563")
    void case_UTAPI_005563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005563",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005563", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005563", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005563", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005563", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005563", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005563")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005564")
    void case_UTAPI_005564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005564",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005564", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005564", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005564", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005564", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005564", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005564")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005565")
    void case_UTAPI_005565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005565",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005565", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005565", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005565", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005565", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005565", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005565")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005566")
    void case_UTAPI_005566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005566",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005566", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005566", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005566", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005566", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005566", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005566")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005567")
    void case_UTAPI_005567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005567",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005567", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005567", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005567", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005567")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005568")
    void case_UTAPI_005568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005568",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005568", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005568", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005568", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005568")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005569")
    void case_UTAPI_005569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005569",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005569", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005569", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005569", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005569")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005570")
    void case_UTAPI_005570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005570",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005570", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005570", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005570", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005570")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005571")
    void case_UTAPI_005571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005571",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005571", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005571", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005571", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005571", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005571")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005572")
    void case_UTAPI_005572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005572",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005572", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005572", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005572", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005572", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005572")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005573")
    void case_UTAPI_005573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005573",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005573", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005573", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005573", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005573", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005573")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005574")
    void case_UTAPI_005574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005574",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005574", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005574", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005574", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005574", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005574")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005575")
    void case_UTAPI_005575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005575",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005575", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005575", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005575", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005575", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005575")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005576")
    void case_UTAPI_005576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005576",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005576", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005576", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005576", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005576", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005576")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005577")
    void case_UTAPI_005577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005577",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005577", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005577", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005577", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005577", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005577", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005577", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005577", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005577", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005577", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005577", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005577")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005578")
    void case_UTAPI_005578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005578",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005578", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005578", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005578", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005578", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005578", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005578", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005578", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005578", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005578", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005578", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005578")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005579")
    void case_UTAPI_005579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005579",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005579", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005579", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005579", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005579", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005579", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005579", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005579", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005579", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005579", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005579", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005579")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005580")
    void case_UTAPI_005580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005580",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005580", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005580", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005580", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005580", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005580", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005580", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005580", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005580", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005580", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005580", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005580")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005581")
    void case_UTAPI_005581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005581",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005581", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005581", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005581", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005581", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005581", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005581", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005581", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005581", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005581", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005581", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005581")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005582")
    void case_UTAPI_005582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005582",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005582", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005582", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005582", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005582", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005582", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005582", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005582", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005582", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005582", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005582", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005582")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005583")
    void case_UTAPI_005583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005583",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005583", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005583", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005583", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005583", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005583", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005583", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005583", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005583", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005583", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005583", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005583")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005584")
    void case_UTAPI_005584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005584",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005584", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005584", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005584", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005584", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005584", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005584", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005584", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005584", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005584", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005584", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005584", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005584")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005585")
    void case_UTAPI_005585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005585",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005585", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005585", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005585", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005585", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005585", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005585", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005585", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005585", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005585", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005585", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005585", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005585")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005586")
    void case_UTAPI_005586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005586",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005586", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005586", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005586", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005586", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005586", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005586", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005586", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005586", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005586", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005586", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005586")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005587")
    void case_UTAPI_005587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005587",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005587", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005587", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005587", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005587", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005587", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005587", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005587", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005587", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005587", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005587", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005587")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005588")
    void case_UTAPI_005588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005588",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005588", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005588", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005588", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005588", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005588", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005588", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005588", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005588", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005588", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005588", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005588", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005588")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005589")
    void case_UTAPI_005589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005589",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005589", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005589", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005589", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005589", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005589", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005589", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005589", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005589", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005589", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005589", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005589", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005589")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005590")
    void case_UTAPI_005590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005590",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005590", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005590", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005590", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005590", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005590", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005590", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005590", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005590", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005590", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005590", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005590", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005590", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005590")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005591")
    void case_UTAPI_005591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005591",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005591", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005591", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005591", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005591", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005591", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005591", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005591", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005591", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005591", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005591", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005591", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005591", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005591")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005592")
    void case_UTAPI_005592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005592",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005592", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005592", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005592", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005592", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005592", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005592", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005592", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005592", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005592", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005592", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005592", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005592", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005592")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005593")
    void case_UTAPI_005593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005593",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005593", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005593", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005593", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005593", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005593", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005593", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005593", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005593", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005593", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005593", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005593", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005593", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005593")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005594")
    void case_UTAPI_005594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005594",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005594", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005594", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005594", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005594", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005594", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005594", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005594", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005594", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005594", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005594", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005594", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005594", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005594")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005595")
    void case_UTAPI_005595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005595",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005595", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005595", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005595", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005595", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005595", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005595", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005595", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005595", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005595", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005595", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005595", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005595", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005595")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005596")
    void case_UTAPI_005596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005596",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005596", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005596", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005596", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005596", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005596", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005596", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005596", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005596", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005596", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005596", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005596", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005596", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005596")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005597")
    void case_UTAPI_005597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005597",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005597", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005597", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005597", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005597", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005597", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005597", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005597", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005597", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005597", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005597", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005597", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005597", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005597")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005598")
    void case_UTAPI_005598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005598",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005598", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005598", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005598", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005598", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005598", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005598", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005598", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005598", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005598", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005598", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005598", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005598", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005598")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005599")
    void case_UTAPI_005599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005599",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005599", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005599", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005599", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005599", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005599", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005599", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005599", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005599", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005599", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005599", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005599", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005599", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005599")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005600")
    void case_UTAPI_005600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005600",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005600", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005600", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005600", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005600", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005600", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005600", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005600", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005600", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005600", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005600", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005600", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005600", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005600")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005601")
    void case_UTAPI_005601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005601",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005601", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005601", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005601", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005601", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005601", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005601", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005601", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005601", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005601", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005601", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005601", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005601", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005601")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005602")
    void case_UTAPI_005602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005602",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005602", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005602", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005602", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005602", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005602", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005602", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005602", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005602", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005602", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005602", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005602", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005602")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005603")
    void case_UTAPI_005603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005603",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005603", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005603", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005603", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005603", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005603", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005603", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005603", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005603", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005603", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005603", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005603", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005603")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005604")
    void case_UTAPI_005604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005604",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005604", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005604", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005604", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005604", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005604", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005604", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005604", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005604", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005604", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005604", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005604", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005604")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005605")
    void case_UTAPI_005605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005605",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005605", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005605", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005605", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005605", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005605", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005605", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005605", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005605", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005605", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005605", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005605", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005605")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005606")
    void case_UTAPI_005606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005606",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005606", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005606", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005606", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005606", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005606", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005606", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005606", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005606", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005606", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005606", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005606", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005606")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005607")
    void case_UTAPI_005607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005607",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005607", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005607", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005607", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005607", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005607", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005607", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005607", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005607", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005607", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005607", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005607", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005607")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005608")
    void case_UTAPI_005608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005608",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005608", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005608", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005608", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005608", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005608", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005608", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005608", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005608", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005608", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005608", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005608", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005608")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005609")
    void case_UTAPI_005609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005609",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005609", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005609", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005609", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005609", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005609", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005609", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005609", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005609", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005609", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005609", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005609", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005609")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005610")
    void case_UTAPI_005610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005610",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005610", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005610", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005610", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005610", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005610", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005610", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005610", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005610", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005610", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005610", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005610", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005610")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005611")
    void case_UTAPI_005611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005611",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005611", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005611", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005611", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005611", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005611", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005611", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005611", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005611", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005611", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005611", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005611", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005611")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005612")
    void case_UTAPI_005612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005612",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005612", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005612", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005612", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005612", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005612", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005612", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005612", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005612", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005612", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005612", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005612", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005612")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005613")
    void case_UTAPI_005613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005613",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005613", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005613", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005613", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005613", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005613", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005613", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005613", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005613", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005613", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005613", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005613", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005613")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005614")
    void case_UTAPI_005614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005614",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005614", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005614", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005614", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005614", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005614", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005614", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005614", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005614", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005614", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005614", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005614", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005614")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005615")
    void case_UTAPI_005615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005615",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005615", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005615", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005615", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005615", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005615", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005615", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005615", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005615", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005615", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005615", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005615", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005615")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005616")
    void case_UTAPI_005616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005616",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005616", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005616", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005616", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005616", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005616", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005616", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005616", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005616", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005616", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005616", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005616", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005616")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005617")
    void case_UTAPI_005617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005617",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005617", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005617", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005617", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005617", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005617", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005617", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005617", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005617", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005617", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005617", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005617", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005617")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005618")
    void case_UTAPI_005618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005618",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005618", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005618", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005618", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005618", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005618", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005618", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005618", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005618", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005618", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005618", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005618", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005618")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005619")
    void case_UTAPI_005619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005619",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005619", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005619", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005619", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005619", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005619", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005619", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005619", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005619", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005619", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005619", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005619", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005619")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005620")
    void case_UTAPI_005620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005620",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005620", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005620", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005620", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005620", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005620", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005620", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005620", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005620", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005620", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005620", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005620", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005620", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005620")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005621")
    void case_UTAPI_005621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005621",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005621", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005621", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005621", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005621", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005621", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005621", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005621", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005621", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005621", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005621", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005621", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005621", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005621")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005622")
    void case_UTAPI_005622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005622",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005622", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005622", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005622", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005622", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005622", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005622", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005622", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005622", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005622", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005622", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005622", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005622", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005622")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005623")
    void case_UTAPI_005623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005623",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005623", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005623", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005623", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005623", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005623", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005623", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005623", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005623", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005623", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005623", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005623", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005623", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005623")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005624")
    void case_UTAPI_005624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005624",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005624", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005624", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005624", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005624", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005624", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005624", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005624", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005624", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005624", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005624", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005624", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005624", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005624")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005625")
    void case_UTAPI_005625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005625",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005625", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005625", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005625", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005625", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005625", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005625")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005626")
    void case_UTAPI_005626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005626",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005626", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005626", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005626", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005626", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005626", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005626")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005627")
    void case_UTAPI_005627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005627",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005627", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005627", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005627", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005627", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005627", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005627")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005628")
    void case_UTAPI_005628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005628",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005628", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005628", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005628", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005628", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005628", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005628")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005629")
    void case_UTAPI_005629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005629",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005629", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005629", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005629", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005629", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005629", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005629", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005629")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005630")
    void case_UTAPI_005630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005630",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005630", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005630", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005630", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005630", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005630", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005630")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005631")
    void case_UTAPI_005631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005631",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005631", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005631", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005631", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005631", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005631", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005631")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005632")
    void case_UTAPI_005632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005632",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005632", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005632", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005632", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005632", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005632")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005633")
    void case_UTAPI_005633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005633",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005633", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005633", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005633", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005633", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005633", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005633")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005634")
    void case_UTAPI_005634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005634",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005634", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005634", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005634", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005634", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005634", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005634", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005634")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005635")
    void case_UTAPI_005635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005635",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005635", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005635", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005635", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005635", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005635", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005635", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005635")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005636")
    void case_UTAPI_005636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005636",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005636", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005636", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005636", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005636", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005636", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005636", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005636")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005637")
    void case_UTAPI_005637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005637",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005637", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005637", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005637", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005637", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005637", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005637", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005637")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005638")
    void case_UTAPI_005638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005638",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005638", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005638", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005638", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005638", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005638", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005638")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005639")
    void case_UTAPI_005639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005639",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005639", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005639", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005639", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005639", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005639", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005639")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005640")
    void case_UTAPI_005640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005640",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005640", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005640", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005640", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005640", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005640")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005641")
    void case_UTAPI_005641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005641",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005641", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005641", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005641", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005641", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005641")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005642")
    void case_UTAPI_005642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005642",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005642", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005642", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005642", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005642", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005642")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005643")
    void case_UTAPI_005643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005643",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005643", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005643", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005643", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005643", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005643")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005644")
    void case_UTAPI_005644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005644",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005644", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005644", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005644", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005644", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005644")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005645")
    void case_UTAPI_005645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005645",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005645", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005645", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005645", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005645", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005645")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005646")
    void case_UTAPI_005646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005646",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005646", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005646", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005646", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005646", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005646")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005647")
    void case_UTAPI_005647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005647",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005647", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005647", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005647", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005647", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005647")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005648")
    void case_UTAPI_005648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005648",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005648", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005648", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005648", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005648", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005648")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005649")
    void case_UTAPI_005649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005649",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005649", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005649", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005649", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005649", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005649")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005650")
    void case_UTAPI_005650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005650",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005650", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005650", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005650", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005650", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005650", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005650")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005651")
    void case_UTAPI_005651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005651",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005651", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005651", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005651", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005651", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005651", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005651")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005652")
    void case_UTAPI_005652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005652",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005652", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005652", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005652", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005652", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005652", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005652")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005653")
    void case_UTAPI_005653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005653",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005653", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005653", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005653", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005653", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005653", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005653")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005654")
    void case_UTAPI_005654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005654",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005654", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005654", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005654", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005654", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005654", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005654", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005654")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005655")
    void case_UTAPI_005655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005655",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005655", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005655", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005655", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005655", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005655", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005655", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005655")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005656")
    void case_UTAPI_005656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005656",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005656", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005656", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005656", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005656", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005656", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005656", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005656")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005657")
    void case_UTAPI_005657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005657",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005657", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005657", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005657", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005657", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005657", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005657")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005658")
    void case_UTAPI_005658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005658",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005658", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005658", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005658", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005658", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005658", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005658")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005659")
    void case_UTAPI_005659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005659",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005659", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005659", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005659", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005659", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005659")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005660")
    void case_UTAPI_005660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005660",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005660", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005660", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005660", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005660", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005660")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005661")
    void case_UTAPI_005661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005661",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005661", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005661", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005661", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005661", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005661")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005662")
    void case_UTAPI_005662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005662",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005662", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005662", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005662", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005662", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005662")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005663")
    void case_UTAPI_005663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005663",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005663", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005663", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005663", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005663", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005663")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005664")
    void case_UTAPI_005664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005664",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005664", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005664", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005664", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005664", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005664")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005665")
    void case_UTAPI_005665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005665",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005665", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005665", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005665", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005665", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005665")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005666")
    void case_UTAPI_005666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005666",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005666", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005666", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005666", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005666", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005666")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005667")
    void case_UTAPI_005667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005667",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005667", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005667", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005667", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005667", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005667")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005668")
    void case_UTAPI_005668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005668",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005668", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005668", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005668", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005668", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005668")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005669")
    void case_UTAPI_005669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005669",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005669", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005669", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005669", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005669", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005669")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005670")
    void case_UTAPI_005670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005670",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findAllRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005670", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005670", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005670", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005670", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005670")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findAllRecords::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

}

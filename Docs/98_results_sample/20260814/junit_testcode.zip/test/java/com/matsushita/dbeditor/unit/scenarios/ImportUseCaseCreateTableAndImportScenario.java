package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#createTableAndImport.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseCreateTableAndImportScenario {

    @Test
    @DisplayName("UTAPI-012327")
    void case_UTAPI_012327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012327",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012327", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012327", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012327", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012327", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012327", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012327", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012327", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012327", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012327", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012327", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012327", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012327")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012328")
    void case_UTAPI_012328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012328",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012328", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012328", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012328", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012328", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012328", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012328", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012328", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012328", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012328", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012328", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012328", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012328")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012329")
    void case_UTAPI_012329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012329",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012329", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012329", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012329", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012329", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012329", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012329", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012329", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012329", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012329", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012329", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012329", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012329")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012330")
    void case_UTAPI_012330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012330",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012330", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012330", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012330", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012330", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012330", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012330", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012330", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012330", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012330", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012330", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012330", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012330")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012331")
    void case_UTAPI_012331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012331",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012331", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012331", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012331", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012331", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012331", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012331", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012331", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012331", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012331", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012331", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012331", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012331")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012332")
    void case_UTAPI_012332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012332",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012332", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012332", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012332", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012332", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012332", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012332", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012332", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012332", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012332", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012332", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012332", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012332")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012333")
    void case_UTAPI_012333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012333",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012333", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012333", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012333", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012333", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012333", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012333", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012333", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012333", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012333", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012333", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012333", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012333")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012334")
    void case_UTAPI_012334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012334",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012334", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012334", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012334", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012334", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012334", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012334", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012334", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012334", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012334", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012334", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012334", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012334")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012335")
    void case_UTAPI_012335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012335",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012335", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012335", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012335", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012335", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012335", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012335", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012335", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012335", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012335", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012335", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012335", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012335")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012336")
    void case_UTAPI_012336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012336",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012336", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012336", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012336", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012336", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012336", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012336", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012336", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012336", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012336", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012336", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012336", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012336")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012337")
    void case_UTAPI_012337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012337",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012337", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012337", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012337", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012337", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012337", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012337", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012337", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012337", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012337", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012337", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012337", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012337")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012338")
    void case_UTAPI_012338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012338",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012338", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012338", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012338", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012338", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012338", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012338", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012338", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012338", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012338", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012338", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012338", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012338")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012339")
    void case_UTAPI_012339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012339",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012339", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012339", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012339", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012339", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012339", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012339", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012339", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012339", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012339", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012339", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012339", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012339")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012340")
    void case_UTAPI_012340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012340",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012340", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012340", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012340", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012340", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012340", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012340", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012340", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012340", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012340", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012340", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012340", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012340")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012341")
    void case_UTAPI_012341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012341",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012341", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012341", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012341", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012341", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012341", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012341", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012341", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012341", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012341", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012341", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012341", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012341")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012342")
    void case_UTAPI_012342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012342",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012342", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012342", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012342", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012342", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012342", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012342", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012342", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012342", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012342", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012342", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012342", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012342")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012343")
    void case_UTAPI_012343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012343",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012343", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012343", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012343", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012343", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012343", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012343", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012343", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012343", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012343", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012343", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012343", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012343")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012344")
    void case_UTAPI_012344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012344",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012344", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012344", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012344", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012344", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012344", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012344", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012344", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012344", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012344", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012344", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012344", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012344")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012345")
    void case_UTAPI_012345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012345",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012345", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012345", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012345", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012345", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012345", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012345", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012345", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012345", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012345", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012345", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012345", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012345")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012346")
    void case_UTAPI_012346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012346",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012346", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012346", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012346", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012346", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012346", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012346", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012346", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012346", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012346", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012346", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012346", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012346")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012347")
    void case_UTAPI_012347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012347",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012347", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012347", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012347", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012347", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012347", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012347", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012347", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012347", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012347", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012347", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012347", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012347")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012348")
    void case_UTAPI_012348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012348",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012348", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012348", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012348", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012348", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012348", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012348", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012348", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012348", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012348", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012348", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012348", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012348")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012349")
    void case_UTAPI_012349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012349",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012349", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012349", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012349", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012349", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012349", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012349", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012349", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012349", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012349", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012349", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012349", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012349")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012350")
    void case_UTAPI_012350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012350",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012350", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012350", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012350", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012350", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012350", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012350", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012350", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012350", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012350", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012350", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012350", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012350")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012351")
    void case_UTAPI_012351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012351",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012351", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012351", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012351", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012351", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012351", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012351", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012351", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012351", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012351", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012351", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012351", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012351")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012352")
    void case_UTAPI_012352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012352",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012352", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012352", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012352", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012352", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012352", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012352", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012352", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012352", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012352", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012352", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012352", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012352")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012353")
    void case_UTAPI_012353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012353",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012353", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012353", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012353", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012353", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012353", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012353", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012353", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012353", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012353", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012353", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012353", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012353")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012354")
    void case_UTAPI_012354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012354",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012354", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012354", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012354", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012354", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012354", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012354", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012354", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012354", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012354", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012354", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012354", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012354")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012355")
    void case_UTAPI_012355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012355",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012355", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012355", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012355", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012355", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012355", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012355", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012355", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012355", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012355", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012355", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012355", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012355")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012356")
    void case_UTAPI_012356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012356",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012356", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012356", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012356", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012356", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012356", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012356", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012356", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012356", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012356", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012356", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012356", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012356")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012357")
    void case_UTAPI_012357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012357",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012357", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012357", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012357", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012357", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012357", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012357", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012357", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012357", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012357", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012357", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012357", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012357")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012358")
    void case_UTAPI_012358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012358",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012358", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012358", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012358", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012358", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012358", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012358", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012358", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012358", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012358", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012358", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012358", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012358")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012359")
    void case_UTAPI_012359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012359",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012359", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012359", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012359", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012359", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012359", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012359", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012359", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012359", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012359", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012359", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012359", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012359")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012360")
    void case_UTAPI_012360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012360",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012360", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012360", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012360", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012360", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012360", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012360", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012360", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012360", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012360", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012360", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012360", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012360")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012361")
    void case_UTAPI_012361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012361",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012361", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012361", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012361", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012361", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012361", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012361", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012361", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012361", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012361", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012361", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012361", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012361")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012362")
    void case_UTAPI_012362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012362",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012362", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012362", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012362", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012362", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012362", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012362", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012362", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012362", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012362", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012362", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012362", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012362")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012363")
    void case_UTAPI_012363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012363",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012363", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012363", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012363", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012363", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012363", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012363", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012363", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012363", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012363", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012363", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012363", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012363")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012364")
    void case_UTAPI_012364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012364",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012364", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012364", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012364", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012364", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012364", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012364", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012364", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012364", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012364", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012364", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012364", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012364")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012365")
    void case_UTAPI_012365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012365",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012365", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012365", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012365", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012365", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012365", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012365", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012365", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012365", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012365", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012365", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012365", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012365")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012366")
    void case_UTAPI_012366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012366",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012366", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012366", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012366", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012366", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012366", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012366", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012366", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012366", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012366", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012366", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012366", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012366")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012367")
    void case_UTAPI_012367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012367",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012367", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012367", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012367", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012367", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012367", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012367", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012367", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012367", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012367", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012367", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012367", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012367")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012368")
    void case_UTAPI_012368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012368",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012368", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012368", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012368", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012368", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012368", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012368", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012368", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012368", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012368", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012368", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012368", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012368")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012369")
    void case_UTAPI_012369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012369",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012369", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012369", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012369", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012369", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012369", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012369", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012369", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012369", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012369", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012369", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012369", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012369")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012370")
    void case_UTAPI_012370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012370",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012370", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012370", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012370", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012370", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012370", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012370", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012370", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012370", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012370", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012370", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012370", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012370")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012371")
    void case_UTAPI_012371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012371",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012371", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012371", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012371", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012371", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012371", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012371", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012371", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012371", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012371", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012371", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012371", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012371")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012372")
    void case_UTAPI_012372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012372",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012372", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012372", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012372", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012372", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012372", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012372", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012372", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012372", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012372", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012372", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012372", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012372")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012373")
    void case_UTAPI_012373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012373",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012373", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012373", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012373", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012373", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012373", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012373", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012373", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012373", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012373", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012373", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012373", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012373")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012374")
    void case_UTAPI_012374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012374",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012374", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012374", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012374", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012374", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012374", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012374", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012374", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012374", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012374", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012374", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012374", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012374")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012375")
    void case_UTAPI_012375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012375",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012375", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012375", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012375", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012375", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012375", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012375", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012375", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012375", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012375", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012375", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012375", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012375")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012376")
    void case_UTAPI_012376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012376",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012376", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012376", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012376", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012376", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012376", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012376", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012376", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012376", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012376", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012376", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012376", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012376")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012377")
    void case_UTAPI_012377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012377",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012377", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012377", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012377", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012377", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012377", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012377", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012377", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012377", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012377", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012377", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012377", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012377")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012378")
    void case_UTAPI_012378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012378",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012378", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012378", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012378", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012378", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012378", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012378", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012378", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012378", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012378", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012378", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012378", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012378")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012379")
    void case_UTAPI_012379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012379",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012379", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012379", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012379", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012379", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012379", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012379", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012379", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012379", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012379", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012379", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012379", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012379")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::3::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012380")
    void case_UTAPI_012380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012380",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012380", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012380", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012380", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012380", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012380", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012380", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012380", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012380", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012380", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012380", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012380", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012380")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "1:length_null", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012381")
    void case_UTAPI_012381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012381",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012381", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012381", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012381", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012381", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012381", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012381", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012381", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012381", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012381", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012381", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012381", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012381")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "2:length_empty", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012382")
    void case_UTAPI_012382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012382",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012382", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012382", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012382", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012382", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012382", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012382", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012382", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012382", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012382", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012382", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012382", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012382")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "3:length_min", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012383")
    void case_UTAPI_012383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012383",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012383", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012383", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012383", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012383", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012383", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012383", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012383", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012383", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012383", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012383", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012383", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012383")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012384")
    void case_UTAPI_012384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012384",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012384", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012384", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012384", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012384", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012384", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012384", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012384", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012384", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012384", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012384", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012384", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012384")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "5:length_max", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012385")
    void case_UTAPI_012385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012385",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012385", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012385", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012385", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012385", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012385", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012385", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012385", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012385", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012385", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012385", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012385", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012385")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012386")
    void case_UTAPI_012386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012386",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012386", "columns", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012386", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012386", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012386", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012386", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012386", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012386", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012386", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012386", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012386", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012386", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012386")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::4::-::columns")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("columns", "columns")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columns is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columns entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "3", "data:columns")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012387")
    void case_UTAPI_012387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012387",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012387", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012387", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012387", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012387", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012387", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012387", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012387", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012387", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012387", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012387", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012387", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012387")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "1:length_null", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012388")
    void case_UTAPI_012388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012388",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012388", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012388", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012388", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012388", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012388", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012388", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012388", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012388", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012388", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012388", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012388", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012388")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "2:length_empty", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012389")
    void case_UTAPI_012389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012389",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012389", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012389", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012389", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012389", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012389", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012389", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012389", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012389", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012389", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012389", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012389", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012389")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "3:length_min", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012390")
    void case_UTAPI_012390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012390",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012390", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012390", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012390", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012390", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012390", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012390", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012390", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012390", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012390", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012390", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012390", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012390")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012391")
    void case_UTAPI_012391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012391",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012391", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012391", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012391", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012391", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012391", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012391", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012391", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012391", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012391", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012391", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012391", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012391")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "5:length_max", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012392")
    void case_UTAPI_012392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012392",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012392", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012392", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012392", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012392", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012392", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012392", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012392", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012392", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012392", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012392", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012392", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012392")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012393")
    void case_UTAPI_012393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012393",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012393", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012393", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012393", "columnTypes", "TARGET", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012393", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012393", "rows", "NORMAL", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012393", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012393", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012393", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012393", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012393", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012393", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012393")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::5::-::columnTypes")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("columnTypes", "columnTypes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for columnTypes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied columnTypes entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "4", "data:columnTypes")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012394")
    void case_UTAPI_012394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012394",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012394", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012394", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012394", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012394", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012394", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012394", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012394", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012394", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012394", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012394", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012394", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012394")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "1:length_null", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012395")
    void case_UTAPI_012395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012395",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012395", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012395", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012395", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012395", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012395", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012395", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012395", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012395", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012395", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012395", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012395", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012395")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "2:length_empty", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012396")
    void case_UTAPI_012396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012396",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012396", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012396", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012396", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012396", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012396", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012396", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012396", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012396", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012396", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012396", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012396", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012396")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "3:length_min", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012397")
    void case_UTAPI_012397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012397",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012397", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012397", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012397", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012397", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012397", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012397", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012397", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012397", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012397", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012397", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012397", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012397")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012398")
    void case_UTAPI_012398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012398",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012398", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012398", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012398", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012398", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012398", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012398", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012398", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012398", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012398", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012398", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012398", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012398")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "5:length_max", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012399")
    void case_UTAPI_012399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012399",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012399", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012399", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012399", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012399", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012399", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012399", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012399", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012399", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012399", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012399", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012399", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012399")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012400")
    void case_UTAPI_012400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012400",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "createTableAndImport",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("columns", "List<String>", "columns"),
                    new ParamSpec("columnTypes", "List<String>", "columnTypes"),
                    new ParamSpec("rows", "List<Map<String, String>>", "rows")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012400", "columns", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012400", "columns[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012400", "columnTypes", "NORMAL", "COLLECTION", "List<String>"),
                    new DataRef("UTAPI-012400", "columnTypes[]", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012400", "rows", "TARGET", "COLLECTION", "List<Map<String, String>>"),
                    new DataRef("UTAPI-012400", "rows[]", "NORMAL", "MAP", "Map<String, String>"),
                    new DataRef("UTAPI-012400", "rows[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012400", "rows[]{value}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012400", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012400", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012400", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012400")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::createTableAndImport::5::ARG::6::-::rows")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("rows", "rows")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of importRepository.createTableAndInsert")
                    .expected("the value generated for rows is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importRepository.createTableAndInsert", "importRepository", "createTableAndInsert")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importRepository.createTableAndInsert must carry the value generated for schemaName", "importRepository", "createTableAndInsert", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importRepository.createTableAndInsert must carry the value generated for tableName", "importRepository", "createTableAndInsert", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SIZE_EQUALS_VALUE, "every supplied rows entry must be forwarded to the table creation", "importRepository", "createTableAndInsert", "5", "data:rows")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

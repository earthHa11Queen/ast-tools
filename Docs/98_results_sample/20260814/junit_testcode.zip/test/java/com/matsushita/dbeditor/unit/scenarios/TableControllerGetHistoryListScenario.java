package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#getHistoryList.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerGetHistoryListScenario {

    @Test
    @DisplayName("UTAPI-001420")
    void case_UTAPI_001420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001420",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001420", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001420", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001420", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001420")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001421")
    void case_UTAPI_001421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001421",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001421", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001421", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001421", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001421")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001422")
    void case_UTAPI_001422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001422",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001422", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001422", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001422", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001422")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001423")
    void case_UTAPI_001423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001423",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001423", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001423", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001423", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001423")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001424")
    void case_UTAPI_001424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001424",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001424", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001424", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001424", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001424")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001425")
    void case_UTAPI_001425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001425",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001425", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001425", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001425", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001425")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001426")
    void case_UTAPI_001426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001426",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001426", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001426", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001426", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001426")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001427")
    void case_UTAPI_001427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001427",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001427", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001427", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001427", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001427")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001428")
    void case_UTAPI_001428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001428",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001428", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001428", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001428", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001428")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001429")
    void case_UTAPI_001429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001429",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001429", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001429", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001429", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001429")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001430")
    void case_UTAPI_001430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001430",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001430", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001430", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001430", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001430")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001431")
    void case_UTAPI_001431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001431",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001431", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001431", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001431", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001431")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001432")
    void case_UTAPI_001432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001432",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001432", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001432", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001432", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001432")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001433")
    void case_UTAPI_001433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001433",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001433", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001433", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001433", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001433")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001434")
    void case_UTAPI_001434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001434",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001434", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001434", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001434", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001434")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001435")
    void case_UTAPI_001435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001435",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001435", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001435", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001435", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001435")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001436")
    void case_UTAPI_001436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001436",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001436", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001436", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001436", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001436")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001437")
    void case_UTAPI_001437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001437",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001437", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001437", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001437", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001437")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001438")
    void case_UTAPI_001438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001438",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001438", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001438", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001438", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001438")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001439")
    void case_UTAPI_001439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001439",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001439", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001439", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001439", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001439")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001440")
    void case_UTAPI_001440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001440",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001440", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001440", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001440", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001440")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001441")
    void case_UTAPI_001441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001441",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001441", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001441", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001441", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001441")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001442")
    void case_UTAPI_001442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001442",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001442", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001442", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001442", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001442")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001443")
    void case_UTAPI_001443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001443",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001443", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001443", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001443", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001443")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001444")
    void case_UTAPI_001444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001444",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001444", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001444", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001444", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001444")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001445")
    void case_UTAPI_001445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001445",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001445", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001445", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001445", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001445")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001446")
    void case_UTAPI_001446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001446",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001446", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001446", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001446", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001446")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001447")
    void case_UTAPI_001447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001447",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001447", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001447", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001447", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001447")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001448")
    void case_UTAPI_001448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001448",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001448", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001448", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001448", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001448")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001449")
    void case_UTAPI_001449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001449",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001449", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001449", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001449", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001449")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001450")
    void case_UTAPI_001450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001450",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001450", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001450", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001450", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001450")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001451")
    void case_UTAPI_001451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001451",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001451", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001451", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001451", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001451")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001452")
    void case_UTAPI_001452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001452",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001452", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001452", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001452", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001452")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001453")
    void case_UTAPI_001453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001453",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001453", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001453", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001453", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001453")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001454")
    void case_UTAPI_001454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001454",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001454", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001454", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001454", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001454")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001455")
    void case_UTAPI_001455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001455",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001455", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001455", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001455", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001455")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001456")
    void case_UTAPI_001456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001456",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001456", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001456", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001456", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001456")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001457")
    void case_UTAPI_001457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001457",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001457", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001457", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001457", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001457")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001458")
    void case_UTAPI_001458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001458",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001458", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001458", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001458", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001458")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001459")
    void case_UTAPI_001459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001459",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001459", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001459", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001459", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001459")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001460")
    void case_UTAPI_001460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001460",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001460", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001460", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001460", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001460")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001461")
    void case_UTAPI_001461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001461",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001461", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001461", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001461", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001461")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001462")
    void case_UTAPI_001462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001462",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001462", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001462", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001462", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001462")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001463")
    void case_UTAPI_001463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001463",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001463", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001463", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001463", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001463")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001464")
    void case_UTAPI_001464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001464",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001464", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001464", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001464", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001464")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001465")
    void case_UTAPI_001465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001465",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001465", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001465", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001465", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001465")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001466")
    void case_UTAPI_001466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001466",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001466", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001466", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001466", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001466")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001467")
    void case_UTAPI_001467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001467",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001467", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001467", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001467", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001467")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001468")
    void case_UTAPI_001468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001468",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001468", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001468", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001468", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001468")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001469")
    void case_UTAPI_001469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001469",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001469", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001469", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001469", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001469")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001470")
    void case_UTAPI_001470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001470",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001470", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001470", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001470", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001470")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001471")
    void case_UTAPI_001471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001471",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getHistoryList",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001471", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001471", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001471", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001471")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getHistoryList::8::ARG::3::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.getHistoryList")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.getHistoryList", "tableHistoryUseCase", "getHistoryList")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.getHistoryList must carry the value generated for connectionId", "tableHistoryUseCase", "getHistoryList", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.getHistoryList must carry the value generated for schema", "tableHistoryUseCase", "getHistoryList", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.getHistoryList must carry the value generated for name", "tableHistoryUseCase", "getHistoryList", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#splitCsvLine.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseSplitCsvLineScenario {

    @Test
    @DisplayName("UTAPI-012557")
    void case_UTAPI_012557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012557",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012557", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012557")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "1:length_null", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012558")
    void case_UTAPI_012558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012558",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012558", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012558")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "2:length_empty", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012559")
    void case_UTAPI_012559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012559",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012559", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012559")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "3:length_min", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012560")
    void case_UTAPI_012560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012560",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012560", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012560")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012561")
    void case_UTAPI_012561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012561",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012561", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012561")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "5:length_max", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012562")
    void case_UTAPI_012562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012562",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012562", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012562")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012563")
    void case_UTAPI_012563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012563",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012563", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012563")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012564")
    void case_UTAPI_012564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012564",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012564", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012564")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012565")
    void case_UTAPI_012565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012565",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012565", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012565")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012566")
    void case_UTAPI_012566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012566",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012566", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012566")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012567")
    void case_UTAPI_012567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012567",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012567", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012567")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012568")
    void case_UTAPI_012568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012568",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012568", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012568")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012569")
    void case_UTAPI_012569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012569",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012569", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012569")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "56:space")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012570")
    void case_UTAPI_012570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012570",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012570", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012570")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012571")
    void case_UTAPI_012571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012571",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012571", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012571")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012572")
    void case_UTAPI_012572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012572",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012572", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012572")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "59:tab")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012573")
    void case_UTAPI_012573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012573",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012573", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012573")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "60:control_character_null")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012574")
    void case_UTAPI_012574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012574",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012574", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012574")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012575")
    void case_UTAPI_012575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012575",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012575", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012575")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012576")
    void case_UTAPI_012576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012576",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "splitCsvLine",
                "String[]",
                new ParamSpec[] {
                    new ParamSpec("line", "String", "line")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012576", "line", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012576")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::splitCsvLine::9::ARG::1::-::line")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("line", "line")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the fields produced for the supplied line")
                    .expected("every character of an unquoted line survives the split")
                    .failure("characters are dropped, fields are merged, or null fields appear")
                    .assertion("assert the comma joined fields reproduce the supplied line for unquoted input")
                    .check(CheckType.NO_EXCEPTION, "splitting must accept this line condition")
                    .check(CheckType.RETURN_NOT_NULL, "splitting must produce fields")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no field may be lost as null")
                    .check(CheckType.CSV_SPLIT_ROUNDTRIP, "an unquoted line must be recoverable from its fields", "data:line")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

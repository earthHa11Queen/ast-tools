package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlUseCase#uploadSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlUseCaseUploadSqlScenario {

    @Test
    @DisplayName("UTAPI-012967")
    void case_UTAPI_012967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012967",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012967", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012967", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012967", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012967", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012967")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012968")
    void case_UTAPI_012968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012968",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012968", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012968", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012968", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012968", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012968")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012969")
    void case_UTAPI_012969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012969",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012969", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012969", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012969", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012969", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012969")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012970")
    void case_UTAPI_012970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012970",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012970", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012970", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012970", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012970", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012970")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012971")
    void case_UTAPI_012971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012971",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012971", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012971", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012971", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012971", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012971")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012972")
    void case_UTAPI_012972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012972",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012972", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012972", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012972", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012972", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012972")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012973")
    void case_UTAPI_012973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012973",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012973", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012973", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012973", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012973", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012973")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012974")
    void case_UTAPI_012974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012974",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012974", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012974", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012974", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012974", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012974")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012975")
    void case_UTAPI_012975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012975",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012975", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012975", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012975", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012975", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012975")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012976")
    void case_UTAPI_012976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012976",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012976", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012976", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012976", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012976", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012976")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012977")
    void case_UTAPI_012977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012977",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012977", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012977", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012977", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012977", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012977")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012978")
    void case_UTAPI_012978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012978",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012978", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012978", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012978", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012978", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012978")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "1:length_null", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012979")
    void case_UTAPI_012979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012979",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012979", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012979", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012979", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012979", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012979")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "2:length_empty", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012980")
    void case_UTAPI_012980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012980",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012980", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012980", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012980", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012980", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012980")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "3:length_min", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012981")
    void case_UTAPI_012981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012981",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012981", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012981", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012981", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012981", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012981")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012982")
    void case_UTAPI_012982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012982",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012982", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012982", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012982", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012982", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012982")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "5:length_max", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012983")
    void case_UTAPI_012983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012983",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012983", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012983", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012983", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012983", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012983")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012984")
    void case_UTAPI_012984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012984",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012984", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012984", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012984", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012984", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012984")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012985")
    void case_UTAPI_012985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012985",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012985", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012985", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012985", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012985", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012985")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012986")
    void case_UTAPI_012986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012986",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012986", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012986", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012986", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012986", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012986")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012987")
    void case_UTAPI_012987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012987",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012987", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012987", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012987", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012987", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012987")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012988")
    void case_UTAPI_012988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012988",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012988", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012988", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012988", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012988", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012988")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012989")
    void case_UTAPI_012989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012989",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012989", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012989", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012989", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012989", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012989")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012990")
    void case_UTAPI_012990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012990",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012990", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012990", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012990", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012990", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012990")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012991")
    void case_UTAPI_012991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012991",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012991", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012991", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012991", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012991", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012991")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "56:space")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012992")
    void case_UTAPI_012992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012992",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012992", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012992", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012992", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012992", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012992")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012993")
    void case_UTAPI_012993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012993",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012993", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012993", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012993", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012993", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012993")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012994")
    void case_UTAPI_012994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012994",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012994", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012994", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012994", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012994", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012994")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "59:tab")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012995")
    void case_UTAPI_012995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012995",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012995", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012995", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012995", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012995", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012995")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "60:control_character_null")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012996")
    void case_UTAPI_012996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012996",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012996", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012996", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012996", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012996", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012996")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012997")
    void case_UTAPI_012997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012997",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012997", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012997", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012997", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012997", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012997")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012998")
    void case_UTAPI_012998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012998",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012998", "bytes", "NORMAL", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012998", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012998", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012998", "filename", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012998")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::2::-::filename")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("filename", "filename")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for filename is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012999")
    void case_UTAPI_012999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012999",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012999", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-012999", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-012999", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012999", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012999")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "1:length_null", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013000")
    void case_UTAPI_013000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013000",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013000", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-013000", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-013000", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013000", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013000")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "2:length_empty", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013001")
    void case_UTAPI_013001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013001",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013001", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-013001", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-013001", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013001", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013001")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "3:length_min", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013002")
    void case_UTAPI_013002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013002",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013002", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-013002", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-013002", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013002", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013002")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013003")
    void case_UTAPI_013003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013003",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013003", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-013003", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-013003", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013003", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013003")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "5:length_max", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013004")
    void case_UTAPI_013004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013004",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013004", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-013004", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-013004", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013004", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013004")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013005")
    void case_UTAPI_013005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013005",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "uploadSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("filename", "String", "filename"),
                    new ParamSpec("bytes", "byte[]", "bytes")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013005", "bytes", "TARGET", "COLLECTION", "byte[]"),
                    new DataRef("UTAPI-013005", "bytes[]", "NORMAL", "NUMBER", "byte"),
                    new DataRef("UTAPI-013005", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013005", "filename", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013005")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::uploadSql::5::ARG::3::-::bytes")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("bytes", "bytes")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for bytes is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql must be the uploaded content decoded from bytes", "savedSqlRepository", "save", "0", "getContentSql", "utf8:bytes")
                    .check(CheckType.ARG_FIELD_RELATED_TEXT, "getTitleSql must be derived from filename", "savedSqlRepository", "save", "0", "getTitleSql", "data:filename")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

}

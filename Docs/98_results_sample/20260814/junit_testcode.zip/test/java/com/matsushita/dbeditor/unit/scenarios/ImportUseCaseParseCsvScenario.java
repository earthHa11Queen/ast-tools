package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#parseCsv.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseParseCsvScenario {

    @Test
    @DisplayName("UTAPI-012555")
    void case_UTAPI_012555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012555",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "parseCsv",
                "List<String[]>",
                new ParamSpec[] {
                    new ParamSpec("is", "InputStream", "is")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012555", "is", "TARGET", "OBJECT", "InputStream")
                },
                OraclePlan.builder("UTAPI-012555")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::parseCsv::8::ARG::1::-::is")
                    .mirror("-", "1:length_null", "-")
                    .target("is", "is")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the outcome of parsing a missing stream")
                    .expected("parsing fails instead of pretending an empty document")
                    .failure("a missing stream is silently treated as an empty document")
                    .assertion("assertThrows for the missing stream")
                    .check(CheckType.EXCEPTION_REQUIRED, "a missing stream cannot be parsed", "java.lang.Exception", "data:is")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012556")
    void case_UTAPI_012556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012556",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "parseCsv",
                "List<String[]>",
                new ParamSpec[] {
                    new ParamSpec("is", "InputStream", "is")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012556", "is", "TARGET", "OBJECT", "InputStream")
                },
                OraclePlan.builder("UTAPI-012556")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::parseCsv::8::ARG::1::-::is")
                    .mirror("-", "2:length_empty", "-")
                    .target("is", "is")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.CSV_FIELD_PRESERVATION)
                    .observation("the row list produced for the supplied stream")
                    .expected("parsing succeeds and produces a well formed row list")
                    .failure("parsing fails or produces null rows")
                    .assertion("assertNotNull and per element assertion on the row list")
                    .check(CheckType.NO_EXCEPTION, "an empty document must be parsed, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "parsing must produce a row list")
                    .check(CheckType.RETURN_SIZE_EQUALS, "an empty document must yield no rows", "0", "data:is")
                    .check(CheckType.RETURN_NO_NULL_ELEMENTS, "no row may be null")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

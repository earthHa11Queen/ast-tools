package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TemplateController.
 */
public final class TemplateControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.TemplateController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.TemplateController";
    private static final String[] DEP_NAMES = new String[] {"templateUseCase"};
    private static final String[] DEP_TYPES = new String[] {"TemplateUseCase"};
    private static final String[] TYPES_deleteMemoTemplate = new String[] {"Integer"};
    private static final String[] TYPES_deleteSqlTemplate = new String[] {"Integer"};
    private static final String[] TYPES_listMemoTemplates = new String[] {};
    private static final String[] TYPES_listSqlTemplates = new String[] {};
    private static final String[] TYPES_saveMemoTemplate = new String[] {"TemplateRequest"};
    private static final String[] TYPES_saveSqlTemplate = new String[] {"TemplateRequest"};

    public TemplateControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<Void> deleteMemoTemplate(n) */
    public ExecutionResult deleteMemoTemplate(Object[] args) {
        return invoke("deleteMemoTemplate", TYPES_deleteMemoTemplate, args);
    }

    /** ResponseEntity<Void> deleteSqlTemplate(n) */
    public ExecutionResult deleteSqlTemplate(Object[] args) {
        return invoke("deleteSqlTemplate", TYPES_deleteSqlTemplate, args);
    }

    /** ResponseEntity<List<TemplateResponse>> listMemoTemplates() */
    public ExecutionResult listMemoTemplates(Object[] args) {
        return invoke("listMemoTemplates", TYPES_listMemoTemplates, args);
    }

    /** ResponseEntity<List<TemplateResponse>> listSqlTemplates() */
    public ExecutionResult listSqlTemplates(Object[] args) {
        return invoke("listSqlTemplates", TYPES_listSqlTemplates, args);
    }

    /** ResponseEntity<TemplateResponse> saveMemoTemplate(request) */
    public ExecutionResult saveMemoTemplate(Object[] args) {
        return invoke("saveMemoTemplate", TYPES_saveMemoTemplate, args);
    }

    /** ResponseEntity<TemplateResponse> saveSqlTemplate(request) */
    public ExecutionResult saveSqlTemplate(Object[] args) {
        return invoke("saveSqlTemplate", TYPES_saveSqlTemplate, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("deleteMemoTemplate".equals(operation)) {
            return deleteMemoTemplate(args);
        } else if ("deleteSqlTemplate".equals(operation)) {
            return deleteSqlTemplate(args);
        } else if ("listMemoTemplates".equals(operation)) {
            return listMemoTemplates(args);
        } else if ("listSqlTemplates".equals(operation)) {
            return listSqlTemplates(args);
        } else if ("saveMemoTemplate".equals(operation)) {
            return saveMemoTemplate(args);
        } else if ("saveSqlTemplate".equals(operation)) {
            return saveSqlTemplate(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

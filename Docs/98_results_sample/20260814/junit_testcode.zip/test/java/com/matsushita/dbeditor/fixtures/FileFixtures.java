package com.matsushita.dbeditor.fixtures;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Uploaded file content used when a target method declares a file parameter.
 *
 * <p>These bytes are not Mirror test values. The Mirror target of such Cases is always a
 * different parameter or DTO field, and the file only has to be a well formed carrier so the
 * declared collaborator contract can be observed.</p>
 */
public final class FileFixtures {

    private FileFixtures() {
    }

    public static final String CSV_HEADER_A = "COL_A";
    public static final String CSV_HEADER_B = "COL_B";
    public static final String CSV_CELL_A = "VAL_A1";
    public static final String CSV_CELL_B = "VAL_B1";
    public static final String SHEET_NAME = "SHEET1";

    private static byte[] xlsxCache;

    public static byte[] csvBytes() {
        String csv = CSV_HEADER_A + "," + CSV_HEADER_B + "\r\n" + CSV_CELL_A + "," + CSV_CELL_B + "\r\n";
        return csv.getBytes(StandardCharsets.UTF_8);
    }

    public static byte[] emptyBytes() {
        return new byte[0];
    }

    public static synchronized byte[] xlsxBytes() {
        if (xlsxCache != null) {
            return xlsxCache.clone();
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            ZipOutputStream zip = new ZipOutputStream(out);
            put(zip, "[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "</Types>");
            put(zip, "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                + "</Relationships>");
            put(zip, "xl/workbook.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\""
                + " xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                + "<sheets><sheet name=\"" + SHEET_NAME + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            put(zip, "xl/_rels/workbook.xml.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
                + "</Relationships>");
            put(zip, "xl/styles.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"1\"><fill><patternFill patternType=\"none\"/></fill></fills>"
                + "<borders count=\"1\"><border/></borders>"
                + "<cellStyleXfs count=\"1\"><xf/></cellStyleXfs>"
                + "<cellXfs count=\"1\"><xf xfId=\"0\"/></cellXfs>"
                + "</styleSheet>");
            put(zip, "xl/worksheets/sheet1.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"
                + "<row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>" + CSV_HEADER_A + "</t></is></c>"
                + "<c r=\"B1\" t=\"inlineStr\"><is><t>" + CSV_HEADER_B + "</t></is></c></row>"
                + "<row r=\"2\"><c r=\"A2\" t=\"inlineStr\"><is><t>" + CSV_CELL_A + "</t></is></c>"
                + "<c r=\"B2\" t=\"inlineStr\"><is><t>" + CSV_CELL_B + "</t></is></c></row>"
                + "</sheetData></worksheet>");
            zip.close();
        } catch (Exception e) {
            throw new HarnessException("Cannot build workbook fixture", e);
        }
        xlsxCache = out.toByteArray();
        return xlsxCache.clone();
    }

    private static void put(ZipOutputStream zip, String name, String content) throws java.io.IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }
}

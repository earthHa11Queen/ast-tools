package com.matsushita.dbeditor.utils;

import com.matsushita.dbeditor.unit.wrappers.SutWrapper;

/**
 * Common execution flow for one validated CaseNo.
 *
 * <p>Input values are obtained from TestDataRuntime, the SUT operation is executed through
 * the Wrapper, and the Oracle Plan of the Case decides PASS or FAIL. The flow is shared, the
 * judgement is not: every Case supplies its own Oracle Plan.</p>
 */
public final class CaseExecutor {

    private CaseExecutor() {
    }

    public static void execute(CaseDefinition def, SutWrapper wrapper) {
        boolean excelFlavour = def.methodName().toLowerCase().contains("excel");
        try {
            wrapper.setUp();
            Arguments args = ArgumentAssembly.build(def, wrapper.registry(), def.plan().mirrorY(), excelFlavour);
            ExecutionResult result = wrapper.execute(def.methodName(), args.values());
            CaseOracle.verify(def, wrapper, args, result);
        } finally {
            wrapper.close();
        }
    }
}

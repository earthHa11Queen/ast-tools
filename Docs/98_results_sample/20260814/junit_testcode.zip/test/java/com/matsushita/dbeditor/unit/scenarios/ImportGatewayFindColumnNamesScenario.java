package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportGateway#findColumnNames.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportGatewayFindColumnNamesScenario {

    @Test
    @DisplayName("UTAPI-002449")
    void case_UTAPI_002449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002449",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002449", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002449", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002449", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002449", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002449", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002449", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002449")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002450")
    void case_UTAPI_002450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002450",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002450", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002450", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002450", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002450", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002450", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002450", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002450")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002451")
    void case_UTAPI_002451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002451",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002451", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002451", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002451", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002451", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002451", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002451")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002452")
    void case_UTAPI_002452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002452",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002452", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002452", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002452", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002452", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002452", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002452")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002453")
    void case_UTAPI_002453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002453",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002453", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002453", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002453", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002453", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002453", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002453")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002454")
    void case_UTAPI_002454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002454",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002454", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002454", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002454", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002454", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002454", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002454")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002455")
    void case_UTAPI_002455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002455",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002455", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002455", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002455", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002455", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002455", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002455")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002456")
    void case_UTAPI_002456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002456",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002456", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002456", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002456", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002456", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002456", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002456")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002457")
    void case_UTAPI_002457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002457",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002457", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002457", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002457", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002457", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002457", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002457")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002458")
    void case_UTAPI_002458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002458",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002458", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002458", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002458", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002458", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002458", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002458")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002459")
    void case_UTAPI_002459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002459",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002459", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002459", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002459", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002459", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002459", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002459")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002460")
    void case_UTAPI_002460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002460",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002460", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002460", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002460", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002460", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002460", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002460")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002461")
    void case_UTAPI_002461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002461",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002461", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002461", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002461", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002461", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002461", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002461")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002462")
    void case_UTAPI_002462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002462",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002462", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002462", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002462", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002462", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002462", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002462", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002462")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002463")
    void case_UTAPI_002463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002463",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002463", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002463", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002463", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002463", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002463", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002463", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002463")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002464")
    void case_UTAPI_002464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002464",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002464", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002464", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002464", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002464", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002464", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002464")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002465")
    void case_UTAPI_002465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002465",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002465", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002465", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002465", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002465", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002465", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002465")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002466")
    void case_UTAPI_002466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002466",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002466", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002466", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002466", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002466", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002466", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002466", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002466")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002467")
    void case_UTAPI_002467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002467",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002467", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002467", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002467", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002467", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002467", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002467", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002467")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002468")
    void case_UTAPI_002468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002468",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002468", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002468", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002468", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002468", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002468", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002468", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002468")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002469")
    void case_UTAPI_002469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002469",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002469", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002469", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002469", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002469", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002469", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002469", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002469")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002470")
    void case_UTAPI_002470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002470",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002470", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002470", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002470", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002470", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002470", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002470", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002470")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002471")
    void case_UTAPI_002471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002471",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002471", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002471", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002471", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002471", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002471", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002471", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002471")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002472")
    void case_UTAPI_002472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002472",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002472", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002472", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002472", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002472", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002472", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002472", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002472")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002473")
    void case_UTAPI_002473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002473",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002473", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002473", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002473", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002473", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002473", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002473", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002473")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002474")
    void case_UTAPI_002474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002474",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002474", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002474", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002474", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002474", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002474", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002474")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002475")
    void case_UTAPI_002475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002475",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002475", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002475", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002475", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002475", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002475", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002475")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002476")
    void case_UTAPI_002476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002476",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002476", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002476", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002476", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002476", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002476", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002476")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002477")
    void case_UTAPI_002477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002477",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002477", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002477", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002477", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002477", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002477", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002477")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002478")
    void case_UTAPI_002478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002478",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002478", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002478", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002478", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002478", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002478", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002478", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002478")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002479")
    void case_UTAPI_002479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002479",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002479", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002479", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002479", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002479", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002479", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002479", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002479")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002480")
    void case_UTAPI_002480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002480",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002480", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002480", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002480", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002480", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002480", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002480", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002480")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002481")
    void case_UTAPI_002481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002481",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002481", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002481", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002481", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002481", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002481", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002481", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002481")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002482")
    void case_UTAPI_002482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002482",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002482", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002482", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002482", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002482", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002482", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002482", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002482", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002482")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002483")
    void case_UTAPI_002483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002483",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002483", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002483", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002483", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002483", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002483", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002483", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002483", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002483")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002484")
    void case_UTAPI_002484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002484",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002484", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002484", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002484", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002484", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002484", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002484", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002484")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002485")
    void case_UTAPI_002485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002485",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002485", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002485", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002485", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002485", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002485", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002485", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002485")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002486")
    void case_UTAPI_002486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002486",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002486", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002486", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002486", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002486", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002486", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002486", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002486")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002487")
    void case_UTAPI_002487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002487",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002487", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002487", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002487", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002487", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002487", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002487", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002487")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002488")
    void case_UTAPI_002488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002488",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002488", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002488", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002488", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002488", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002488", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002488")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002489")
    void case_UTAPI_002489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002489",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002489", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002489", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002489", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002489", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002489", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002489")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002490")
    void case_UTAPI_002490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002490",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002490", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002490", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002490", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002490", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002490", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002490")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002491")
    void case_UTAPI_002491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002491",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002491", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002491", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002491", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002491", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002491", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002491")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002492")
    void case_UTAPI_002492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002492",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002492", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002492", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002492", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002492", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002492", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002492", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002492", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002492", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002492", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002492", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002492", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002492", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002492")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002493")
    void case_UTAPI_002493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002493",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002493", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002493", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002493", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002493", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002493", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002493", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002493", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002493", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002493", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002493", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002493", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002493", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002493")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002494")
    void case_UTAPI_002494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002494",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002494", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002494", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002494", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002494", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002494", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002494", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002494", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002494", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002494", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002494", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002494", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002494", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002494")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002495")
    void case_UTAPI_002495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002495",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002495", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002495", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002495", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002495", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002495", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002495", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002495", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002495", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002495", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002495", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002495", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002495", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002495")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002496")
    void case_UTAPI_002496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002496",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002496", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002496", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002496", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002496", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002496", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002496", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002496", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002496", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002496", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002496", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002496", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002496", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002496")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002497")
    void case_UTAPI_002497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002497",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002497", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002497", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002497", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002497", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002497")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002498")
    void case_UTAPI_002498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002498",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002498", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002498", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002498", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002498", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002498", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002498")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002499")
    void case_UTAPI_002499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002499",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002499", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002499", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002499", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002499", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002499", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002499")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002500")
    void case_UTAPI_002500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002500",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002500", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002500", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002500", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002500", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002500", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002500")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002501")
    void case_UTAPI_002501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002501",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002501", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002501", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002501", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002501", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002501", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002501")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002502")
    void case_UTAPI_002502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002502",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002502", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002502", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002502", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002502", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002502", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002502")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002503")
    void case_UTAPI_002503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002503",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002503", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002503", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002503", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002503", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002503", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002503")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002504")
    void case_UTAPI_002504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002504",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002504", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002504", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002504", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002504", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002504", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002504")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002505")
    void case_UTAPI_002505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002505",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002505", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002505", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002505", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002505", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002505")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002506")
    void case_UTAPI_002506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002506",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002506", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002506", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002506", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002506", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002506")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002507")
    void case_UTAPI_002507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002507",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002507", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002507", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002507", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002507", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002507")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002508")
    void case_UTAPI_002508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002508",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002508", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002508", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002508", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002508", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002508")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002509")
    void case_UTAPI_002509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002509",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002509", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002509", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002509", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002509", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002509")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002510")
    void case_UTAPI_002510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002510",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002510", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002510", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002510", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002510", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002510")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002511")
    void case_UTAPI_002511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002511",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002511", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002511", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002511", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002511", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002511")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002512")
    void case_UTAPI_002512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002512",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002512", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002512", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002512", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002512", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002512")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002513")
    void case_UTAPI_002513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002513",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002513", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002513", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002513", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002513", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002513")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002514")
    void case_UTAPI_002514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002514",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002514", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002514", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002514", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002514", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002514", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002514")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002515")
    void case_UTAPI_002515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002515",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002515", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002515", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002515", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002515", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002515")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002516")
    void case_UTAPI_002516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002516",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002516", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002516", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002516", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002516")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002517")
    void case_UTAPI_002517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002517",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002517", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002517", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002517", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002517", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002517")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002518")
    void case_UTAPI_002518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002518",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002518", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002518", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002518", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002518", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002518")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002519")
    void case_UTAPI_002519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002519",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002519", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002519", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002519", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002519", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002519", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002519")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002520")
    void case_UTAPI_002520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002520",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002520", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002520", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002520", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002520", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002520", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002520")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002521")
    void case_UTAPI_002521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002521",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002521", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002521", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002521", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002521", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002521", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002521")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002522")
    void case_UTAPI_002522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002522",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002522", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002522", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002522", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002522", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002522", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002522")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002523")
    void case_UTAPI_002523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002523",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002523", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002523", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002523", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002523", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002523", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002523")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002524")
    void case_UTAPI_002524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002524",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002524", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002524", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002524", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002524", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002524", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002524")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002525")
    void case_UTAPI_002525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002525",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002525", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002525", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002525", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002525", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002525", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002525", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002525")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002526")
    void case_UTAPI_002526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002526",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002526", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002526", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002526", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002526", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002526", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002526")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002527")
    void case_UTAPI_002527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002527",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002527", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002527", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002527", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002527", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002527")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002528")
    void case_UTAPI_002528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002528",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002528", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002528", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002528", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002528", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002528")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002529")
    void case_UTAPI_002529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002529",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002529", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002529", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002529", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002529", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002529")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002530")
    void case_UTAPI_002530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002530",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002530", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002530", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002530", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002530", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002530")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002531")
    void case_UTAPI_002531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002531",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002531", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002531", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002531", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002531", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002531")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002532")
    void case_UTAPI_002532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002532",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002532", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002532", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002532", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002532", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002532")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002533")
    void case_UTAPI_002533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002533",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002533", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002533", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002533", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002533", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002533")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002534")
    void case_UTAPI_002534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002534",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002534", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002534", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002534", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002534", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002534")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002535")
    void case_UTAPI_002535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002535",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002535", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002535", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002535", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002535", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002535")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002536")
    void case_UTAPI_002536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002536",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002536", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002536", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002536", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002536")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002537")
    void case_UTAPI_002537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002537",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002537", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002537", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002537", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002537", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002537")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002538")
    void case_UTAPI_002538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002538",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002538", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002538", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002538", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002538", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002538")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002539")
    void case_UTAPI_002539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002539",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002539", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002539", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002539", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002539", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002539", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002539")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002540")
    void case_UTAPI_002540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002540",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002540", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002540", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002540", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002540", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002540", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002540")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002541")
    void case_UTAPI_002541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002541",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002541", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002541", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002541", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002541", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002541", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002541")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002542")
    void case_UTAPI_002542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002542",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002542", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002542", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002542", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002542", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002542", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002542")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002543")
    void case_UTAPI_002543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002543",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002543", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002543", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002543", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002543", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002543", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002543")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002544")
    void case_UTAPI_002544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002544",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002544", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002544", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002544", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002544", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002544", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002544")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002545")
    void case_UTAPI_002545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002545",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002545", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002545", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002545", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002545", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002545", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002545")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002546")
    void case_UTAPI_002546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002546",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002546", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002546", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002546", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002546", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002546")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002547")
    void case_UTAPI_002547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002547",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002547", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002547", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002547", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002547", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002547")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002548")
    void case_UTAPI_002548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002548",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002548", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002548", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002548", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002548", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002548")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002549")
    void case_UTAPI_002549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002549",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002549", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002549", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002549", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002549", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002549")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002550")
    void case_UTAPI_002550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002550",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002550", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002550", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002550", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002550", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002550")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002551")
    void case_UTAPI_002551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002551",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002551", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002551", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002551", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002551", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002551")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002552")
    void case_UTAPI_002552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002552",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002552", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002552", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002552", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002552", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002552")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002553")
    void case_UTAPI_002553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002553",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002553", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002553", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002553", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002553", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002553")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002554")
    void case_UTAPI_002554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002554",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002554", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002554", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002554", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002554")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002555")
    void case_UTAPI_002555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002555",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002555", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002555", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002555", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002555")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002556")
    void case_UTAPI_002556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002556",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002556", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002556", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002556", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002556", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002556")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002557")
    void case_UTAPI_002557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002557",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002557", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002557", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002557", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002557", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002557")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002558")
    void case_UTAPI_002558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002558",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002558", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002558", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002558", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002558", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002558", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002558")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002559")
    void case_UTAPI_002559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002559",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002559", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002559", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002559", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002559", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002559", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002559")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002560")
    void case_UTAPI_002560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002560",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002560", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002560", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002560", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002560", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002560", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002560")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002561")
    void case_UTAPI_002561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002561",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002561", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002561", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002561", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002561", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002561", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002561")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002562")
    void case_UTAPI_002562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002562",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002562", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002562", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002562", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002562", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002562", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002562")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002563")
    void case_UTAPI_002563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002563",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002563", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002563", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002563", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002563", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002563", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002563")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002564")
    void case_UTAPI_002564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002564",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002564", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002564", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002564", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002564", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002564", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002564")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002565")
    void case_UTAPI_002565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002565",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002565", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002565", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002565", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002565", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002565", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002565")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002566")
    void case_UTAPI_002566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002566",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002566", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002566", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002566", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002566", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002566", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002566")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002567")
    void case_UTAPI_002567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002567",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002567", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002567", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002567", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002567")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002568")
    void case_UTAPI_002568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002568",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002568", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002568", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002568", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002568")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002569")
    void case_UTAPI_002569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002569",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002569", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002569", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002569", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002569")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002570")
    void case_UTAPI_002570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002570",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002570", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002570", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002570", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002570")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002571")
    void case_UTAPI_002571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002571",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002571", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002571", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002571", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002571", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002571")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002572")
    void case_UTAPI_002572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002572",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002572", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002572", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002572", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002572", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002572")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002573")
    void case_UTAPI_002573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002573",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002573", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002573", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002573", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002573", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002573")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002574")
    void case_UTAPI_002574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002574",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002574", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002574", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002574", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002574", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002574")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002575")
    void case_UTAPI_002575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002575",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002575", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002575", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002575", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002575", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002575")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002576")
    void case_UTAPI_002576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002576",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002576", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002576", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002576", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002576", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002576")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002577")
    void case_UTAPI_002577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002577",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002577", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002577", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002577", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002577", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002577", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002577", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002577", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002577", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002577", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002577", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002577")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002578")
    void case_UTAPI_002578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002578",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002578", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002578", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002578", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002578", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002578", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002578", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002578", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002578", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002578", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002578", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002578")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002579")
    void case_UTAPI_002579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002579",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002579", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002579", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002579", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002579", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002579", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002579", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002579", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002579", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002579", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002579", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002579")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002580")
    void case_UTAPI_002580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002580",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002580", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002580", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002580", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002580", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002580", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002580", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002580", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002580", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002580", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002580", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002580")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002581")
    void case_UTAPI_002581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002581",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002581", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002581", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002581", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002581", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002581", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002581", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002581", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002581", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002581", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002581", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002581")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002582")
    void case_UTAPI_002582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002582",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002582", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002582", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002582", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002582", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002582", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002582", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002582", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002582", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002582", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002582", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002582")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002583")
    void case_UTAPI_002583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002583",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002583", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002583", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002583", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002583", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002583", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002583", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002583", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002583", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002583", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002583", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002583")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002584")
    void case_UTAPI_002584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002584",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002584", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002584", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002584", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002584", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002584", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002584", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002584", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002584", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002584", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002584", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002584", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002584")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002585")
    void case_UTAPI_002585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002585",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002585", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002585", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002585", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002585", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002585", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002585", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002585", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002585", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002585", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002585", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002585", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002585")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002586")
    void case_UTAPI_002586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002586",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002586", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002586", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002586", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002586", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002586", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002586", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002586", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002586", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002586", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002586", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002586")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002587")
    void case_UTAPI_002587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002587",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002587", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002587", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002587", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002587", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002587", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002587", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002587", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002587", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002587", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002587", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002587")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002588")
    void case_UTAPI_002588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002588",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002588", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002588", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002588", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002588", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002588", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002588", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002588", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002588", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002588", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002588", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002588", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002588")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002589")
    void case_UTAPI_002589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002589",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002589", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002589", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002589", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002589", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002589", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002589", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002589", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002589", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002589", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002589", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002589", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002589")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002590")
    void case_UTAPI_002590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002590",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002590", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002590", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002590", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002590", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002590", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002590", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002590", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002590", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002590", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002590", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002590", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002590", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002590")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002591")
    void case_UTAPI_002591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002591",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002591", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002591", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002591", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002591", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002591", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002591", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002591", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002591", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002591", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002591", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002591", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002591", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002591")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002592")
    void case_UTAPI_002592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002592",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002592", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002592", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002592", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002592", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002592", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002592", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002592", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002592", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002592", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002592", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002592", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002592", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002592")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002593")
    void case_UTAPI_002593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002593",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002593", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002593", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002593", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002593", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002593", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002593", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002593", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002593", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002593", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002593", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002593", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002593", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002593")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002594")
    void case_UTAPI_002594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002594",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002594", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002594", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002594", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002594", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002594", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002594", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002594", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002594", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002594", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002594", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002594", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002594", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002594")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002595")
    void case_UTAPI_002595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002595",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002595", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002595", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002595", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002595", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002595", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002595", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002595", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002595", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002595", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002595", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002595", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002595", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002595")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002596")
    void case_UTAPI_002596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002596",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002596", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002596", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002596", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002596", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002596", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002596", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002596", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002596", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002596", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002596", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002596", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002596", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002596")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002597")
    void case_UTAPI_002597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002597",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002597", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002597", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002597", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002597", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002597", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002597", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002597", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002597", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002597", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002597", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002597", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002597", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002597")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002598")
    void case_UTAPI_002598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002598",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002598", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002598", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002598", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002598", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002598", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002598", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002598", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002598", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002598", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002598", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002598", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002598", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002598")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002599")
    void case_UTAPI_002599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002599",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002599", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002599", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002599", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002599", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002599", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002599", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002599", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002599", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002599", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002599", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002599", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002599", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002599")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002600")
    void case_UTAPI_002600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002600",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002600", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002600", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002600", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002600", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002600", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002600", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002600", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002600", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002600", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002600", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002600", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002600", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002600")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002601")
    void case_UTAPI_002601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002601",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002601", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002601", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002601", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002601", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002601", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002601", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002601", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002601", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002601", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002601", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002601", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002601", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002601")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002602")
    void case_UTAPI_002602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002602",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002602", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002602", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002602", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002602", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002602", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002602", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002602", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002602", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002602", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002602", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002602", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002602")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002603")
    void case_UTAPI_002603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002603",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002603", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002603", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002603", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002603", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002603", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002603", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002603", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002603", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002603", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002603", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002603", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002603")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002604")
    void case_UTAPI_002604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002604",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002604", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002604", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002604", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002604", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002604", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002604", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002604", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002604", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002604", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002604", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002604", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002604")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002605")
    void case_UTAPI_002605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002605",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002605", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002605", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002605", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002605", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002605", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002605", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002605", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002605", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002605", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002605", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002605", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002605")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002606")
    void case_UTAPI_002606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002606",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002606", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002606", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002606", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002606", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002606", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002606", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002606", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002606", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002606", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002606", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002606", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002606")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002607")
    void case_UTAPI_002607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002607",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002607", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002607", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002607", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002607", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002607", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002607", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002607", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002607", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002607", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002607", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002607", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002607")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002608")
    void case_UTAPI_002608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002608",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002608", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002608", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002608", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002608", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002608", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002608", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002608", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002608", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002608", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002608", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002608", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002608")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002609")
    void case_UTAPI_002609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002609",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002609", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002609", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002609", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002609", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002609", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002609", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002609", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002609", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002609", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002609", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002609", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002609")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002610")
    void case_UTAPI_002610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002610",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002610", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002610", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002610", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002610", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002610", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002610", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002610", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002610", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002610", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002610", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002610", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-002610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002610")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002611")
    void case_UTAPI_002611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002611",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002611", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002611", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002611", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002611", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002611", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002611", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002611", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002611", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002611", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002611", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002611", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002611", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002611")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002612")
    void case_UTAPI_002612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002612",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002612", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002612", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002612", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002612", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002612", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002612", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002612", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002612", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002612", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002612", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002612", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002612", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002612")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002613")
    void case_UTAPI_002613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002613",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002613", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002613", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002613", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002613", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002613", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002613", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002613", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002613", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002613", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002613", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002613", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002613", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002613")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002614")
    void case_UTAPI_002614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002614",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002614", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002614", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002614", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002614", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002614", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002614", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002614", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002614", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002614", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002614", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002614", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002614", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002614")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002615")
    void case_UTAPI_002615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002615",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002615", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002615", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002615", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002615", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002615", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002615", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002615", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002615", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002615", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002615", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002615", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002615", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002615")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002616")
    void case_UTAPI_002616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002616",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002616", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002616", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002616", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002616", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002616", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002616", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002616", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002616", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002616", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002616", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002616", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002616", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002616")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002617")
    void case_UTAPI_002617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002617",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002617", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002617", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002617", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002617", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002617", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002617", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002617", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002617", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002617", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002617", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002617", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002617", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002617")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002618")
    void case_UTAPI_002618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002618",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002618", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002618", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002618", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002618", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002618", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002618", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002618", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002618", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002618", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002618", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002618", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002618", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002618")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002619")
    void case_UTAPI_002619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002619",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002619", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002619", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002619", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002619", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002619", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002619", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002619", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002619", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002619", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002619", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002619", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002619", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002619")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002620")
    void case_UTAPI_002620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002620",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002620", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002620", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002620", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002620", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002620", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002620", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002620", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002620", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002620", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002620", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002620", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002620", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002620")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002621")
    void case_UTAPI_002621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002621",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002621", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002621", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002621", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002621", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002621", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002621", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002621", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002621", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002621", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002621", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002621", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002621", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002621")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002622")
    void case_UTAPI_002622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002622",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002622", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002622", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002622", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002622", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002622", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002622", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002622", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002622", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002622", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002622", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002622", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002622", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002622")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002623")
    void case_UTAPI_002623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002623",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002623", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002623", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002623", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002623", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002623", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002623", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002623", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002623", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002623", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002623", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002623", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002623", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002623")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002624")
    void case_UTAPI_002624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002624",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002624", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002624", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002624", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002624", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002624", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002624", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002624", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002624", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002624", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002624", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002624", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002624", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002624")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002625")
    void case_UTAPI_002625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002625",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002625", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002625", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002625", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002625", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002625", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002625", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002625")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002626")
    void case_UTAPI_002626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002626",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002626", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002626", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002626", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002626", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002626", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002626", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002626")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002627")
    void case_UTAPI_002627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002627",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002627", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002627", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002627", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002627", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002627", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002627", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002627")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002628")
    void case_UTAPI_002628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002628",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002628", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002628", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002628", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002628", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002628", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002628")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002629")
    void case_UTAPI_002629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002629",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002629", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002629", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002629", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002629", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002629", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002629", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002629")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002630")
    void case_UTAPI_002630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002630",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002630", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002630", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002630", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002630", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002630", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002630")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002631")
    void case_UTAPI_002631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002631",
                "com.matsushita.dbeditor.adapter.gateway.ImportGateway",
                "findColumnNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-002631", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002631", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-002631", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-002631", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-002631", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-002631")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/ImportGateway.java::ImportGateway::findColumnNames::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportGatewayWrapper());
    }

}

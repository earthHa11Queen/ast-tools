package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoTemplateRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoTemplateRepository#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoTemplateRepositoryDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-007005")
    void case_UTAPI_007005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007005",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007005", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007005")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007006")
    void case_UTAPI_007006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007006",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007006", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007006")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007007")
    void case_UTAPI_007007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007007",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007007", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007007")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007008")
    void case_UTAPI_007008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007008",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007008", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007008")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007009")
    void case_UTAPI_007009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007009",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007009", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007009")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007010")
    void case_UTAPI_007010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007010",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007010", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007010")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007011")
    void case_UTAPI_007011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007011",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007011", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007011")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007012")
    void case_UTAPI_007012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007012",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007012", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007012")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007013")
    void case_UTAPI_007013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007013",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007013", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007013")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007014")
    void case_UTAPI_007014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007014",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007014", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007014")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-007015")
    void case_UTAPI_007015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-007015",
                "com.matsushita.dbeditor.domain.repository.MemoTemplateRepository",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-007015", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-007015")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/MemoTemplateRepository.java::MemoTemplateRepository::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoUseCase#saveMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoUseCaseSaveMemoScenario {

    @Test
    @DisplayName("UTAPI-012641")
    void case_UTAPI_012641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012641",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012641", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012641", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012641", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012641")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012642")
    void case_UTAPI_012642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012642",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012642", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012642", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012642", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012642")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012643")
    void case_UTAPI_012643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012643",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012643", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012643", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012643", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012643")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012644")
    void case_UTAPI_012644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012644",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012644", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012644", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012644", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012644")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012645")
    void case_UTAPI_012645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012645",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012645", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012645", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012645", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012645")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012646")
    void case_UTAPI_012646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012646",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012646", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012646", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012646", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012646")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012647")
    void case_UTAPI_012647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012647",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012647", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012647", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012647", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012647")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012648")
    void case_UTAPI_012648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012648",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012648", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012648", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012648", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012648")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012649")
    void case_UTAPI_012649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012649",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012649", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012649", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012649", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012649")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012650")
    void case_UTAPI_012650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012650",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012650", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012650", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012650", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012650")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012651")
    void case_UTAPI_012651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012651",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012651", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012651", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012651", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012651")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012652")
    void case_UTAPI_012652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012652",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012652", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012652", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012652", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012652")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012653")
    void case_UTAPI_012653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012653",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012653", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012653", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012653", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012653")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012654")
    void case_UTAPI_012654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012654",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012654", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012654", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012654", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012654")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012655")
    void case_UTAPI_012655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012655",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012655", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012655", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012655", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012655")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012656")
    void case_UTAPI_012656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012656",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012656", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012656", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012656", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012656")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012657")
    void case_UTAPI_012657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012657",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012657", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012657", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012657", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012657")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012658")
    void case_UTAPI_012658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012658",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012658", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012658", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012658", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012658")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012659")
    void case_UTAPI_012659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012659",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012659", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012659", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012659", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012659")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012660")
    void case_UTAPI_012660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012660",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012660", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012660", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012660", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012660")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012661")
    void case_UTAPI_012661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012661",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012661", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012661", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012661", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012661")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012662")
    void case_UTAPI_012662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012662",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012662", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012662", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012662", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012662")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012663")
    void case_UTAPI_012663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012663",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012663", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012663", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012663", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012663")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012664")
    void case_UTAPI_012664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012664",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012664", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012664", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012664", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012664")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012665")
    void case_UTAPI_012665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012665",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012665", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012665", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012665", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012665")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012666")
    void case_UTAPI_012666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012666",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012666", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012666", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012666", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012666")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012667")
    void case_UTAPI_012667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012667",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012667", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012667", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012667", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012667")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012668")
    void case_UTAPI_012668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012668",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012668", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012668", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012668", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012668")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012669")
    void case_UTAPI_012669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012669",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012669", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012669", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012669", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012669")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012670")
    void case_UTAPI_012670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012670",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012670", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012670", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012670", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012670")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012671")
    void case_UTAPI_012671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012671",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012671", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012671", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012671", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012671")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012672")
    void case_UTAPI_012672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012672",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012672", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012672", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012672", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012672")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::2::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012673")
    void case_UTAPI_012673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012673",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012673", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012673", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012673", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012673")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "1:length_null", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012674")
    void case_UTAPI_012674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012674",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012674", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012674", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012674", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012674")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012675")
    void case_UTAPI_012675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012675",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012675", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012675", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012675", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012675")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "3:length_min", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012676")
    void case_UTAPI_012676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012676",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012676", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012676", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012676", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012676")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012677")
    void case_UTAPI_012677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012677",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012677", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012677", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012677", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012677")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "5:length_max", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012678")
    void case_UTAPI_012678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012678",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012678", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012678", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012678", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012678")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012679")
    void case_UTAPI_012679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012679",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012679", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012679", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012679", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012679")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012680")
    void case_UTAPI_012680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012680",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012680", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012680", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012680", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012680")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012681")
    void case_UTAPI_012681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012681",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012681", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012681", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012681", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012681")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012682")
    void case_UTAPI_012682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012682",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012682", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012682", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012682", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012682")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012683")
    void case_UTAPI_012683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012683",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012683", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012683", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012683", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012683")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012684")
    void case_UTAPI_012684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012684",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012684", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012684", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012684", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012684")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012685")
    void case_UTAPI_012685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012685",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012685", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012685", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012685", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012685")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "56:space")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012686")
    void case_UTAPI_012686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012686",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012686", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012686", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012686", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012686")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012687")
    void case_UTAPI_012687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012687",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012687", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012687", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012687", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012687")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012688")
    void case_UTAPI_012688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012688",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012688", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012688", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012688", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012688")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "59:tab")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012689")
    void case_UTAPI_012689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012689",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012689", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012689", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012689", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012689")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012690")
    void case_UTAPI_012690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012690",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012690", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012690", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012690", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012690")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012691")
    void case_UTAPI_012691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012691",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012691", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012691", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012691", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012691")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012692")
    void case_UTAPI_012692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012692",
                "com.matsushita.dbeditor.usecase.file.MemoUseCase",
                "saveMemo",
                "MemoResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012692", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012692", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012692", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012692")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/MemoUseCase.java::MemoUseCase::saveMemo::2::ARG::3::-::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableMemoRepository.upsert")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMemoRepository.upsert", "tableMemoRepository", "upsert")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to tableMemoRepository.upsert must carry connectionId", "tableMemoRepository", "upsert", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbTableName of the object handed to tableMemoRepository.upsert must carry tableName", "tableMemoRepository", "upsert", "0", "getDbTableName", "data:tableName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentMemo of the object handed to tableMemoRepository.upsert must carry content", "tableMemoRepository", "upsert", "0", "getContentMemo", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoUseCaseWrapper());
    }

}

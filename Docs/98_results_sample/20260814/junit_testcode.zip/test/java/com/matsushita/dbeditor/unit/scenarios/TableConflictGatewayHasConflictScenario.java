package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableConflictGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableConflictGateway#hasConflict.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableConflictGatewayHasConflictScenario {

    @Test
    @DisplayName("UTAPI-003676")
    void case_UTAPI_003676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003676",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003676", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003676", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003676", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003676", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003676", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003676", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003676")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003677")
    void case_UTAPI_003677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003677",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003677", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003677", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003677", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003677", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003677", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003677", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003677", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003677")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003678")
    void case_UTAPI_003678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003678",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003678", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003678", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003678", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003678", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003678", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003678", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003678")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003679")
    void case_UTAPI_003679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003679",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003679", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003679", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003679", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003679", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003679", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003679", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003679", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003679")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003680")
    void case_UTAPI_003680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003680",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003680", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003680", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003680", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003680", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003680", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003680", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003680")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003681")
    void case_UTAPI_003681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003681",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003681", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003681", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003681", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003681", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003681", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003681", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003681")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003682")
    void case_UTAPI_003682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003682",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003682", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003682", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003682", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003682", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003682", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003682", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003682")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003683")
    void case_UTAPI_003683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003683",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003683", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003683", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003683", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003683", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003683", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003683", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003683")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003684")
    void case_UTAPI_003684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003684",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003684", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003684", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003684", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003684", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003684", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003684")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003685")
    void case_UTAPI_003685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003685",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003685", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003685", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003685", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003685", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003685", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003685")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003686")
    void case_UTAPI_003686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003686",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003686", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003686", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003686", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003686", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003686", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003686")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003687")
    void case_UTAPI_003687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003687",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003687", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003687", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003687", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003687", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003687", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003687", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003687", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003687", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003687", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003687", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003687", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003687", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003687")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003688")
    void case_UTAPI_003688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003688",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003688", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003688", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003688", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003688", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003688", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003688", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003688", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003688", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003688", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003688", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003688", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003688", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003688")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003689")
    void case_UTAPI_003689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003689",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003689", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003689", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003689", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003689", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003689", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003689", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003689", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003689", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003689", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003689", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003689", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003689", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003689")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003690")
    void case_UTAPI_003690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003690",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003690", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003690", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003690", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003690", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003690", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003690", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003690", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003690", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003690", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003690", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003690", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003690", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003690")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003691")
    void case_UTAPI_003691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003691",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003691", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003691", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003691", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003691", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003691", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003691", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003691", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003691", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003691", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003691", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003691", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003691", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003691")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003692")
    void case_UTAPI_003692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003692",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003692", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003692", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003692", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003692", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003692", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003692", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003692", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003692", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003692", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003692", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003692", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003692", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003692")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003693")
    void case_UTAPI_003693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003693",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003693", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003693", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003693", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003693", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003693", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003693", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003693", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003693", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003693", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003693", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003693", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003693", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003693")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003694")
    void case_UTAPI_003694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003694",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003694", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003694", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003694", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003694", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003694", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003694", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003694", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003694", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003694", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003694", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003694", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003694", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003694")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003695")
    void case_UTAPI_003695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003695",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003695", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003695", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003695", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003695", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003695", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003695", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003695", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003695", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003695", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003695", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003695", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003695", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003695")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003696")
    void case_UTAPI_003696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003696",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003696", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003696", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003696", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003696", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003696", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003696", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003696", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003696", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003696", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003696", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003696", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003696", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003696")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003697")
    void case_UTAPI_003697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003697",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003697", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003697", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003697", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003697", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003697", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003697", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003697", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003697", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003697", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003697", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003697", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003697", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003697")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003698")
    void case_UTAPI_003698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003698",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003698", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003698", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003698", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003698", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003698", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003698", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003698", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003698", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003698", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003698", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003698", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003698", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003698")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003699")
    void case_UTAPI_003699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003699",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003699", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003699", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003699", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003699", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003699", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003699", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003699", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003699", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003699", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003699", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003699", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003699", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003699")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003700")
    void case_UTAPI_003700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003700",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003700", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003700", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003700", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003700", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003700", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003700", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003700", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003700", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003700", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003700", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003700", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003700", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003700")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003701")
    void case_UTAPI_003701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003701",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003701", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003701", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003701", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003701", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003701", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003701", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003701", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003701", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003701", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003701", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003701", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003701", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003701")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003702")
    void case_UTAPI_003702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003702",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003702", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003702", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003702", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003702", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003702", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003702", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003702", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003702", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003702", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003702", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003702", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003702", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003702")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003703")
    void case_UTAPI_003703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003703",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003703", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003703", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003703", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003703", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003703", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003703", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003703", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003703", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003703", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003703", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003703", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003703", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003703")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003704")
    void case_UTAPI_003704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003704",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003704", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003704", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003704", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003704", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003704", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003704", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003704", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003704", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003704", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003704", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003704", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003704", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003704")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003705")
    void case_UTAPI_003705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003705",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003705", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003705", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003705", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003705", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003705", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003705", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003705", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003705", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003705", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003705", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003705", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003705", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003705")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003706")
    void case_UTAPI_003706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003706",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003706", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003706", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003706", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003706", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003706", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003706", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003706", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003706", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003706", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003706", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003706", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003706", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003706")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003707")
    void case_UTAPI_003707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003707",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003707", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003707", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003707", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003707", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003707", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003707", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003707", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003707", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003707", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003707", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003707", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003707", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003707")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003708")
    void case_UTAPI_003708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003708",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003708", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003708", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003708", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003708", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003708", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003708", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003708", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003708", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003708", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003708", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003708", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003708", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003708")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003709")
    void case_UTAPI_003709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003709",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003709", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003709", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003709", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003709", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003709", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003709", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003709", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003709", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003709", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003709", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003709", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003709", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003709")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003710")
    void case_UTAPI_003710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003710",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003710", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003710", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003710", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003710", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003710", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003710", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003710", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003710", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003710", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003710", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003710", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003710", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003710")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003711")
    void case_UTAPI_003711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003711",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003711", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003711", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003711", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003711", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003711", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003711", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003711", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003711", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003711", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003711", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003711", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003711", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003711")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003712")
    void case_UTAPI_003712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003712",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003712", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003712", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003712", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003712", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003712", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003712", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003712", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003712", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003712", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003712", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003712", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003712", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003712")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003713")
    void case_UTAPI_003713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003713",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003713", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003713", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003713", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003713", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003713", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003713", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003713", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003713", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003713", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003713", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003713", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003713", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003713")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003714")
    void case_UTAPI_003714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003714",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003714", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003714", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003714", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003714", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003714", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003714", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003714", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003714", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003714", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003714", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003714", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003714", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003714")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003715")
    void case_UTAPI_003715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003715",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003715", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003715", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003715", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003715", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003715", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003715", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003715", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003715", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003715", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003715", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003715", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003715", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003715")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003716")
    void case_UTAPI_003716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003716",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003716", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003716", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003716", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003716", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003716", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003716", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003716", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003716", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003716", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003716", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003716", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003716", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003716")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003717")
    void case_UTAPI_003717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003717",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003717", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003717", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003717", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003717", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003717", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003717", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003717", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003717", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003717", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003717", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003717", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003717", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003717")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003718")
    void case_UTAPI_003718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003718",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003718", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003718", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003718", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003718", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003718", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003718", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003718", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003718", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003718", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003718", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003718", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003718", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003718")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003719")
    void case_UTAPI_003719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003719",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003719", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003719", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003719", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003719", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003719", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003719", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003719", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003719", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003719", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003719", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003719", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003719", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003719")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003720")
    void case_UTAPI_003720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003720",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003720", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003720", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003720", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003720", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003720", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003720", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003720", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003720", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003720", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003720", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003720", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003720", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003720")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003721")
    void case_UTAPI_003721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003721",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003721", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003721", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003721", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003721", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003721", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003721", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003721", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003721", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003721", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003721", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003721", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003721", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003721")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003722")
    void case_UTAPI_003722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003722",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003722", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003722", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003722", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003722", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003722", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003722", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003722", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003722", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003722", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003722", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003722", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003722", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003722")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003723")
    void case_UTAPI_003723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003723",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003723", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003723", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003723", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003723", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003723", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003723", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003723", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003723", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003723", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003723", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003723", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003723", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003723")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003724")
    void case_UTAPI_003724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003724",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003724", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003724", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003724", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003724", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003724", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003724", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003724", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003724", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003724", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003724", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003724", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003724", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003724")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003725")
    void case_UTAPI_003725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003725",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003725", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003725", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003725", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003725", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003725", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003725", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003725", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003725", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003725", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003725", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003725", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003725", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003725")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003726")
    void case_UTAPI_003726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003726",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003726", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003726", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003726", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003726", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003726", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003726", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003726", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003726", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003726", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003726", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003726", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003726", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003726")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003727")
    void case_UTAPI_003727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003727",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003727", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003727", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003727", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003727", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003727", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003727", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003727", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003727", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003727", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003727", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003727", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003727", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003727")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003728")
    void case_UTAPI_003728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003728",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003728", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003728", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003728", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003728", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003728", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003728", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003728", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003728", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003728", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003728", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003728", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003728", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003728")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003729")
    void case_UTAPI_003729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003729",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003729", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003729", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003729", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003729", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003729", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003729", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003729", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003729", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003729", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003729", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003729", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003729", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003729")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003730")
    void case_UTAPI_003730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003730",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003730", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003730", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003730", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003730", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003730", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003730", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003730", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003730", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003730", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003730", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003730", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003730", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003730")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003731")
    void case_UTAPI_003731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003731",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003731", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003731", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003731", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003731", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003731", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003731", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003731", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003731", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003731", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003731", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003731", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003731", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003731")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003732")
    void case_UTAPI_003732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003732",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003732", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003732", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003732", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003732", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003732", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003732", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003732", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003732", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003732", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003732", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003732", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003732", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003732")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003733")
    void case_UTAPI_003733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003733",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003733", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003733", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003733", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003733", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003733", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003733", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003733", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003733", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003733", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003733", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003733", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003733", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003733")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003734")
    void case_UTAPI_003734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003734",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003734", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003734", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003734", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003734", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003734", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003734", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003734", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003734", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003734", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003734", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003734", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003734", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003734")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003735")
    void case_UTAPI_003735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003735",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003735", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003735", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003735", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003735", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003735", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003735", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003735", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003735", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003735", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003735", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003735", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003735", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003735")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003736")
    void case_UTAPI_003736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003736",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003736", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003736", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003736", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003736", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003736", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003736", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003736", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003736", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003736", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003736", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003736", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003736", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003736")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003737")
    void case_UTAPI_003737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003737",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003737", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003737", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003737", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003737", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003737", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003737", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003737", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003737", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003737", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003737", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003737", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003737", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003737")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003738")
    void case_UTAPI_003738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003738",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003738", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003738", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003738", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003738", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003738", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003738", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003738", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003738", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003738", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003738", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003738", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003738", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003738")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003739")
    void case_UTAPI_003739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003739",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003739", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003739", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003739", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003739", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003739", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003739", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003739", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003739", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003739", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003739", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003739", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003739", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003739")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003740")
    void case_UTAPI_003740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003740",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003740", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003740", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003740", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003740", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003740", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003740", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003740", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003740", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003740", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003740", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003740", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003740", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003740")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003741")
    void case_UTAPI_003741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003741",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003741", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003741", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003741", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003741", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003741", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003741", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003741", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003741", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003741", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003741", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003741", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003741", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003741")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003742")
    void case_UTAPI_003742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003742",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003742", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003742", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003742", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003742", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003742", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003742", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003742", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003742", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003742", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003742", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003742", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003742", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003742")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003743")
    void case_UTAPI_003743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003743",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003743", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003743", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003743", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003743", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003743", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003743", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003743", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003743", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003743", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003743", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003743", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003743", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003743")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003744")
    void case_UTAPI_003744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003744",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003744", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003744", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003744", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003744", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003744", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003744", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003744", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003744", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003744", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003744", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003744", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003744", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003744")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003745")
    void case_UTAPI_003745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003745",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003745", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003745", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003745", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003745", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003745", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003745", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003745", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003745", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003745", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003745", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003745", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003745", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003745")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003746")
    void case_UTAPI_003746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003746",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003746", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003746", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003746", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003746", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003746", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003746", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003746", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003746", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003746", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003746", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003746", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003746", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003746")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003747")
    void case_UTAPI_003747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003747",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003747", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003747", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003747", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003747", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003747", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003747", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003747", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003747", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003747", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003747", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003747", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003747", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003747")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003748")
    void case_UTAPI_003748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003748",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003748", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003748", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003748", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003748", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003748", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003748", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003748", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003748", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003748", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003748", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003748", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003748", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003748")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003749")
    void case_UTAPI_003749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003749",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003749", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003749", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003749", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003749", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003749", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003749", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003749", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003749", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003749", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003749", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003749", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003749", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003749")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003750")
    void case_UTAPI_003750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003750",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003750", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003750", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003750", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003750", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003750", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003750", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003750", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003750", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003750", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003750", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003750", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003750", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003750")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003751")
    void case_UTAPI_003751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003751",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003751", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003751", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003751", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003751", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003751", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003751", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003751", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003751", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003751", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003751", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003751", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003751", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003751")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003752")
    void case_UTAPI_003752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003752",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003752", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003752", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003752", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003752", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003752", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003752", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003752", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003752", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003752", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003752", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003752", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003752", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003752")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003753")
    void case_UTAPI_003753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003753",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003753", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003753", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003753", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003753", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003753", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003753", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003753", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003753", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003753", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003753", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003753", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003753", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003753")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003754")
    void case_UTAPI_003754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003754",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003754", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003754", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003754", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003754", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003754", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003754", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003754", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003754", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003754", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003754", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003754", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003754", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003754")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003755")
    void case_UTAPI_003755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003755",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003755", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003755", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003755", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003755", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003755", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003755", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003755", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003755", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003755", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003755", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003755", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003755", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003755")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003756")
    void case_UTAPI_003756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003756",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003756", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003756", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003756", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003756", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003756", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003756", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003756", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003756", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003756", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003756", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003756", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003756", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003756")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003757")
    void case_UTAPI_003757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003757",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003757", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003757", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003757", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003757", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003757", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003757", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003757", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003757", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003757", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003757", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003757", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003757", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003757")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003758")
    void case_UTAPI_003758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003758",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003758", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003758", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003758", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003758", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003758", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003758", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003758", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003758", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003758", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003758", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003758", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003758", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003758")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003759")
    void case_UTAPI_003759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003759",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003759", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003759", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003759", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003759", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003759", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003759", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003759", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003759", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003759", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003759", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003759", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003759", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003759")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003760")
    void case_UTAPI_003760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003760",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003760", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003760", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003760", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003760", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003760", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003760", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003760", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003760")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003761")
    void case_UTAPI_003761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003761",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003761", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003761", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003761", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003761", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003761", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003761", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003761", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003761", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003761")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003762")
    void case_UTAPI_003762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003762",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003762", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003762", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003762", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003762", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003762", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003762", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003762", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003762", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003762")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003763")
    void case_UTAPI_003763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003763",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003763", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003763", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003763", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003763", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003763", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003763", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003763", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003763", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003763")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003764")
    void case_UTAPI_003764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003764",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003764", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003764", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003764", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003764", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003764", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003764", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003764", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003764", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003764")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003765")
    void case_UTAPI_003765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003765",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003765", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003765", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003765", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003765", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003765", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003765", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003765", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003765")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003766")
    void case_UTAPI_003766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003766",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003766", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003766", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003766", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003766", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003766", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003766", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003766")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003767")
    void case_UTAPI_003767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003767",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003767", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003767", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003767", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003767", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003767", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003767", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003767")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003768")
    void case_UTAPI_003768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003768",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003768", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003768", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003768", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003768", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003768", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003768", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003768")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003769")
    void case_UTAPI_003769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003769",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003769", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003769", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003769", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003769", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003769", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003769", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003769")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003770")
    void case_UTAPI_003770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003770",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003770", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003770", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003770", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003770", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003770", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003770", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003770")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003771")
    void case_UTAPI_003771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003771",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003771", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003771", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003771", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003771", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003771", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003771", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003771")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003772")
    void case_UTAPI_003772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003772",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003772", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003772", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003772", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003772", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003772", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003772", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003772", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003772")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003773")
    void case_UTAPI_003773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003773",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003773", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003773", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003773", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003773", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003773", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003773", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003773")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003774")
    void case_UTAPI_003774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003774",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003774", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003774", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003774", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003774", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003774", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003774", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003774")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003775")
    void case_UTAPI_003775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003775",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003775", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003775", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003775", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003775", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003775", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003775", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003775")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003776")
    void case_UTAPI_003776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003776",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003776", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003776", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003776", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003776", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003776", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003776", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003776", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003776", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003776", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003776", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003776", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003776", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003776")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003777")
    void case_UTAPI_003777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003777",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003777", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003777", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003777", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003777", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003777", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003777", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003777", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003777", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003777", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003777", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003777", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003777", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003777")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003778")
    void case_UTAPI_003778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003778",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003778", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003778", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003778", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003778", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003778", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003778", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003778", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003778", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003778", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003778", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003778", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003778", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003778")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003779")
    void case_UTAPI_003779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003779",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003779", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003779", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003779", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003779", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003779", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003779", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003779", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003779", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003779", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003779", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003779", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003779", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003779")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003780")
    void case_UTAPI_003780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003780",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003780", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003780", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003780", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003780", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003780", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003780", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003780", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003780", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003780", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003780", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003780", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003780", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003780")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003781")
    void case_UTAPI_003781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003781",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003781", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003781", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003781", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003781", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003781", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003781", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003781", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003781", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003781", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003781", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003781", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003781", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003781")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003782")
    void case_UTAPI_003782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003782",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003782", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003782", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003782", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003782", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003782", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003782", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003782", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003782", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003782", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003782", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003782", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003782", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003782")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003783")
    void case_UTAPI_003783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003783",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003783", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003783", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003783", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003783", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003783", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003783", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003783", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003783", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003783", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003783", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003783", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003783", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003783")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003784")
    void case_UTAPI_003784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003784",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003784", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003784", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003784", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003784", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003784", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003784", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003784", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003784", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003784", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003784", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003784", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003784", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003784")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003785")
    void case_UTAPI_003785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003785",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003785", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003785", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003785", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003785", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003785", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003785", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003785", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003785", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003785", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003785", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003785", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003785", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003785")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003786")
    void case_UTAPI_003786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003786",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003786", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003786", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003786", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003786", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003786", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003786", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003786", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003786", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003786", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003786", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003786", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003786", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003786")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003787")
    void case_UTAPI_003787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003787",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003787", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003787", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003787", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003787", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003787", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003787", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003787", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003787", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003787", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003787", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003787", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003787", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003787")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003788")
    void case_UTAPI_003788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003788",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003788", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003788", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003788", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003788", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003788", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003788", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003788", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003788", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003788", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003788", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003788", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003788", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003788")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003789")
    void case_UTAPI_003789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003789",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003789", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003789", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003789", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003789", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003789", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003789", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003789", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003789", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003789", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003789", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003789", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003789", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003789")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003790")
    void case_UTAPI_003790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003790",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003790", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003790", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003790", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003790", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003790", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003790", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003790", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003790", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003790", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003790", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003790", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003790", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003790")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003791")
    void case_UTAPI_003791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003791",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003791", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003791", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003791", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003791", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003791", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003791", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003791", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003791", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003791", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003791", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003791", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003791", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003791")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003792")
    void case_UTAPI_003792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003792",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003792", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003792", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003792", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003792", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003792", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003792", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003792", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003792", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003792", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003792", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003792", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003792", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003792")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003793")
    void case_UTAPI_003793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003793",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003793", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003793", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003793", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003793", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003793", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003793", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003793", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003793", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003793", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003793", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003793", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003793", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003793")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003794")
    void case_UTAPI_003794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003794",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003794", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003794", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003794", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003794", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003794", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003794", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003794", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003794", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003794", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003794", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003794", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003794", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003794")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003795")
    void case_UTAPI_003795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003795",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003795", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003795", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003795", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003795", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003795", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003795", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003795", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003795", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003795", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003795", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003795", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003795", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003795")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003796")
    void case_UTAPI_003796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003796",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003796", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003796", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003796", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003796", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003796", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003796", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003796", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003796", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003796", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003796", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003796", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003796", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003796")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003797")
    void case_UTAPI_003797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003797",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003797", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003797", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003797", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003797", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003797", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003797", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003797", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003797", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003797", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003797", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003797", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003797", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003797")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003798")
    void case_UTAPI_003798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003798",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003798", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003798", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003798", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003798", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003798", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003798")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003799")
    void case_UTAPI_003799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003799",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003799", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003799", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003799", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003799", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003799", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003799")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003800")
    void case_UTAPI_003800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003800",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003800", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003800", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003800", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003800", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003800", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003800")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003801")
    void case_UTAPI_003801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003801",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003801", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003801", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003801", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003801", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003801", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003801")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003802")
    void case_UTAPI_003802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003802",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003802", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003802", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003802", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003802", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003802", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003802")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003803")
    void case_UTAPI_003803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003803",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003803", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003803", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003803", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003803", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003803", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003803")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003804")
    void case_UTAPI_003804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003804",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003804", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003804", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003804", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003804", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003804", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003804", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003804")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003805")
    void case_UTAPI_003805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003805",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003805", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003805", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003805", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003805", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003805", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003805", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003805")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003806")
    void case_UTAPI_003806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003806",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003806", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003806", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003806", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003806", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003806", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003806", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003806")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003807")
    void case_UTAPI_003807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003807",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003807", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003807", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003807", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003807", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003807", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003807", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003807")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003808")
    void case_UTAPI_003808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003808",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003808", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003808", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003808", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003808", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003808", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003808", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003808", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003808")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003809")
    void case_UTAPI_003809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003809",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003809", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003809", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003809", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003809", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003809", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003809", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003809")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003810")
    void case_UTAPI_003810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003810",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003810", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003810", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003810", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003810", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003810", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003810", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003810")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003811")
    void case_UTAPI_003811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003811",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003811", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003811", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003811", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003811", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003811", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003811", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003811")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003812")
    void case_UTAPI_003812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003812",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003812", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003812", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003812", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003812", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003812", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003812", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003812")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003813")
    void case_UTAPI_003813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003813",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003813", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003813", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003813", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003813", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003813", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003813", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003813")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003814")
    void case_UTAPI_003814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003814",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003814", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003814", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003814", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003814", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003814", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003814", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003814")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003815")
    void case_UTAPI_003815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003815",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003815", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003815", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003815", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003815", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003815", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003815", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003815")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003816")
    void case_UTAPI_003816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003816",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003816", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003816", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003816", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003816", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003816", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003816")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003817")
    void case_UTAPI_003817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003817",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003817", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003817", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003817", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003817", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003817")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003818")
    void case_UTAPI_003818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003818",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003818", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003818", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003818", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003818", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003818")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003819")
    void case_UTAPI_003819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003819",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003819", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003819", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003819", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003819", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003819")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003820")
    void case_UTAPI_003820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003820",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003820", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003820", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003820", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003820", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003820")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003821")
    void case_UTAPI_003821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003821",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003821", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003821", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003821", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003821", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003821")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003822")
    void case_UTAPI_003822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003822",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003822", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003822", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003822", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003822", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003822")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003823")
    void case_UTAPI_003823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003823",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003823", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003823", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003823", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003823", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003823")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003824")
    void case_UTAPI_003824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003824",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003824", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003824", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003824", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003824", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003824")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003825")
    void case_UTAPI_003825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003825",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003825", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003825", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003825", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003825", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003825")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003826")
    void case_UTAPI_003826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003826",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003826", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003826", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003826", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003826", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003826")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003827")
    void case_UTAPI_003827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003827",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003827", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003827", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003827", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003827", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003827", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003827")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003828")
    void case_UTAPI_003828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003828",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003828", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003828", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003828", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003828", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003828", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003828")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003829")
    void case_UTAPI_003829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003829",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003829", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003829", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003829", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003829", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003829", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003829", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003829", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003829", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003829", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003829", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003829", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003829", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003829")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003830")
    void case_UTAPI_003830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003830",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003830", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003830", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003830", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003830", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003830", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003830", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003830", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003830", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003830", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003830", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003830", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003830", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003830")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003831")
    void case_UTAPI_003831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003831",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003831", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003831", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003831", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003831", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003831", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003831", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003831", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003831", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003831", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003831", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003831", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003831", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003831")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003832")
    void case_UTAPI_003832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003832",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003832", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003832", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003832", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003832", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003832", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003832", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003832", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003832", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003832", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003832", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003832", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003832", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003832")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003833")
    void case_UTAPI_003833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003833",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003833", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003833", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003833", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003833", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003833", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003833", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003833", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003833", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003833", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003833", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003833", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003833", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003833")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003834")
    void case_UTAPI_003834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003834",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003834", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003834", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003834", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003834", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003834", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003834", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003834", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003834", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003834", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003834", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003834", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003834", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003834")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003835")
    void case_UTAPI_003835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003835",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003835", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003835", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003835", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003835", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003835", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003835", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003835", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003835", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003835", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003835", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003835", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003835", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003835")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003836")
    void case_UTAPI_003836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003836",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003836", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003836", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003836", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003836", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003836", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003836", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003836", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003836", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003836", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003836", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003836", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003836", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003836")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003837")
    void case_UTAPI_003837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003837",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003837", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003837", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003837", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003837", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003837", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003837", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003837", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003837", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003837", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003837", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003837", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-003837", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003837")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003838")
    void case_UTAPI_003838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003838",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003838", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003838", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003838", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003838", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003838", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003838", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003838", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003838", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003838", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003838", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003838", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003838", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003838")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003839")
    void case_UTAPI_003839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003839",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003839", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003839", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003839", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003839", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003839", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003839", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003839", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003839", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003839", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003839", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003839", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003839", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003839")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003840")
    void case_UTAPI_003840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003840",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003840", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003840", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003840", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003840", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003840", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003840", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003840", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003840", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003840", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003840", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003840", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003840", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003840")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003841")
    void case_UTAPI_003841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003841",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003841", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003841", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003841", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003841", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003841", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003841", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003841", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003841", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003841", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003841", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003841", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003841", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003841")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003842")
    void case_UTAPI_003842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003842",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003842", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003842", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003842", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003842", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003842", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003842", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003842", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003842", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003842", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003842", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003842", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003842", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003842")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003843")
    void case_UTAPI_003843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003843",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003843", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003843", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003843", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003843", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003843", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003843", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003843", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003843", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003843", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003843", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003843", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003843", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003843")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003844")
    void case_UTAPI_003844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003844",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003844", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003844", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003844", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003844", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003844", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003844", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003844", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003844", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003844", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003844", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003844", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003844", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003844")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003845")
    void case_UTAPI_003845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003845",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003845", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003845", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003845", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003845", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003845", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003845", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003845", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003845", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003845", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003845", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003845", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003845", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003845")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003846")
    void case_UTAPI_003846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003846",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003846", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003846", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003846", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003846", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003846", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003846", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003846", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003846", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003846", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003846", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003846", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003846", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003846")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003847")
    void case_UTAPI_003847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003847",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003847", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003847", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003847", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003847", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003847", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003847", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003847", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003847", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003847", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003847", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003847", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003847", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003847")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003848")
    void case_UTAPI_003848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003848",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003848", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003848", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003848", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003848", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003848", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003848", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003848", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003848", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003848", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003848", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003848", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003848", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003848")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003849")
    void case_UTAPI_003849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003849",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003849", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003849", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003849", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003849", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003849", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003849", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003849", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003849", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003849", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003849", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003849", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003849", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003849")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003850")
    void case_UTAPI_003850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003850",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003850", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003850", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003850", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003850", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003850", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003850", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003850", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003850", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003850", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003850", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003850", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003850", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003850")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003851")
    void case_UTAPI_003851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003851",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003851", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003851", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003851", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003851", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003851", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003851", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003851", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003851", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003851", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003851", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003851", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003851", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003851")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003852")
    void case_UTAPI_003852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003852",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003852", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003852", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003852", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003852", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003852", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003852", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003852", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003852", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003852", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003852", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003852", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003852", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003852")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003853")
    void case_UTAPI_003853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003853",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003853", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003853", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003853", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003853", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003853", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003853", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003853", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003853", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003853", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003853", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003853", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003853", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003853")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003854")
    void case_UTAPI_003854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003854",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003854", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003854", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003854", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003854", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003854", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003854", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003854", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003854", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003854", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003854", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003854", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003854", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003854")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003855")
    void case_UTAPI_003855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003855",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003855", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003855", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003855", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003855", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003855", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003855", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003855", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003855", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003855", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003855", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003855", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003855", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003855")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003856")
    void case_UTAPI_003856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003856",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003856", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003856", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003856", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003856", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003856", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003856", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003856", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003856", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003856", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003856", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003856", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003856", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003856")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003857")
    void case_UTAPI_003857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003857",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003857", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003857", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003857", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003857", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003857", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003857", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003857", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003857", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003857", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003857", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003857", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003857", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003857")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-003858")
    void case_UTAPI_003858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-003858",
                "com.matsushita.dbeditor.adapter.gateway.TableConflictGateway",
                "hasConflict",
                "boolean",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-003858", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-003858", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003858", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003858", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003858", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003858", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003858", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003858", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003858", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-003858", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-003858", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-003858", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-003858")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableConflictGateway.java::TableConflictGateway::hasConflict::2::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableConflictGatewayWrapper());
    }

}

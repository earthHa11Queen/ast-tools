package com.matsushita.dbeditor.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Maps the referenceType of test-data-instruction onto the Java receiving type
 * handed to TestDataRuntime, and resolves declared parameter types for reflection.
 */
public final class TypeSupport {

    private TypeSupport() {
    }

    /** Raw type name without generic arguments and without array suffix handling. */
    public static String raw(String declared) {
        if (declared == null) {
            return null;
        }
        String t = declared.trim();
        int lt = t.indexOf('<');
        if (lt >= 0) {
            int gt = t.lastIndexOf('>');
            if (gt > lt) {
                t = t.substring(0, lt) + t.substring(gt + 1);
            } else {
                t = t.substring(0, lt);
            }
        }
        return t.trim();
    }

    /** Receiving type passed to TestDataRuntime.getValue. */
    public static Class<?> receivingType(String referenceType) {
        String t = raw(referenceType);
        if (t == null || t.isEmpty() || "-".equals(t)) {
            return Object.class;
        }
        if (t.endsWith("[]")) {
            String base = t.substring(0, t.length() - 2);
            if ("byte".equals(base)) {
                return byte[].class;
            }
            if ("String".equals(base)) {
                return String[].class;
            }
            if ("int".equals(base)) {
                return int[].class;
            }
            Class<?> comp = ProjectTypes.loadOrNull(base);
            if (comp != null) {
                return java.lang.reflect.Array.newInstance(comp, 0).getClass();
            }
            return Object[].class;
        }
        if ("String".equals(t)) {
            return String.class;
        }
        if ("Integer".equals(t) || "int".equals(t)) {
            return Integer.class;
        }
        if ("Long".equals(t) || "long".equals(t)) {
            return Long.class;
        }
        if ("Short".equals(t) || "short".equals(t)) {
            return Short.class;
        }
        if ("Byte".equals(t) || "byte".equals(t)) {
            return Byte.class;
        }
        if ("Double".equals(t) || "double".equals(t)) {
            return Double.class;
        }
        if ("Float".equals(t) || "float".equals(t)) {
            return Float.class;
        }
        if ("Boolean".equals(t) || "boolean".equals(t)) {
            return Boolean.class;
        }
        if ("BigDecimal".equals(t)) {
            return java.math.BigDecimal.class;
        }
        if ("LocalDateTime".equals(t)) {
            return LocalDateTime.class;
        }
        if ("LocalDate".equals(t)) {
            return LocalDate.class;
        }
        if ("List".equals(t) || "Collection".equals(t) || "Queue".equals(t) || "Deque".equals(t)) {
            return List.class;
        }
        if ("Set".equals(t)) {
            return java.util.Set.class;
        }
        if ("Map".equals(t)) {
            return Map.class;
        }
        if ("Object".equals(t)) {
            return Object.class;
        }
        Class<?> loaded = ProjectTypes.loadOrNull(t);
        if (loaded != null) {
            return loaded;
        }
        return Object.class;
    }

    /** True when the referenceType denotes a container handled by TestDataRuntime. */
    public static boolean isContainerModel(String convModel) {
        return "COLLECTION".equals(convModel) || "ARRAY".equals(convModel) || "MAP".equals(convModel);
    }

    public static boolean matchesSimpleName(Class<?> actual, String declared) {
        String want = raw(declared);
        if (want == null) {
            return false;
        }
        if (want.endsWith("[]")) {
            if (!actual.isArray()) {
                return false;
            }
            return matchesSimpleName(actual.getComponentType(), want.substring(0, want.length() - 2));
        }
        String have = actual.getSimpleName();
        if (have.equals(want)) {
            return true;
        }
        if (("int".equals(want) && "int".equals(have)) || ("Integer".equals(want) && "int".equals(have))
                || ("int".equals(want) && "Integer".equals(have))) {
            return true;
        }
        if (("boolean".equals(want) && "Boolean".equals(have)) || ("Boolean".equals(want) && "boolean".equals(have))) {
            return true;
        }
        if (("long".equals(want) && "Long".equals(have)) || ("Long".equals(want) && "long".equals(have))) {
            return true;
        }
        return false;
    }
}

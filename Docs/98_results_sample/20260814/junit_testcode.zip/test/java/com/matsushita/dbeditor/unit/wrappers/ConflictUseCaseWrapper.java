package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ConflictUseCase.
 */
public final class ConflictUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase";
    private static final String[] DEP_NAMES = new String[] {"connectionSettingRepository", "tableConflictRepository"};
    private static final String[] DEP_TYPES = new String[] {"ConnectionSettingRepository", "TableConflictRepository"};
    private static final String[] TYPES_applyToReal = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_calcDiff = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_createBackup = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_getConnection = new String[] {"Integer"};
    private static final String[] TYPES_hasConflict = new String[] {"Integer", "String", "String"};

    public ConflictUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void applyToReal(connectionId, schemaName, tableName) */
    public ExecutionResult applyToReal(Object[] args) {
        return invoke("applyToReal", TYPES_applyToReal, args);
    }

    /** List<Map<String,Object>> calcDiff(connectionId, schemaName, tableName) */
    public ExecutionResult calcDiff(Object[] args) {
        return invoke("calcDiff", TYPES_calcDiff, args);
    }

    /** void createBackup(connectionId, schemaName, tableName) */
    public ExecutionResult createBackup(Object[] args) {
        return invoke("createBackup", TYPES_createBackup, args);
    }

    /** ConnectionSetting getConnection(connectionId) */
    public ExecutionResult getConnection(Object[] args) {
        return invoke("getConnection", TYPES_getConnection, args);
    }

    /** boolean hasConflict(connectionId, schemaName, tableName) */
    public ExecutionResult hasConflict(Object[] args) {
        return invoke("hasConflict", TYPES_hasConflict, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("applyToReal".equals(operation)) {
            return applyToReal(args);
        } else if ("calcDiff".equals(operation)) {
            return calcDiff(args);
        } else if ("createBackup".equals(operation)) {
            return createBackup(args);
        } else if ("getConnection".equals(operation)) {
            return getConnection(args);
        } else if ("hasConflict".equals(operation)) {
            return hasConflict(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

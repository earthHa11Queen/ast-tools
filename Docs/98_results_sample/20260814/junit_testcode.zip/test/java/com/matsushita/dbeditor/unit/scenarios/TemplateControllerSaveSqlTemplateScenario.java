package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateController#saveSqlTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateControllerSaveSqlTemplateScenario {

    @Test
    @DisplayName("UTAPI-001808")
    void case_UTAPI_001808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001808",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001808", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001808", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001808", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001808")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of TemplateRequest.content classifies this input condition", "TemplateRequest", "content", "NotBlank", "data:request.content")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001809")
    void case_UTAPI_001809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001809",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001809", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001809", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001809", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001809")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "3:length_min", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001810")
    void case_UTAPI_001810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001810",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001810", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001810", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001810", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001810")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001811")
    void case_UTAPI_001811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001811",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001811", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001811", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001811", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001811")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "5:length_max", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001812")
    void case_UTAPI_001812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001812",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001812", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001812", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001812", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001812")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001813")
    void case_UTAPI_001813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001813",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001813", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001813", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001813", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001813")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001814")
    void case_UTAPI_001814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001814",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001814", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001814", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001814", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001814")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001815")
    void case_UTAPI_001815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001815",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001815", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001815", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001815", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001815")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001816")
    void case_UTAPI_001816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001816",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001816", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001816", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001816", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001816")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001817")
    void case_UTAPI_001817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001817",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001817", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001817", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001817", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001817")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001818")
    void case_UTAPI_001818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001818",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001818", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001818", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001818", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001818")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001819")
    void case_UTAPI_001819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001819",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001819", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001819", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001819", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001819")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "56:space")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001820")
    void case_UTAPI_001820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001820",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001820", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001820", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001820", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001820")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001821")
    void case_UTAPI_001821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001821",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001821", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001821", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001821", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001821")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001822")
    void case_UTAPI_001822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001822",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001822", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001822", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001822", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001822")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "59:tab")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001823")
    void case_UTAPI_001823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001823",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001823", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001823", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001823", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001823")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001824")
    void case_UTAPI_001824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001824",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001824", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001824", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001824", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001824")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001825")
    void case_UTAPI_001825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001825",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001825", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001825", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001825", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001825")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001826")
    void case_UTAPI_001826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001826",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001826", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001826", "request.content", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001826", "request.title", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001826")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.content", "TemplateRequest.content")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001827")
    void case_UTAPI_001827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001827",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001827", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001827", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001827", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001827")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of TemplateRequest.title classifies this input condition", "TemplateRequest", "title", "NotBlank", "data:request.title")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001828")
    void case_UTAPI_001828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001828",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001828", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001828", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001828", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001828")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "3:length_min", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001829")
    void case_UTAPI_001829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001829",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001829", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001829", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001829", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001829")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001830")
    void case_UTAPI_001830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001830",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001830", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001830", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001830", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001830")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "5:length_max", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001831")
    void case_UTAPI_001831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001831",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001831", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001831", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001831", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001831")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001832")
    void case_UTAPI_001832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001832",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001832", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001832", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001832", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001832")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001833")
    void case_UTAPI_001833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001833",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001833", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001833", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001833", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001833")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001834")
    void case_UTAPI_001834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001834",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001834", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001834", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001834", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001834")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001835")
    void case_UTAPI_001835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001835",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001835", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001835", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001835", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001835")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001836")
    void case_UTAPI_001836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001836",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001836", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001836", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001836", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001836")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001837")
    void case_UTAPI_001837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001837",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001837", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001837", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001837", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001837")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001838")
    void case_UTAPI_001838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001838",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001838", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001838", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001838", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001838")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001839")
    void case_UTAPI_001839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001839",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001839", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001839", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001839", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001839")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "56:space")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001840")
    void case_UTAPI_001840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001840",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001840", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001840", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001840", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001840")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001841")
    void case_UTAPI_001841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001841",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001841", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001841", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001841", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001841")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001842")
    void case_UTAPI_001842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001842",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001842", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001842", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001842", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001842")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "59:tab")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001843")
    void case_UTAPI_001843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001843",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001843", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001843", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001843", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001843")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001844")
    void case_UTAPI_001844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001844",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001844", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001844", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001844", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001844")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001845")
    void case_UTAPI_001845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001845",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001845", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001845", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001845", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001845")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001846")
    void case_UTAPI_001846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001846",
                "com.matsushita.dbeditor.adapter.controller.TemplateController",
                "saveSqlTemplate",
                "ResponseEntity<TemplateResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "TemplateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001846", "request", "NORMAL", "OBJECT", "TemplateRequest"),
                    new DataRef("UTAPI-001846", "request.content", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001846", "request.title", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001846")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TemplateController.java::TemplateController::saveSqlTemplate::5::FIELD::1::TemplateRequest::title")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.title", "TemplateRequest.title")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of templateUseCase.saveSqlTemplate")
                    .expected("the value generated for request.title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through templateUseCase.saveSqlTemplate", "templateUseCase", "saveSqlTemplate")
                    .check(CheckType.ARG_EQUALS, "argument 0 of templateUseCase.saveSqlTemplate must carry the value generated for request.title", "templateUseCase", "saveSqlTemplate", "0", "data:request.title")
                    .check(CheckType.ARG_EQUALS, "argument 1 of templateUseCase.saveSqlTemplate must carry the value generated for request.content", "templateUseCase", "saveSqlTemplate", "1", "data:request.content")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateControllerWrapper());
    }

}

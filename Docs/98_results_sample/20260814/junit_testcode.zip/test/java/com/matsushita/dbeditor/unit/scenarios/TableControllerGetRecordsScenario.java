package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#getRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerGetRecordsScenario {

    @Test
    @DisplayName("UTAPI-001472")
    void case_UTAPI_001472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001472",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001472", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001472", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001472", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001472")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001473")
    void case_UTAPI_001473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001473",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001473", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001473", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001473", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001473")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001474")
    void case_UTAPI_001474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001474",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001474", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001474", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001474", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001474")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001475")
    void case_UTAPI_001475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001475",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001475", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001475", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001475", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001475")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001476")
    void case_UTAPI_001476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001476",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001476", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001476", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001476", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001476")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001477")
    void case_UTAPI_001477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001477",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001477", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001477", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001477", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001477")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001478")
    void case_UTAPI_001478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001478",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001478", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001478", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001478", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001478")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001479")
    void case_UTAPI_001479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001479",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001479", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001479", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001479", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001479")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001480")
    void case_UTAPI_001480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001480",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001480", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001480", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001480", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001480")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001481")
    void case_UTAPI_001481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001481",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001481", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001481", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001481", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001481")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001482")
    void case_UTAPI_001482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001482",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001482", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001482", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001482", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001482")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001483")
    void case_UTAPI_001483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001483",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001483", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001483", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001483", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001483")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001484")
    void case_UTAPI_001484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001484",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001484", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001484", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001484", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001484")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001485")
    void case_UTAPI_001485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001485",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001485", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001485", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001485", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001485")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001486")
    void case_UTAPI_001486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001486",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001486", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001486", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001486", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001486")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001487")
    void case_UTAPI_001487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001487",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001487", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001487", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001487", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001487")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001488")
    void case_UTAPI_001488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001488",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001488", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001488", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001488", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001488")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001489")
    void case_UTAPI_001489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001489",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001489", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001489", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001489", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001489")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001490")
    void case_UTAPI_001490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001490",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001490", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001490", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001490", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001490")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001491")
    void case_UTAPI_001491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001491",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001491", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001491", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001491", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001491")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001492")
    void case_UTAPI_001492() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001492",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001492", "name", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001492", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001492", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001492")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001493")
    void case_UTAPI_001493() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001493",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001493", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001493", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001493", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001493")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001494")
    void case_UTAPI_001494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001494",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001494", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001494", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001494", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001494")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001495")
    void case_UTAPI_001495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001495",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001495", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001495", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001495", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001495")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001496")
    void case_UTAPI_001496() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001496",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001496", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001496", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001496", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001496")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001497")
    void case_UTAPI_001497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001497",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001497", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001497", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001497", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001497")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001498")
    void case_UTAPI_001498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001498",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001498", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001498", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001498", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001498")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001499")
    void case_UTAPI_001499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001499",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001499", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001499", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001499", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001499")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001500")
    void case_UTAPI_001500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001500",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001500", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001500", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001500", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001500")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001501")
    void case_UTAPI_001501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001501",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001501", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001501", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001501", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001501")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001502")
    void case_UTAPI_001502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001502",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001502", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001502", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001502", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001502")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001503")
    void case_UTAPI_001503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001503",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001503", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001503", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001503", "schema", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001503")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001504")
    void case_UTAPI_001504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001504",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001504", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001504", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001504", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001504")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "1:length_null", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001505")
    void case_UTAPI_001505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001505",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001505", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001505", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001505", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001505")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "2:length_empty", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001506")
    void case_UTAPI_001506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001506",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001506", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001506", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001506", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001506")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "3:length_min", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001507")
    void case_UTAPI_001507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001507",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001507", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001507", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001507", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001507")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001508")
    void case_UTAPI_001508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001508",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001508", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001508", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001508", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001508")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "5:length_max", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001509")
    void case_UTAPI_001509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001509",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001509", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001509", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001509", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001509")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001510")
    void case_UTAPI_001510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001510",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001510", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001510", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001510", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001510")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001511")
    void case_UTAPI_001511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001511",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001511", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001511", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001511", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001511")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001512")
    void case_UTAPI_001512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001512",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001512", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001512", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001512", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001512")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001513")
    void case_UTAPI_001513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001513",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001513", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001513", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001513", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001513")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001514")
    void case_UTAPI_001514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001514",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001514", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001514", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001514", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001514")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001515")
    void case_UTAPI_001515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001515",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001515", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001515", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001515", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001515")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001516")
    void case_UTAPI_001516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001516",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001516", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001516", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001516", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001516")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "56:space")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001517")
    void case_UTAPI_001517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001517",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001517", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001517", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001517", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001517")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001518")
    void case_UTAPI_001518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001518",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001518", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001518", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001518", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001518")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001519")
    void case_UTAPI_001519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001519",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001519", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001519", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001519", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001519")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "59:tab")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001520")
    void case_UTAPI_001520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001520",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001520", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001520", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001520", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001520")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001521")
    void case_UTAPI_001521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001521",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001521", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001521", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001521", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001521")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001522")
    void case_UTAPI_001522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001522",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001522", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001522", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001522", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001522")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001523")
    void case_UTAPI_001523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001523",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "getRecords",
                "ResponseEntity<List<Map<String,Object>>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schema", "String", "schema")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001523", "name", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001523", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001523", "schema", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001523")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::getRecords::4::ARG::3::-::schema")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schema", "schema")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.getAllRecords")
                    .expected("the value generated for schema is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.getAllRecords", "tableRecordUseCase", "getAllRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.getAllRecords must carry the value generated for connectionId", "tableRecordUseCase", "getAllRecords", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.getAllRecords must carry the value generated for schema", "tableRecordUseCase", "getAllRecords", "1", "data:schema")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.getAllRecords must carry the value generated for name", "tableRecordUseCase", "getAllRecords", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

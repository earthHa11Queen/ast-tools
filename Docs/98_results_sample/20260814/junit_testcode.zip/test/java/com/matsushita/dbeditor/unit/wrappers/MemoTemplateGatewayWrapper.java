package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for MemoTemplateGateway.
 */
public final class MemoTemplateGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway";
    private static final String[] DEP_NAMES = new String[] {"jdbcTemplate", "SCHEMA", "rowMapper"};
    private static final String[] DEP_TYPES = new String[] {"JdbcTemplate", "String", "RowMapper<MemoTemplate>"};
    private static final String[] TYPES_deleteById = new String[] {"Integer"};
    private static final String[] TYPES_findAll = new String[] {};
    private static final String[] TYPES_findById = new String[] {"Integer"};
    private static final String[] TYPES_save = new String[] {"MemoTemplate"};

    public MemoTemplateGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
        registry().setGenericHint("MemoTemplate");
    }

    /** void deleteById(n) */
    public ExecutionResult deleteById(Object[] args) {
        return invoke("deleteById", TYPES_deleteById, args);
    }

    /** List<MemoTemplate> findAll() */
    public ExecutionResult findAll(Object[] args) {
        return invoke("findAll", TYPES_findAll, args);
    }

    /** Optional<MemoTemplate> findById(n) */
    public ExecutionResult findById(Object[] args) {
        return invoke("findById", TYPES_findById, args);
    }

    /** MemoTemplate save(template) */
    public ExecutionResult save(Object[] args) {
        return invoke("save", TYPES_save, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("deleteById".equals(operation)) {
            return deleteById(args);
        } else if ("findAll".equals(operation)) {
            return findAll(args);
        } else if ("findById".equals(operation)) {
            return findById(args);
        } else if ("save".equals(operation)) {
            return save(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionUseCase#update.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionUseCaseUpdateScenario {

    @Test
    @DisplayName("UTAPI-011975")
    void case_UTAPI_011975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011975",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011975", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011975", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011975", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011975", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011975", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011975", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011975", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011975", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011975")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011976")
    void case_UTAPI_011976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011976",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011976", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011976", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011976", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011976", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011976", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011976", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011976", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011976", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011976")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011977")
    void case_UTAPI_011977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011977",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011977", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011977", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011977", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011977", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011977", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011977", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011977", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011977", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011977")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011978")
    void case_UTAPI_011978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011978",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011978", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011978", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011978", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011978", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011978", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011978", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011978", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011978", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011978")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011979")
    void case_UTAPI_011979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011979",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011979", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011979", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011979", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011979", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011979", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011979", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011979", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011979", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011979")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011980")
    void case_UTAPI_011980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011980",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011980", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011980", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011980", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011980", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011980", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011980", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011980", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011980", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011980")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011981")
    void case_UTAPI_011981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011981",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011981", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011981", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011981", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011981", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011981", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011981", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011981", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011981", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011981")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011982")
    void case_UTAPI_011982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011982",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011982", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011982", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011982", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011982", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011982", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011982", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011982", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011982", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011982")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011983")
    void case_UTAPI_011983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011983",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011983", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011983", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011983", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011983", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011983", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011983", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011983", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011983", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011983")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011984")
    void case_UTAPI_011984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011984",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011984", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011984", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011984", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011984", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011984", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011984", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011984", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011984", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011984")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011985")
    void case_UTAPI_011985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011985",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011985", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011985", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011985", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011985", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011985", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011985", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011985", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011985", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011985")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011986")
    void case_UTAPI_011986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011986",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011986", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011986", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011986", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011986", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011986", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011986", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011986", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011986", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011986")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.databaseName classifies this input condition", "ConnectionSettingRequest", "databaseName", "NotBlank", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011987")
    void case_UTAPI_011987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011987",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011987", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011987", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011987", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011987", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011987", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011987", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011987", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011987", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011987")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011988")
    void case_UTAPI_011988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011988",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011988", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011988", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011988", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011988", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011988", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011988", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011988", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011988", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011988")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011989")
    void case_UTAPI_011989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011989",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011989", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011989", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011989", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011989", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011989", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011989", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011989", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011989", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011989")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011990")
    void case_UTAPI_011990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011990",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011990", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011990", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011990", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011990", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011990", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011990", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011990", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011990", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011990")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011991")
    void case_UTAPI_011991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011991",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011991", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011991", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011991", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011991", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011991", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011991", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011991", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011991", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011991")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011992")
    void case_UTAPI_011992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011992",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011992", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011992", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011992", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011992", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011992", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011992", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011992", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011992", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011992")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011993")
    void case_UTAPI_011993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011993",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011993", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011993", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011993", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011993", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011993", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011993", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011993", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011993", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011993")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011994")
    void case_UTAPI_011994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011994",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011994", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011994", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011994", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011994", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011994", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011994", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011994", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011994", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011994")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011995")
    void case_UTAPI_011995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011995",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011995", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011995", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011995", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011995", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011995", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011995", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011995", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011995", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011995")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011996")
    void case_UTAPI_011996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011996",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011996", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011996", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011996", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011996", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011996", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011996", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011996", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011996", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011996")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011997")
    void case_UTAPI_011997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011997",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011997", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011997", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011997", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011997", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011997", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011997", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011997", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011997", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011997")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011998")
    void case_UTAPI_011998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011998",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011998", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011998", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011998", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011998", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011998", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011998", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011998", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011998", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011998")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011999")
    void case_UTAPI_011999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011999",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011999", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011999", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011999", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011999", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011999", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011999", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011999", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011999", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-011999")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012000")
    void case_UTAPI_012000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012000",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012000", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012000", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012000", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012000", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012000", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012000", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012000", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012000", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012000")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012001")
    void case_UTAPI_012001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012001",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012001", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012001", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012001", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012001", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012001", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012001", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012001", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012001", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012001")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012002")
    void case_UTAPI_012002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012002",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012002", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012002", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012002", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012002", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012002", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012002", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012002", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012002", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012002")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012003")
    void case_UTAPI_012003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012003",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012003", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012003", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012003", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012003", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012003", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012003", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012003", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012003", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012003")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012004")
    void case_UTAPI_012004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012004",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012004", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012004", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012004", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012004", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012004", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012004", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012004", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012004", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012004")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012005")
    void case_UTAPI_012005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012005",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012005", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012005", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012005", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012005", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012005", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012005", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012005", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012005", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012005")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012006")
    void case_UTAPI_012006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012006",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012006", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012006", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012006", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012006", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012006", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012006", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012006", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012006", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012006")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbHost classifies this input condition", "ConnectionSettingRequest", "dbHost", "NotBlank", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012007")
    void case_UTAPI_012007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012007",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012007", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012007", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012007", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012007", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012007", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012007", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012007", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012007", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012007")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012008")
    void case_UTAPI_012008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012008",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012008", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012008", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012008", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012008", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012008", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012008", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012008", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012008", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012008")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012009")
    void case_UTAPI_012009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012009",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012009", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012009", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012009", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012009", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012009", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012009", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012009", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012009", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012009")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012010")
    void case_UTAPI_012010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012010",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012010", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012010", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012010", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012010", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012010", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012010", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012010", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012010", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012010")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012011")
    void case_UTAPI_012011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012011",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012011", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012011", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012011", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012011", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012011", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012011", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012011", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012011", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012011")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012012")
    void case_UTAPI_012012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012012",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012012", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012012", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012012", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012012", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012012", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012012", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012012", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012012", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012012")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012013")
    void case_UTAPI_012013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012013",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012013", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012013", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012013", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012013", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012013", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012013", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012013", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012013", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012013")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012014")
    void case_UTAPI_012014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012014",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012014", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012014", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012014", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012014", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012014", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012014", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012014", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012014", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012014")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012015")
    void case_UTAPI_012015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012015",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012015", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012015", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012015", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012015", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012015", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012015", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012015", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012015", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012015")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012016")
    void case_UTAPI_012016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012016",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012016", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012016", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012016", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012016", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012016", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012016", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012016", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012016", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012016")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012017")
    void case_UTAPI_012017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012017",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012017", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012017", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012017", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012017", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012017", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012017", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012017", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012017", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012017")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012018")
    void case_UTAPI_012018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012018",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012018", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012018", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012018", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012018", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012018", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012018", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012018", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012018", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012018")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012019")
    void case_UTAPI_012019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012019",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012019", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012019", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012019", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012019", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012019", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012019", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012019", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012019", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012019")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012020")
    void case_UTAPI_012020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012020",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012020", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012020", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012020", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012020", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012020", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012020", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012020", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012020", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012020")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012021")
    void case_UTAPI_012021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012021",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012021", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012021", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012021", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012021", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012021", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012021", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012021", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012021", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012021")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012022")
    void case_UTAPI_012022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012022",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012022", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012022", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012022", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012022", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012022", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012022", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012022", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012022", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012022")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012023")
    void case_UTAPI_012023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012023",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012023", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012023", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012023", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012023", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012023", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012023", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012023", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012023", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012023")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012024")
    void case_UTAPI_012024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012024",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012024", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012024", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012024", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012024", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012024", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012024", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012024", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012024", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012024")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012025")
    void case_UTAPI_012025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012025",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012025", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012025", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012025", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012025", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012025", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012025", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012025", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012025", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012025")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbName classifies this input condition", "ConnectionSettingRequest", "dbName", "NotBlank", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012026")
    void case_UTAPI_012026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012026",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012026", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012026", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012026", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012026", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012026", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012026", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012026", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012026", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012026")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012027")
    void case_UTAPI_012027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012027",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012027", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012027", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012027", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012027", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012027", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012027", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012027", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012027", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012027")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012028")
    void case_UTAPI_012028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012028",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012028", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012028", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012028", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012028", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012028", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012028", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012028", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012028", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012028")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012029")
    void case_UTAPI_012029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012029",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012029", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012029", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012029", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012029", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012029", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012029", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012029", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012029", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012029")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012030")
    void case_UTAPI_012030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012030",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012030", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012030", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012030", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012030", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012030", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012030", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012030", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012030", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012030")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012031")
    void case_UTAPI_012031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012031",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012031", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012031", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012031", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012031", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012031", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012031", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012031", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012031", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012031")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012032")
    void case_UTAPI_012032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012032",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012032", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012032", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012032", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012032", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012032", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012032", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012032", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012032", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012032")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012033")
    void case_UTAPI_012033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012033",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012033", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012033", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012033", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012033", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012033", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012033", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012033", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012033", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012033")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012034")
    void case_UTAPI_012034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012034",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012034", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012034", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012034", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012034", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012034", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012034", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012034", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012034", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012034")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012035")
    void case_UTAPI_012035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012035",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012035", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012035", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012035", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012035", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012035", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012035", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012035", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012035", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012035")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012036")
    void case_UTAPI_012036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012036",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012036", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012036", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012036", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012036", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012036", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012036", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012036", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012036", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012036")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012037")
    void case_UTAPI_012037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012037",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012037", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012037", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012037", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012037", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012037", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012037", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012037", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012037", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012037")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "56:space")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012038")
    void case_UTAPI_012038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012038",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012038", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012038", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012038", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012038", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012038", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012038", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012038", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012038", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012038")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012039")
    void case_UTAPI_012039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012039",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012039", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012039", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012039", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012039", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012039", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012039", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012039", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012039", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012039")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012040")
    void case_UTAPI_012040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012040",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012040", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012040", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012040", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012040", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012040", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012040", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012040", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012040", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012040")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012041")
    void case_UTAPI_012041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012041",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012041", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012041", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012041", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012041", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012041", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012041", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012041", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012041", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012041")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012042")
    void case_UTAPI_012042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012042",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012042", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012042", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012042", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012042", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012042", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012042", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012042", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012042", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012042")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012043")
    void case_UTAPI_012043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012043",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012043", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012043", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012043", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012043", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012043", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012043", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012043", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012043", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012043")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012044")
    void case_UTAPI_012044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012044",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012044", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012044", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012044", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012044", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012044", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012044", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012044", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012044", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012044")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012045")
    void case_UTAPI_012045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012045",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012045", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012045", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012045", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012045", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012045", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012045", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012045", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012045", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012045")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbPassword classifies this input condition", "ConnectionSettingRequest", "dbPassword", "NotBlank", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012046")
    void case_UTAPI_012046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012046",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012046", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012046", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012046", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012046", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012046", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012046", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012046", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012046", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012046")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012047")
    void case_UTAPI_012047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012047",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012047", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012047", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012047", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012047", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012047", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012047", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012047", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012047", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012047")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012048")
    void case_UTAPI_012048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012048",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012048", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012048", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012048", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012048", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012048", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012048", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012048", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012048", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012048")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012049")
    void case_UTAPI_012049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012049",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012049", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012049", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012049", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012049", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012049", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012049", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012049", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012049", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012049")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012050")
    void case_UTAPI_012050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012050",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012050", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012050", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012050", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012050", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012050", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012050", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012050", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012050", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012050")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012051")
    void case_UTAPI_012051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012051",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012051", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012051", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012051", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012051", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012051", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012051", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012051", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012051", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012051")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012052")
    void case_UTAPI_012052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012052",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012052", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012052", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012052", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012052", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012052", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012052", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012052", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012052", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012052")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012053")
    void case_UTAPI_012053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012053",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012053", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012053", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012053", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012053", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012053", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012053", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012053", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012053", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012053")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012054")
    void case_UTAPI_012054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012054",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012054", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012054", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012054", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012054", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012054", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012054", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012054", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012054", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012054")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012055")
    void case_UTAPI_012055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012055",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012055", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012055", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012055", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012055", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012055", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012055", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012055", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012055", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012055")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012056")
    void case_UTAPI_012056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012056",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012056", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012056", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012056", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012056", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012056", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012056", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012056", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012056", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012056")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012057")
    void case_UTAPI_012057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012057",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012057", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012057", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012057", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012057", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012057", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012057", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012057", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012057", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012057")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012058")
    void case_UTAPI_012058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012058",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012058", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012058", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012058", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012058", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012058", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012058", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012058", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012058", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012058")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012059")
    void case_UTAPI_012059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012059",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012059", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012059", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012059", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012059", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012059", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012059", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012059", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012059", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012059")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012060")
    void case_UTAPI_012060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012060",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012060", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012060", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012060", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012060", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012060", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012060", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012060", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012060", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012060")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012061")
    void case_UTAPI_012061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012061",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012061", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012061", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012061", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012061", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012061", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012061", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012061", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012061", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012061")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012062")
    void case_UTAPI_012062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012062",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012062", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012062", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012062", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012062", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012062", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012062", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012062", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012062", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012062")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012063")
    void case_UTAPI_012063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012063",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012063", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012063", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012063", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012063", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012063", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012063", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012063", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012063", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012063")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012064")
    void case_UTAPI_012064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012064",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012064", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012064", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012064", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012064", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012064", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012064", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012064", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012064", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012064")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012065")
    void case_UTAPI_012065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012065",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012065", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012065", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012065", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012065", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012065", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012065", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012065", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012065", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012065")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012066")
    void case_UTAPI_012066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012066",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012066", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012066", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012066", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012066", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012066", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012066", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012066", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012066", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012066")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012067")
    void case_UTAPI_012067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012067",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012067", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012067", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012067", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012067", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012067", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012067", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012067", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012067", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012067")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012068")
    void case_UTAPI_012068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012068",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012068", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012068", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012068", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012068", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012068", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012068", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012068", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012068", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012068")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012069")
    void case_UTAPI_012069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012069",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012069", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012069", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012069", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012069", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012069", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012069", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012069", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012069", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012069")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012070")
    void case_UTAPI_012070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012070",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012070", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012070", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012070", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012070", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012070", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012070", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012070", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012070", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012070")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012071")
    void case_UTAPI_012071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012071",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012071", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012071", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012071", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012071", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012071", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012071", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012071", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012071", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012071")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012072")
    void case_UTAPI_012072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012072",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012072", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012072", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012072", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012072", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012072", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012072", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012072", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012072", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012072")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012073")
    void case_UTAPI_012073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012073",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012073", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012073", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012073", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012073", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012073", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012073", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012073", "request.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012073", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012073")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012074")
    void case_UTAPI_012074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012074",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012074", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012074", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012074", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012074", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012074", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012074", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012074", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012074", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012074")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbUsername classifies this input condition", "ConnectionSettingRequest", "dbUsername", "NotBlank", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012075")
    void case_UTAPI_012075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012075",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012075", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012075", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012075", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012075", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012075", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012075", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012075", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012075", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012075")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012076")
    void case_UTAPI_012076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012076",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012076", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012076", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012076", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012076", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012076", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012076", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012076", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012076", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012076")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012077")
    void case_UTAPI_012077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012077",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012077", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012077", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012077", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012077", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012077", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012077", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012077", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012077", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012077")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012078")
    void case_UTAPI_012078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012078",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012078", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012078", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012078", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012078", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012078", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012078", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012078", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012078", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012078")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012079")
    void case_UTAPI_012079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012079",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012079", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012079", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012079", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012079", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012079", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012079", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012079", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012079", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012079")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012080")
    void case_UTAPI_012080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012080",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012080", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012080", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012080", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012080", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012080", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012080", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012080", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012080", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012080")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012081")
    void case_UTAPI_012081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012081",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012081", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012081", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012081", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012081", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012081", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012081", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012081", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012081", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012081")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012082")
    void case_UTAPI_012082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012082",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012082", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012082", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012082", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012082", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012082", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012082", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012082", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012082", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012082")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012083")
    void case_UTAPI_012083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012083",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012083", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012083", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012083", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012083", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012083", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012083", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012083", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012083", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012083")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012084")
    void case_UTAPI_012084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012084",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012084", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012084", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012084", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012084", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012084", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012084", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012084", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012084", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012084")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012085")
    void case_UTAPI_012085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012085",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012085", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012085", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012085", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012085", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012085", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012085", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012085", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012085", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012085")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012086")
    void case_UTAPI_012086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012086",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012086", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012086", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012086", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012086", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012086", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012086", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012086", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012086", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012086")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012087")
    void case_UTAPI_012087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012087",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012087", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012087", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012087", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012087", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012087", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012087", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012087", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012087", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012087")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012088")
    void case_UTAPI_012088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012088",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012088", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012088", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012088", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012088", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012088", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012088", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012088", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012088", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012088")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012089")
    void case_UTAPI_012089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012089",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012089", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012089", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012089", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012089", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012089", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012089", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012089", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012089", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012089")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012090")
    void case_UTAPI_012090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012090",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012090", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012090", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012090", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012090", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012090", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012090", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012090", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012090", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012090")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012091")
    void case_UTAPI_012091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012091",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012091", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012091", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012091", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012091", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012091", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012091", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012091", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012091", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012091")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012092")
    void case_UTAPI_012092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012092",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012092", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012092", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012092", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012092", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012092", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012092", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012092", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012092", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012092")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012093")
    void case_UTAPI_012093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012093",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n"),
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012093", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-012093", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012093", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012093", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012093", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012093", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012093", "request.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012093", "n", "NORMAL", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012093")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::update::4::FIELD::2::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.update")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.update", "connectionSettingRepository", "update")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.update must carry request.dbName", "connectionSettingRepository", "update", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.update must carry request.dbHost", "connectionSettingRepository", "update", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.update must carry request.dbPort", "connectionSettingRepository", "update", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.update must carry request.databaseName", "connectionSettingRepository", "update", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.update must carry request.dbUsername", "connectionSettingRepository", "update", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.update must carry request.dbPassword", "connectionSettingRepository", "update", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.ARG_FIELD_EQUALS, "getN of the object handed to connectionSettingRepository.update must carry n", "connectionSettingRepository", "update", "0", "getN", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMemoRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMemoRepository#upsert.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMemoRepositoryUpsertScenario {

    @Test
    @DisplayName("UTAPI-008808")
    void case_UTAPI_008808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008808",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008808", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008808", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008808", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008808", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008808", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008808", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008808", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008808")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008809")
    void case_UTAPI_008809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008809",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008809", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008809", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008809", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008809", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008809", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008809", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008809", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008809")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008810")
    void case_UTAPI_008810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008810",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008810", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008810", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008810", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008810", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008810", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008810", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008810", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008810")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008811")
    void case_UTAPI_008811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008811",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008811", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008811", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008811", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008811", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008811", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008811", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008811", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008811")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008812")
    void case_UTAPI_008812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008812",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008812", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008812", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008812", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008812", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008812", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008812", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008812", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008812")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008813")
    void case_UTAPI_008813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008813",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008813", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008813", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008813", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008813", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008813", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008813", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008813", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008813")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008814")
    void case_UTAPI_008814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008814",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008814", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008814", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008814", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008814", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008814", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008814", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008814", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008814")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008815")
    void case_UTAPI_008815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008815",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008815", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008815", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008815", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008815", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008815", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008815", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008815", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008815")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008816")
    void case_UTAPI_008816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008816",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008816", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008816", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008816", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008816", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008816", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008816", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008816", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008816")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008817")
    void case_UTAPI_008817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008817",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008817", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008817", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008817", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008817", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008817", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008817", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008817", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008817")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008818")
    void case_UTAPI_008818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008818",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008818", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008818", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008818", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008818", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008818", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008818", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008818", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008818")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008819")
    void case_UTAPI_008819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008819",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008819", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008819", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008819", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008819", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008819", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008819", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008819", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008819")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008820")
    void case_UTAPI_008820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008820",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008820", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008820", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008820", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008820", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008820", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008820", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008820", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008820")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "56:space")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008821")
    void case_UTAPI_008821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008821",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008821", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008821", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008821", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008821", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008821", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008821", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008821", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008821")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008822")
    void case_UTAPI_008822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008822",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008822", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008822", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008822", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008822", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008822", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008822", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008822", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008822")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008823")
    void case_UTAPI_008823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008823",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008823", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008823", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008823", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008823", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008823", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008823", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008823", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008823")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "59:tab")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008824")
    void case_UTAPI_008824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008824",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008824", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008824", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008824", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008824", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008824", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008824", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008824", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008824")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008825")
    void case_UTAPI_008825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008825",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008825", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008825", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008825", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008825", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008825", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008825", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008825", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008825")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008826")
    void case_UTAPI_008826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008826",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008826", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008826", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008826", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008826", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008826", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008826", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008826", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008826")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008827")
    void case_UTAPI_008827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008827",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008827", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008827", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008827", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008827", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008827", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008827", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008827", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008827")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008828")
    void case_UTAPI_008828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008828",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008828", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008828", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008828", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008828", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008828", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008828", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008828", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008828")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008829")
    void case_UTAPI_008829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008829",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008829", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008829", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008829", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008829", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008829", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008829", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008829", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008829")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008830")
    void case_UTAPI_008830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008830",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008830", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008830", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008830", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008830", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008830", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008830", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008830", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008830")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008831")
    void case_UTAPI_008831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008831",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008831", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008831", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008831", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008831", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008831", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008831", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008831", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008831")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008832")
    void case_UTAPI_008832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008832",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008832", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008832", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008832", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008832", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008832", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008832", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008832", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008832")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008833")
    void case_UTAPI_008833() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008833",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008833", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008833", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008833", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008833", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008833", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008833", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008833", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008833")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008834")
    void case_UTAPI_008834() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008834",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008834", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008834", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008834", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008834", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008834", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008834", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008834", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008834")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008835")
    void case_UTAPI_008835() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008835",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008835", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008835", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008835", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008835", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008835", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008835", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008835", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008835")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008836")
    void case_UTAPI_008836() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008836",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008836", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008836", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008836", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008836", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008836", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008836", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008836", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008836")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008837")
    void case_UTAPI_008837() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008837",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008837", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008837", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008837", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008837", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008837", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008837", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008837", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008837")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008838")
    void case_UTAPI_008838() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008838",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008838", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008838", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008838", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008838", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008838", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008838", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008838", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008838")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008839")
    void case_UTAPI_008839() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008839",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008839", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008839", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008839", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008839", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008839", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008839", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008839", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008839")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008840")
    void case_UTAPI_008840() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008840",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008840", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008840", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008840", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008840", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008840", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008840", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008840", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008840")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008841")
    void case_UTAPI_008841() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008841",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008841", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008841", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008841", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008841", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008841", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008841", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008841", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008841")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008842")
    void case_UTAPI_008842() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008842",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008842", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008842", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008842", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008842", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008842", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008842", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008842", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008842")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008843")
    void case_UTAPI_008843() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008843",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008843", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008843", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008843", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008843", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008843", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008843", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008843", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008843")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008844")
    void case_UTAPI_008844() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008844",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008844", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008844", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008844", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008844", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008844", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008844", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008844", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008844")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008845")
    void case_UTAPI_008845() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008845",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008845", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008845", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008845", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008845", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008845", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008845", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008845", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008845")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008846")
    void case_UTAPI_008846() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008846",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008846", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008846", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008846", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008846", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008846", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008846", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008846", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008846")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008847")
    void case_UTAPI_008847() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008847",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008847", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008847", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008847", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008847", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008847", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008847", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008847", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008847")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008848")
    void case_UTAPI_008848() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008848",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008848", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008848", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008848", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008848", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008848", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008848", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008848", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008848")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008849")
    void case_UTAPI_008849() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008849",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008849", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008849", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008849", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008849", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008849", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008849", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008849", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008849")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008850")
    void case_UTAPI_008850() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008850",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008850", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008850", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008850", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008850", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008850", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008850", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008850", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008850")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008851")
    void case_UTAPI_008851() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008851",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008851", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008851", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008851", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008851", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008851", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008851", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008851", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008851")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008852")
    void case_UTAPI_008852() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008852",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008852", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008852", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008852", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008852", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008852", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008852", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008852", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008852")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008853")
    void case_UTAPI_008853() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008853",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008853", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008853", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008853", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008853", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008853", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008853", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008853", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008853")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008854")
    void case_UTAPI_008854() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008854",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008854", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008854", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008854", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008854", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008854", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008854", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008854", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008854")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008855")
    void case_UTAPI_008855() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008855",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008855", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008855", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008855", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008855", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008855", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008855", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008855", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008855")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008856")
    void case_UTAPI_008856() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008856",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008856", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008856", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008856", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008856", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008856", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008856", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008856", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008856")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008857")
    void case_UTAPI_008857() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008857",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008857", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008857", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008857", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008857", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008857", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008857", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008857", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008857")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008858")
    void case_UTAPI_008858() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008858",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008858", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008858", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008858", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008858", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008858", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008858", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008858", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008858")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008859")
    void case_UTAPI_008859() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008859",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008859", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008859", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008859", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008859", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008859", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008859", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008859", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008859")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008860")
    void case_UTAPI_008860() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008860",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008860", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008860", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008860", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008860", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008860", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008860", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008860", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008860")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "56:space")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008861")
    void case_UTAPI_008861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008861",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008861", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008861", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008861", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008861", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008861", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008861", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008861", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008861")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008862")
    void case_UTAPI_008862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008862",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008862", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008862", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008862", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008862", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008862", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008862", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008862", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008862")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008863")
    void case_UTAPI_008863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008863",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008863", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008863", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008863", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008863", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008863", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008863", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008863", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008863")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "59:tab")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008864")
    void case_UTAPI_008864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008864",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008864", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008864", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008864", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008864", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008864", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008864", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008864", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008864")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008865")
    void case_UTAPI_008865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008865",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008865", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008865", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008865", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008865", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008865", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008865", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008865", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008865")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008866")
    void case_UTAPI_008866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008866",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008866", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008866", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008866", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008866", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008866", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008866", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008866", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008866")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008867")
    void case_UTAPI_008867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008867",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008867", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008867", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008867", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008867", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008867", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-008867", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008867", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008867")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008868")
    void case_UTAPI_008868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008868",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008868", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008868", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008868", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008868", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008868", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008868", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008868", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008868")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008869")
    void case_UTAPI_008869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008869",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008869", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008869", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008869", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008869", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008869", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008869", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008869", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008869")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008870")
    void case_UTAPI_008870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008870",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008870", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008870", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008870", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008870", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008870", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008870", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008870", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008870")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008871")
    void case_UTAPI_008871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008871",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008871", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008871", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008871", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008871", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008871", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008871", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008871", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008871")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008872")
    void case_UTAPI_008872() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008872",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008872", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008872", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008872", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008872", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008872", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008872", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008872", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008872")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008873")
    void case_UTAPI_008873() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008873",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008873", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008873", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008873", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008873", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008873", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008873", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008873", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008873")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008874")
    void case_UTAPI_008874() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008874",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008874", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008874", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008874", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008874", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008874", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008874", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008874", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008874")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008875")
    void case_UTAPI_008875() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008875",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008875", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008875", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008875", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008875", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008875", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008875", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008875", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008875")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008876")
    void case_UTAPI_008876() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008876",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008876", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008876", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008876", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008876", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008876", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008876", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008876", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008876")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008877")
    void case_UTAPI_008877() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008877",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008877", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008877", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008877", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008877", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008877", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008877", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008877", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008877")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008878")
    void case_UTAPI_008878() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008878",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008878", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008878", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008878", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008878", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008878", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008878", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008878", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008878")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008879")
    void case_UTAPI_008879() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008879",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008879", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008879", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008879", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008879", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008879", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008879", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008879", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008879")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008880")
    void case_UTAPI_008880() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008880",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008880", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008880", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008880", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008880", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008880", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008880", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008880", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008880")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008881")
    void case_UTAPI_008881() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008881",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008881", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008881", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008881", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008881", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008881", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008881", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008881", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008881")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008882")
    void case_UTAPI_008882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008882",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008882", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008882", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008882", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008882", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008882", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008882", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008882", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008882")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008883")
    void case_UTAPI_008883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008883",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008883", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008883", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008883", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008883", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008883", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008883", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008883", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008883")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008884")
    void case_UTAPI_008884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008884",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008884", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008884", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008884", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008884", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008884", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008884", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008884", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008884")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008885")
    void case_UTAPI_008885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008885",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008885", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008885", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008885", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008885", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008885", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008885", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008885", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008885")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-008886")
    void case_UTAPI_008886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-008886",
                "com.matsushita.dbeditor.domain.repository.TableMemoRepository",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-008886", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-008886", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008886", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-008886", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008886", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-008886", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-008886", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-008886")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableMemoRepository.java::TableMemoRepository::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoRepositoryWrapper());
    }

}

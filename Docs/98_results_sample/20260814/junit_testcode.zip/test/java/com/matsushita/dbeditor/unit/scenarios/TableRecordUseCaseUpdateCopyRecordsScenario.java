package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordUseCase#updateCopyRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordUseCaseUpdateCopyRecordsScenario {

    @Test
    @DisplayName("UTAPI-013524")
    void case_UTAPI_013524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013524",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013524", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013524", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013524", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013524", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013524", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013524")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013525")
    void case_UTAPI_013525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013525",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013525", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013525", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013525", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013525", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013525", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013525")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013526")
    void case_UTAPI_013526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013526",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013526", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013526", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013526", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013526", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013526", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013526")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013527")
    void case_UTAPI_013527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013527",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013527", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013527", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013527", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013527", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013527", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013527")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013528")
    void case_UTAPI_013528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013528",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013528", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013528", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013528", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013528", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013528", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013528")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013529")
    void case_UTAPI_013529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013529",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013529", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013529", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013529", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013529", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013529", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013529")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013530")
    void case_UTAPI_013530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013530",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013530", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013530", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013530", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013530", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013530", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013530")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013531")
    void case_UTAPI_013531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013531",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013531", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013531", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013531", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013531", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013531", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013531")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013532")
    void case_UTAPI_013532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013532",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013532", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013532", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013532", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013532", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013532", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013532")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013533")
    void case_UTAPI_013533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013533",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013533", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013533", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013533", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013533", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013533", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013533")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013534")
    void case_UTAPI_013534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013534",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013534", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013534", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013534", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013534", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013534", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013534")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013535")
    void case_UTAPI_013535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013535",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013535", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013535", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013535", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013535", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013535", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013535", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013535")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013536")
    void case_UTAPI_013536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013536",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013536", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013536", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013536", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013536", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013536", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013536", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013536")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013537")
    void case_UTAPI_013537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013537",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013537", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013537", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013537", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013537", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013537", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013537", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013537")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013538")
    void case_UTAPI_013538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013538",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013538", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013538", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013538", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013538", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013538", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013538", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013538")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013539")
    void case_UTAPI_013539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013539",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013539", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013539", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013539", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013539", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013539", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013539", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013539")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013540")
    void case_UTAPI_013540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013540",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013540", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013540", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013540", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013540", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013540", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013540", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013540")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013541")
    void case_UTAPI_013541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013541",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013541", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013541", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013541", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013541", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013541", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013541", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013541")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013542")
    void case_UTAPI_013542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013542",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013542", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013542", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013542", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013542", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013542", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013542", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013542")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013543")
    void case_UTAPI_013543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013543",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013543", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013543", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013543", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013543", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013543", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013543", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013543")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013544")
    void case_UTAPI_013544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013544",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013544", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013544", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013544", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013544", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013544", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013544", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013544")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013545")
    void case_UTAPI_013545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013545",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013545", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013545", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013545", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013545", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013545", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013545", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013545")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013546")
    void case_UTAPI_013546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013546",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013546", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013546", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013546", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013546", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013546", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013546", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013546")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013547")
    void case_UTAPI_013547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013547",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013547", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013547", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013547", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013547", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013547", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013547", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013547")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013548")
    void case_UTAPI_013548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013548",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013548", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013548", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013548", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013548", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013548", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013548", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013548")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013549")
    void case_UTAPI_013549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013549",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013549", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013549", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013549", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013549", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013549", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013549", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013549")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013550")
    void case_UTAPI_013550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013550",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013550", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013550", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013550", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013550", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013550", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013550", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013550")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013551")
    void case_UTAPI_013551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013551",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013551", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013551", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013551", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013551", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013551", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013551", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013551")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013552")
    void case_UTAPI_013552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013552",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013552", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013552", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013552", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013552", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013552", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013552", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013552")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013553")
    void case_UTAPI_013553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013553",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013553", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013553", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013553", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013553", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013553", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013553", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013553")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013554")
    void case_UTAPI_013554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013554",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013554", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013554", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013554", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013554", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013554", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013554", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013554")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013555")
    void case_UTAPI_013555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013555",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013555", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013555", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013555", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013555", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013555", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013555", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013555")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013556")
    void case_UTAPI_013556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013556",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013556", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013556", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013556", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013556", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013556", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013556", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013556")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013557")
    void case_UTAPI_013557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013557",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013557", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013557", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013557", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013557", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013557", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013557", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013557")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013558")
    void case_UTAPI_013558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013558",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013558", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013558", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013558", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013558", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013558", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013558", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013558")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013559")
    void case_UTAPI_013559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013559",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013559", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013559", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013559", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013559", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013559", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013559", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013559")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013560")
    void case_UTAPI_013560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013560",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013560", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013560", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013560", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013560", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013560", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013560", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013560")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013561")
    void case_UTAPI_013561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013561",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013561", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013561", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013561", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013561", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013561", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013561", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013561")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013562")
    void case_UTAPI_013562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013562",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013562", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013562", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013562", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013562", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013562", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013562", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013562")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013563")
    void case_UTAPI_013563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013563",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013563", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013563", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013563", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013563", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013563", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013563", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013563")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013564")
    void case_UTAPI_013564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013564",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013564", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013564", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013564", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013564", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013564", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013564", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013564")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013565")
    void case_UTAPI_013565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013565",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013565", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013565", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013565", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013565", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013565", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013565", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013565")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013566")
    void case_UTAPI_013566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013566",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013566", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013566", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013566", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013566", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013566", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013566", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013566")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013567")
    void case_UTAPI_013567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013567",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013567", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013567", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013567", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013567", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013567", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013567", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013567")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013568")
    void case_UTAPI_013568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013568",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013568", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013568", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013568", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013568", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013568", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013568", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013568")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013569")
    void case_UTAPI_013569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013569",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013569", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013569", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013569", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013569", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013569", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013569", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013569")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013570")
    void case_UTAPI_013570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013570",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013570", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013570", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013570", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013570", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013570", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013570", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013570")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013571")
    void case_UTAPI_013571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013571",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013571", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013571", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013571", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013571", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013571", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013571", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013571")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013572")
    void case_UTAPI_013572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013572",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013572", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013572", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013572", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013572", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013572", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013572", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013572")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013573")
    void case_UTAPI_013573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013573",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013573", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013573", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013573", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013573", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013573", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013573", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013573")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013574")
    void case_UTAPI_013574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013574",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013574", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013574", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013574", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013574", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013574", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013574", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013574")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013575")
    void case_UTAPI_013575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013575",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013575", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013575", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013575", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013575", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013575", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013575", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013575")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013576")
    void case_UTAPI_013576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013576",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013576", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013576", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013576", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013576", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013576", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013576", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013576")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013577")
    void case_UTAPI_013577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013577",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013577", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013577", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013577", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013577", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013577", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013577")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "1:length_null", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013578")
    void case_UTAPI_013578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013578",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013578", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013578", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013578", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013578", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013578", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013578")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013579")
    void case_UTAPI_013579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013579",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013579", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013579", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013579", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013579", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013579", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013579")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "3:length_min", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013580")
    void case_UTAPI_013580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013580",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013580", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013580", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013580", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013580", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013580", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013580")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013581")
    void case_UTAPI_013581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013581",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013581", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013581", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013581", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013581", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013581", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013581")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "5:length_max", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013582")
    void case_UTAPI_013582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013582",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013582", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013582", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013582", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013582", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013582", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013582")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013583")
    void case_UTAPI_013583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013583",
                "com.matsushita.dbeditor.usecase.table.TableRecordUseCase",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013583", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-013583", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-013583", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013583", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-013583", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-013583")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableRecordUseCase.java::TableRecordUseCase::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableRecordRepository.updateCopyRecords")
                    .expected("the value generated for records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordRepository.updateCopyRecords", "tableRecordRepository", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordRepository.updateCopyRecords must carry the value generated for schemaName", "tableRecordRepository", "updateCopyRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordRepository.updateCopyRecords must carry the value generated for tableName", "tableRecordRepository", "updateCopyRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordRepository.updateCopyRecords must carry the value generated for records", "tableRecordRepository", "updateCopyRecords", "3", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordUseCaseWrapper());
    }

}

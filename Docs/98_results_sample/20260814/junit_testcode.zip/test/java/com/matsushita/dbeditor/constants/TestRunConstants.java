package com.matsushita.dbeditor.constants;

/**
 * Test side constants shared by every generated scenario.
 */
public final class TestRunConstants {

    private TestRunConstants() {
    }

    /** Data role names used by test-data-instruction. */
    public static final String ROLE_TARGET = "TARGET";
    public static final String ROLE_NORMAL = "NORMAL";

    /** Run mode forwarded to TestDataRuntime for Evidence / Replay. */
    public static final String RUN_MODE_PROPERTY = "testdata.runMode";
    public static final String RUN_MODE_DEFAULT = "NORMAL";

    /** System property that can override the TestDataRuntime class name. */
    public static final String RUNTIME_CLASS_PROPERTY = "testdata.runtime.class";

    /** Element index used by Evidence for a scalar or direct root value. */
    public static final int ELEMENT_INDEX_ROOT = -1;

    /** Schema like default used when a SUT constructor requires a plain String. */
    public static final String DEFAULT_SCHEMA = "public";

    public static String runMode() {
        String value = System.getProperty(RUN_MODE_PROPERTY);
        if (value == null || value.trim().isEmpty()) {
            return RUN_MODE_DEFAULT;
        } else {
            return value.trim();
        }
    }
}

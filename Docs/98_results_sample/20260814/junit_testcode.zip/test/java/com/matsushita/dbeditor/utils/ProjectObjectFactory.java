package com.matsushita.dbeditor.utils;

import java.lang.reflect.Method;
import java.util.List;

import com.matsushita.dbeditor.fixtures.FrameworkObjects;
import com.matsushita.dbeditor.fixtures.SentinelRegistry;

/**
 * Assembles project specific DTO and Object graphs on the test side.
 *
 * <p>TestDataRuntime owns every concrete value. This factory only wires the values it
 * returns into the object structure that AST Field Level declares, using the constructors
 * and setters that the target project actually provides.</p>
 */
public final class ProjectObjectFactory {

    private ProjectObjectFactory() {
    }

    public static Object build(String caseNo, List<DataRef> allRefs, DataRef root, String mirrorY,
            boolean excelFlavour, SentinelRegistry registry, java.util.Map<String, Object> collector) {
        Object built = buildInternal(caseNo, allRefs, root, mirrorY, excelFlavour, registry, collector);
        collector.put(root.dataId(), built);
        return built;
    }

    private static Object buildInternal(String caseNo, List<DataRef> allRefs, DataRef root, String mirrorY,
            boolean excelFlavour, SentinelRegistry registry, java.util.Map<String, Object> collector) {
        String convModel = root.convModel();
        if (!"OBJECT".equals(convModel)) {
            return TestDataAccess.getValue(caseNo, root.dataId(), TypeSupport.receivingType(root.referenceType()));
        }
        String refType = TypeSupport.raw(root.referenceType());
        if (FrameworkObjects.handles(refType)) {
            return FrameworkObjects.build(refType, mirrorY, excelFlavour, registry);
        }
        if (!ProjectTypes.isProjectType(refType)) {
            return TestDataAccess.getValue(caseNo, root.dataId(), TypeSupport.receivingType(refType));
        }
        if (mirrorY != null && mirrorY.contains("length_null")) {
            return null;
        }
        Class<?> type = ProjectTypes.load(refType);
        Object instance = instantiate(type);
        String prefix = root.dataId() + ".";
        for (int i = 0; i < allRefs.size(); i++) {
            DataRef child = allRefs.get(i);
            String id = child.dataId();
            if (!id.startsWith(prefix)) {
                continue;
            }
            String rest = id.substring(prefix.length());
            if (rest.indexOf('.') >= 0 || rest.indexOf('[') >= 0 || rest.indexOf('{') >= 0) {
                continue;
            }
            Object value = build(caseNo, allRefs, child, "-", excelFlavour, registry, collector);
            apply(instance, type, rest, value);
        }
        return instance;
    }

    private static Object instantiate(Class<?> type) {
        try {
            java.lang.reflect.Constructor<?> ctor = type.getDeclaredConstructor();
            ctor.setAccessible(true);
            return ctor.newInstance();
        } catch (NoSuchMethodException e) {
            java.lang.reflect.Constructor<?>[] ctors = type.getDeclaredConstructors();
            java.lang.reflect.Constructor<?> best = null;
            for (int i = 0; i < ctors.length; i++) {
                if (best == null || ctors[i].getParameterCount() < best.getParameterCount()) {
                    best = ctors[i];
                }
            }
            if (best == null) {
                throw new HarnessException("No constructor on " + type.getName(), e);
            }
            try {
                best.setAccessible(true);
                Class<?>[] p = best.getParameterTypes();
                Object[] args = new Object[p.length];
                for (int i = 0; i < p.length; i++) {
                    args[i] = defaultOf(p[i]);
                }
                return best.newInstance(args);
            } catch (Exception inner) {
                throw new HarnessException("Cannot instantiate " + type.getName(), inner);
            }
        } catch (Exception e) {
            throw new HarnessException("Cannot instantiate " + type.getName(), e);
        }
    }

    private static Object defaultOf(Class<?> type) {
        if (!type.isPrimitive()) {
            return null;
        }
        if (type == boolean.class) {
            return Boolean.FALSE;
        }
        if (type == long.class) {
            return Long.valueOf(0L);
        }
        if (type == double.class) {
            return Double.valueOf(0d);
        }
        if (type == float.class) {
            return Float.valueOf(0f);
        }
        if (type == char.class) {
            return Character.valueOf(' ');
        }
        return Integer.valueOf(0);
    }

    private static void apply(Object instance, Class<?> type, String fieldName, Object value) {
        String setter = "set" + Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1);
        Method[] methods = type.getMethods();
        for (int i = 0; i < methods.length; i++) {
            Method m = methods[i];
            if (m.getName().equals(setter) && m.getParameterCount() == 1) {
                try {
                    m.setAccessible(true);
                    m.invoke(instance, coerce(value, m.getParameterTypes()[0]));
                    return;
                } catch (Exception e) {
                    throw new HarnessException("Setter " + setter + " failed on " + type.getName(), e);
                }
            }
        }
        try {
            java.lang.reflect.Field f = declaredField(type, fieldName);
            if (f == null) {
                throw new HarnessException("Field " + fieldName + " not found on " + type.getName());
            }
            f.setAccessible(true);
            f.set(instance, coerce(value, f.getType()));
        } catch (HarnessException e) {
            throw e;
        } catch (Exception e) {
            throw new HarnessException("Cannot set " + fieldName + " on " + type.getName(), e);
        }
    }

    private static java.lang.reflect.Field declaredField(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException e) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    private static Object coerce(Object value, Class<?> target) {
        if (value == null) {
            return defaultOf(target);
        }
        if (target.isInstance(value)) {
            return value;
        }
        if (value instanceof Number) {
            Number n = (Number) value;
            if (target == int.class || target == Integer.class) {
                return Integer.valueOf(n.intValue());
            }
            if (target == long.class || target == Long.class) {
                return Long.valueOf(n.longValue());
            }
            if (target == double.class || target == Double.class) {
                return Double.valueOf(n.doubleValue());
            }
            if (target == float.class || target == Float.class) {
                return Float.valueOf(n.floatValue());
            }
            if (target == short.class || target == Short.class) {
                return Short.valueOf(n.shortValue());
            }
            if (target == byte.class || target == Byte.class) {
                return Byte.valueOf(n.byteValue());
            }
        }
        if (target == String.class) {
            return String.valueOf(value);
        }
        return value;
    }
}

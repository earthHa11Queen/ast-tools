package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SavedSqlGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SavedSqlGateway#findAllByConnectionId.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SavedSqlGatewayFindAllByConnectionIdScenario {

    @Test
    @DisplayName("UTAPI-002943")
    void case_UTAPI_002943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002943",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002943", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002943")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002944")
    void case_UTAPI_002944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002944",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002944", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002944")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002945")
    void case_UTAPI_002945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002945",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002945", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002945")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002946")
    void case_UTAPI_002946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002946",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002946", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002946")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002947")
    void case_UTAPI_002947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002947",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002947", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002947")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002948")
    void case_UTAPI_002948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002948",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002948", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002948")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002949")
    void case_UTAPI_002949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002949",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002949", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002949")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002950")
    void case_UTAPI_002950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002950",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002950", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002950")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002951")
    void case_UTAPI_002951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002951",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002951", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002951")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002952")
    void case_UTAPI_002952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002952",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002952", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002952")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002953")
    void case_UTAPI_002953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002953",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "findAllByConnectionId",
                "List<SavedSql>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002953", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002953")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::findAllByConnectionId::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for connectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the listing must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for connectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:connectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConflictUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConflictUseCase#createBackup.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConflictUseCaseCreateBackupScenario {

    @Test
    @DisplayName("UTAPI-011602")
    void case_UTAPI_011602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011602",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011602", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011602", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011602")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011603")
    void case_UTAPI_011603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011603",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011603", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011603", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011603")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011604")
    void case_UTAPI_011604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011604",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011604", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011604", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011604")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011605")
    void case_UTAPI_011605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011605",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011605", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011605", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011605")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011606")
    void case_UTAPI_011606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011606",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011606", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011606", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011606")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011607")
    void case_UTAPI_011607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011607",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011607", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011607", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011607")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011608")
    void case_UTAPI_011608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011608",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011608", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011608", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011608")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011609")
    void case_UTAPI_011609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011609",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011609", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011609", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011609")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011610")
    void case_UTAPI_011610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011610",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011610", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011610", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011610")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011611")
    void case_UTAPI_011611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011611",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011611", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011611", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011611")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011612")
    void case_UTAPI_011612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011612",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011612", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011612", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011612")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011613")
    void case_UTAPI_011613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011613",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011613", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011613", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011613")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011614")
    void case_UTAPI_011614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011614",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011614", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011614", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011614")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011615")
    void case_UTAPI_011615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011615",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011615", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011615", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011615")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011616")
    void case_UTAPI_011616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011616",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011616", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011616", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011616")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011617")
    void case_UTAPI_011617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011617",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011617", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011617", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011617")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011618")
    void case_UTAPI_011618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011618",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011618", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011618", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011618")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011619")
    void case_UTAPI_011619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011619",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011619", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011619", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011619")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011620")
    void case_UTAPI_011620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011620",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011620", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011620", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011620", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011620")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011621")
    void case_UTAPI_011621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011621",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011621", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011621", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011621", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011621")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011622")
    void case_UTAPI_011622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011622",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011622", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011622", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011622", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011622")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011623")
    void case_UTAPI_011623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011623",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011623", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011623", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011623", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011623")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011624")
    void case_UTAPI_011624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011624",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011624", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011624", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011624", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011624")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011625")
    void case_UTAPI_011625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011625",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011625", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011625", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011625")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011626")
    void case_UTAPI_011626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011626",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011626", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011626", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011626")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011627")
    void case_UTAPI_011627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011627",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011627", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011627", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011627")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011628")
    void case_UTAPI_011628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011628",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011628", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011628", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011628", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011628")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011629")
    void case_UTAPI_011629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011629",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011629", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011629", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011629", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011629")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011630")
    void case_UTAPI_011630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011630",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011630", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011630", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011630", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011630")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011631")
    void case_UTAPI_011631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011631",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011631", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011631", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011631", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011631")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011632")
    void case_UTAPI_011632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011632",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011632", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011632", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011632")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011633")
    void case_UTAPI_011633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011633",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011633", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011633", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011633")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011634")
    void case_UTAPI_011634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011634",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011634", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011634", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011634", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011634")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011635")
    void case_UTAPI_011635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011635",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011635", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011635", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011635", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011635")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011636")
    void case_UTAPI_011636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011636",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011636", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011636", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011636", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011636")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011637")
    void case_UTAPI_011637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011637",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011637", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011637", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011637", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011637")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011638")
    void case_UTAPI_011638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011638",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011638", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011638", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011638", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011638")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011639")
    void case_UTAPI_011639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011639",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011639", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011639", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011639", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011639")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011640")
    void case_UTAPI_011640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011640",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011640", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011640", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011640", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011640")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011641")
    void case_UTAPI_011641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011641",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011641", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011641", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011641", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011641")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011642")
    void case_UTAPI_011642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011642",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011642", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011642", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011642", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011642")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011643")
    void case_UTAPI_011643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011643",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011643", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011643", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011643", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011643")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011644")
    void case_UTAPI_011644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011644",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011644", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011644", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011644", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011644")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011645")
    void case_UTAPI_011645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011645",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011645", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011645", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011645", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011645")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011646")
    void case_UTAPI_011646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011646",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011646", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011646", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011646", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011646")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011647")
    void case_UTAPI_011647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011647",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011647", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011647", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011647", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011647")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011648")
    void case_UTAPI_011648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011648",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011648", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011648", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011648", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011648")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011649")
    void case_UTAPI_011649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011649",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011649", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011649", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011649", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011649")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011650")
    void case_UTAPI_011650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011650",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011650", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011650", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011650", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011650")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011651")
    void case_UTAPI_011651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011651",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011651", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011651", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011651", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011651")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011652")
    void case_UTAPI_011652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011652",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011652", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011652", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011652", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011652")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011653")
    void case_UTAPI_011653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011653",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011653", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011653", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011653", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011653")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011654")
    void case_UTAPI_011654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011654",
                "com.matsushita.dbeditor.usecase.conflict.ConflictUseCase",
                "createBackup",
                "void",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011654", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011654", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011654", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011654")
                    .targetId("./java/com/matsushita/dbeditor/usecase/conflict/ConflictUseCase.java::ConflictUseCase::createBackup::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableConflictRepository.createBackup")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableConflictRepository.createBackup", "tableConflictRepository", "createBackup")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableConflictRepository.createBackup must carry the value generated for schemaName", "tableConflictRepository", "createBackup", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableConflictRepository.createBackup must carry the value generated for tableName", "tableConflictRepository", "createBackup", "2", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConflictUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateUseCase#deleteMemoTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateUseCaseDeleteMemoTemplateScenario {

    @Test
    @DisplayName("UTAPI-012745")
    void case_UTAPI_012745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012745",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012745", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012745")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012746")
    void case_UTAPI_012746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012746",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012746", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012746")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012747")
    void case_UTAPI_012747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012747",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012747", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012747")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012748")
    void case_UTAPI_012748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012748",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012748", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012748")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012749")
    void case_UTAPI_012749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012749",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012749", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012749")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012750")
    void case_UTAPI_012750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012750",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012750", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012750")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012751")
    void case_UTAPI_012751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012751",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012751", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012751")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012752")
    void case_UTAPI_012752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012752",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012752", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012752")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012753")
    void case_UTAPI_012753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012753",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012753", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012753")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012754")
    void case_UTAPI_012754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012754",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012754", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012754")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012755")
    void case_UTAPI_012755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012755",
                "com.matsushita.dbeditor.usecase.file.TemplateUseCase",
                "deleteMemoTemplate",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012755", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012755")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/TemplateUseCase.java::TemplateUseCase::deleteMemoTemplate::3::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of memoTemplateRepository.deleteById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through memoTemplateRepository.deleteById", "memoTemplateRepository", "deleteById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of memoTemplateRepository.deleteById must carry the value generated for n", "memoTemplateRepository", "deleteById", "0", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TemplateUseCaseWrapper());
    }

}

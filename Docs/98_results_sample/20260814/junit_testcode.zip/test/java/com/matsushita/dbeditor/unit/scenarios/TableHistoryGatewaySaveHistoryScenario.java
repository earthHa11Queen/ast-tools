package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryGateway#saveHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryGatewaySaveHistoryScenario {

    @Test
    @DisplayName("UTAPI-004497")
    void case_UTAPI_004497() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004497",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004497", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004497", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004497", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004497", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004497", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004497", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004497", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004497", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004497", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004497", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004497")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004498")
    void case_UTAPI_004498() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004498",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004498", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004498", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004498", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004498", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004498", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004498", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004498", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004498", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004498", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004498", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004498")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004499")
    void case_UTAPI_004499() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004499",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004499", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004499", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004499", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004499", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004499", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004499", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004499", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004499", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004499", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004499", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004499")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004500")
    void case_UTAPI_004500() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004500",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004500", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004500", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004500", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004500", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004500", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004500", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004500", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004500", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004500", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004500", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004500")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004501")
    void case_UTAPI_004501() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004501",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004501", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004501", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004501", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004501", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004501", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004501", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004501", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004501", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004501", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004501", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004501")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004502")
    void case_UTAPI_004502() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004502",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004502", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004502", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004502", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004502", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004502", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004502", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004502", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004502", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004502", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004502", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004502")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004503")
    void case_UTAPI_004503() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004503",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004503", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004503", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004503", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004503", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004503", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004503", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004503", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004503", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004503", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004503", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004503")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004504")
    void case_UTAPI_004504() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004504",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004504", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004504", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004504", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004504", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004504", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004504", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004504", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004504", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004504", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004504", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004504")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004505")
    void case_UTAPI_004505() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004505",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004505", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004505", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004505", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004505", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004505", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004505", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004505", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004505", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004505", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004505", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004505", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004505", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004505", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004505", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004505", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004505", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004505")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004506")
    void case_UTAPI_004506() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004506",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004506", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004506", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004506", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004506", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004506", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004506", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004506", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004506", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004506", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004506", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004506", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004506", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004506", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004506", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004506", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004506", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004506")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004507")
    void case_UTAPI_004507() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004507",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004507", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004507", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004507", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004507", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004507", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004507", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004507", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004507", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004507", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004507", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004507", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004507", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004507", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004507", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004507", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004507", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004507")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004508")
    void case_UTAPI_004508() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004508",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004508", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004508", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004508", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004508", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004508", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004508", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004508", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004508", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004508", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004508", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004508", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004508", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004508", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004508", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004508", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004508", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004508")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004509")
    void case_UTAPI_004509() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004509",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004509", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004509", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004509", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004509", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004509", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004509", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004509", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004509", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004509", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004509", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004509", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004509", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004509", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004509", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004509", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004509", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004509")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004510")
    void case_UTAPI_004510() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004510",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004510", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004510", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004510", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004510", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004510", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004510", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004510", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004510", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004510", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004510", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004510", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004510", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004510", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004510", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004510", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004510", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004510")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004511")
    void case_UTAPI_004511() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004511",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004511", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004511", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004511", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004511", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004511", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004511", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004511", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004511", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004511", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004511", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004511", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004511", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004511", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004511", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004511", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004511", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004511")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004512")
    void case_UTAPI_004512() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004512",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004512", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004512", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004512", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004512", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004512", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004512", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004512", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004512", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004512", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004512", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004512", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004512", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004512", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004512", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004512", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004512", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004512")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004513")
    void case_UTAPI_004513() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004513",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004513", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004513", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004513", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004513", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004513", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004513", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004513", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004513", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004513", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004513", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004513", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004513", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004513", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004513", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004513", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004513", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004513")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004514")
    void case_UTAPI_004514() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004514",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004514", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004514", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004514", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004514", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004514", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004514", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004514", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004514", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004514", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004514", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004514", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004514", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004514", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004514", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004514", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004514", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004514")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004515")
    void case_UTAPI_004515() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004515",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004515", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004515", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004515", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004515", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004515", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004515", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004515", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004515", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004515", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004515", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004515", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004515", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004515", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004515", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004515", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004515", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004515")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004516")
    void case_UTAPI_004516() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004516",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004516", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004516", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004516", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004516", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004516", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004516", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004516", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004516", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004516", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004516", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004516", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004516", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004516", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004516", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004516", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004516", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004516")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004517")
    void case_UTAPI_004517() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004517",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004517", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004517", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004517", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004517", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004517", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004517", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004517", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004517", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004517", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004517", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004517", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004517", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004517", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004517", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004517", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004517", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004517")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004518")
    void case_UTAPI_004518() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004518",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004518", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004518", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004518", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004518", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004518", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004518", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004518", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004518", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004518", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004518", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004518", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004518", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004518", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004518", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004518", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004518", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004518")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004519")
    void case_UTAPI_004519() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004519",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004519", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004519", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004519", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004519", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004519", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004519", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004519", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004519", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004519", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004519", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004519", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004519", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004519", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004519", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004519", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004519", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004519")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004520")
    void case_UTAPI_004520() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004520",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004520", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004520", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004520", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004520", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004520", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004520", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004520", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004520", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004520", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004520", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004520", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004520", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004520", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004520", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004520", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004520", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004520")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004521")
    void case_UTAPI_004521() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004521",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004521", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004521", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004521", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004521", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004521", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004521", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004521", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004521", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004521", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004521", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004521", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004521", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004521", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004521", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004521", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004521", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004521")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004522")
    void case_UTAPI_004522() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004522",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004522", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004522", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004522", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004522", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004522", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004522", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004522", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004522", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004522", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004522", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004522", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004522", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004522", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004522", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004522", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004522", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004522")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004523")
    void case_UTAPI_004523() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004523",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004523", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004523", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004523", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004523", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004523", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004523", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004523", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004523", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004523", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004523", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004523", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004523", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004523", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004523", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004523", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004523", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004523")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004524")
    void case_UTAPI_004524() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004524",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004524", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004524", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004524", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004524", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004524", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004524", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004524", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004524", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004524", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004524", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004524", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004524", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004524", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004524", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004524", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004524", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004524")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004525")
    void case_UTAPI_004525() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004525",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004525", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004525", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004525", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004525", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004525", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004525", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004525", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004525", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004525", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004525", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004525", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004525", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004525", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004525", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004525", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004525", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004525")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004526")
    void case_UTAPI_004526() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004526",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004526", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004526", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004526", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004526", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004526", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004526", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004526", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004526", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004526", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004526", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004526", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004526", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004526", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004526", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004526", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004526", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004526")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004527")
    void case_UTAPI_004527() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004527",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004527", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004527", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004527", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004527", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004527", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004527", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004527", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004527", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004527", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004527", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004527", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004527", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004527", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004527", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004527", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004527", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004527")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004528")
    void case_UTAPI_004528() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004528",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004528", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004528", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004528", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004528", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004528", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004528", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004528", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004528", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004528", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004528", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004528", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004528", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004528", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004528", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004528", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004528", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004528")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004529")
    void case_UTAPI_004529() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004529",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004529", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004529", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004529", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004529", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004529", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004529", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004529", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004529", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004529", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004529", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004529", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004529", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004529", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004529", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004529", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004529", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004529")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004530")
    void case_UTAPI_004530() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004530",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004530", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004530", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004530", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004530", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004530", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004530", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004530", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004530", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004530", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004530", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004530", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004530", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004530", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004530", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004530", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004530", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004530")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004531")
    void case_UTAPI_004531() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004531",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004531", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004531", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004531", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004531", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004531", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004531", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004531", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004531", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004531", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004531", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004531", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004531", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004531", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004531", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004531", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004531", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004531")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004532")
    void case_UTAPI_004532() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004532",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004532", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004532", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004532", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004532", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004532", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004532", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004532", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004532", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004532", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004532", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004532", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004532", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004532", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004532", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004532", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004532", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004532")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004533")
    void case_UTAPI_004533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004533",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004533", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004533", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004533", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004533", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004533", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004533", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004533", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004533", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004533", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004533", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004533", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004533", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004533", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004533", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004533", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004533", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004533")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004534")
    void case_UTAPI_004534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004534",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004534", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004534", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004534", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004534", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004534", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004534", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004534", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004534", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004534", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004534", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004534", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004534", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004534", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004534", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004534", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004534", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004534")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004535")
    void case_UTAPI_004535() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004535",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004535", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004535", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004535", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004535", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004535", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004535", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004535", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004535", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004535", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004535", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004535", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004535", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004535", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004535", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004535", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004535", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004535")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004536")
    void case_UTAPI_004536() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004536",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004536", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004536", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004536", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004536", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004536", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004536", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004536", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004536", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004536", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004536", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004536", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004536", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004536", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004536", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004536", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004536", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004536")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004537")
    void case_UTAPI_004537() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004537",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004537", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004537", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004537", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004537", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004537", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004537", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004537", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004537", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004537", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004537", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004537", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004537", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004537", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004537", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004537", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004537", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004537")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004538")
    void case_UTAPI_004538() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004538",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004538", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004538", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004538", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004538", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004538", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004538", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004538", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004538", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004538", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004538", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004538", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004538", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004538", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004538", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004538", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004538", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004538")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004539")
    void case_UTAPI_004539() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004539",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004539", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004539", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004539", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004539", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004539", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004539", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004539", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004539", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004539", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004539", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004539", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004539", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004539", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004539", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004539", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004539", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004539")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004540")
    void case_UTAPI_004540() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004540",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004540", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004540", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004540", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004540", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004540", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004540", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004540", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004540", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004540", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004540", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004540", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004540", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004540", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004540", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004540", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004540", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004540")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004541")
    void case_UTAPI_004541() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004541",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004541", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004541", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004541", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004541", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004541", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004541", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004541", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004541", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004541", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004541", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004541", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004541", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004541", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004541", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004541", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004541", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004541")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004542")
    void case_UTAPI_004542() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004542",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004542", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004542", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004542", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004542", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004542", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004542", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004542", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004542", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004542", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004542", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004542", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004542", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004542", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004542", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004542", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004542", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004542")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004543")
    void case_UTAPI_004543() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004543",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004543", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004543", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004543", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004543", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004543", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004543", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004543", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004543", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004543", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004543", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004543", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004543", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004543", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004543", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004543", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004543", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004543")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004544")
    void case_UTAPI_004544() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004544",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004544", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004544", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004544", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004544", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004544", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004544", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004544", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004544", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004544", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004544", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004544", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004544", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004544", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004544", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004544", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004544", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004544")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004545")
    void case_UTAPI_004545() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004545",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004545", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004545", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004545", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004545", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004545", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004545", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004545", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004545", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004545", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004545", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004545", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004545", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004545", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004545", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004545", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004545", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004545")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004546")
    void case_UTAPI_004546() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004546",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004546", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004546", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004546", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004546", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004546", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004546", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004546", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004546", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004546", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004546", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004546", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004546", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004546", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004546", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004546", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004546", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004546")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004547")
    void case_UTAPI_004547() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004547",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004547", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004547", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004547", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004547", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004547", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004547", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004547", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004547", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004547", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004547", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004547", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004547", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004547", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004547", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004547", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004547", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004547")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004548")
    void case_UTAPI_004548() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004548",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004548", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004548", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004548", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004548", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004548", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004548", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004548", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004548", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004548", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004548", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004548", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004548", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004548", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004548", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004548", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004548", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004548")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004549")
    void case_UTAPI_004549() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004549",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004549", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004549", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004549", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004549", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004549", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004549", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004549", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004549", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004549", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004549", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004549", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004549", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004549", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004549", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004549", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004549", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004549")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004550")
    void case_UTAPI_004550() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004550",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004550", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004550", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004550", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004550", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004550", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004550", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004550", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004550", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004550", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004550", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004550", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004550", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004550", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004550", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004550", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004550", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004550")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004551")
    void case_UTAPI_004551() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004551",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004551", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004551", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004551", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004551", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004551", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004551", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004551", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004551", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004551", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004551", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004551", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004551", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004551", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004551", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004551", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004551", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004551")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004552")
    void case_UTAPI_004552() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004552",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004552", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004552", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004552", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004552", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004552", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004552", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004552", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004552", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004552", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004552", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004552", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004552", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004552", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004552", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004552", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004552", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004552")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004553")
    void case_UTAPI_004553() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004553",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004553", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004553", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004553", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004553", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004553", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004553", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004553", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004553", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004553", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004553", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004553", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004553", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004553", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004553", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004553", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004553", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004553")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004554")
    void case_UTAPI_004554() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004554",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004554", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004554", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004554", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004554", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004554", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004554", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004554", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004554", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004554", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004554", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004554", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004554", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004554", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004554", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004554", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004554", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004554")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004555")
    void case_UTAPI_004555() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004555",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004555", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004555", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004555", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004555", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004555", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004555", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004555", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004555", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004555", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004555", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004555", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004555", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004555", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004555", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004555", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004555", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004555")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004556")
    void case_UTAPI_004556() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004556",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004556", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004556", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004556", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004556", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004556", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004556", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004556", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004556", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004556", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004556", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004556", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004556", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004556", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004556", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004556", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004556", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004556")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004557")
    void case_UTAPI_004557() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004557",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004557", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004557", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004557", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004557", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004557", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004557", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004557", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004557", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004557", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004557", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004557", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004557", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004557", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004557", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004557", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004557", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004557")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004558")
    void case_UTAPI_004558() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004558",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004558", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004558", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004558", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004558", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004558", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004558", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004558", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004558", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004558", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004558", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004558", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004558", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004558", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004558", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004558", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004558", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004558")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004559")
    void case_UTAPI_004559() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004559",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004559", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004559", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004559", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004559", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004559", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004559", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004559", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004559", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004559", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004559", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004559", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004559", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004559", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004559", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004559", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004559", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004559")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004560")
    void case_UTAPI_004560() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004560",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004560", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004560", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004560", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004560", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004560", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004560", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004560", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004560", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004560", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004560", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004560", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004560", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004560", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004560", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004560", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004560", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004560")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004561")
    void case_UTAPI_004561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004561",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004561", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004561", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004561", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004561", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004561", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004561", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004561", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004561", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004561", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004561", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004561", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004561", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004561", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004561", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004561", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004561", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004561")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004562")
    void case_UTAPI_004562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004562",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004562", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004562", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004562", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004562", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004562", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004562", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004562", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004562", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004562", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004562", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004562", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004562", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004562", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004562", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004562", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004562", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004562")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004563")
    void case_UTAPI_004563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004563",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004563", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004563", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004563", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004563", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004563", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004563", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004563", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004563", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004563", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004563", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004563", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004563", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004563", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004563", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004563", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004563", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004563")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004564")
    void case_UTAPI_004564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004564",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004564", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004564", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004564", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004564", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004564", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004564", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004564", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004564", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004564", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004564", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004564", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004564", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004564", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004564", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004564", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004564", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004564")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004565")
    void case_UTAPI_004565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004565",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004565", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004565", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004565", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004565", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004565", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004565", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004565", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004565", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004565", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004565", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004565", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004565", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004565", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004565", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004565", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004565", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004565")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004566")
    void case_UTAPI_004566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004566",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004566", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004566", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004566", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004566", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004566", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004566", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004566", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004566", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004566", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004566", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004566", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004566", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004566", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004566", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004566", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004566", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004566")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004567")
    void case_UTAPI_004567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004567",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004567", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004567", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004567", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004567", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004567", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004567", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004567", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004567", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004567", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004567", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004567", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004567", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004567", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004567", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004567", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004567", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004567")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004568")
    void case_UTAPI_004568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004568",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004568", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004568", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004568", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004568", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004568", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004568", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004568", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004568", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004568", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004568", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004568", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004568", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004568", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004568", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004568", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004568", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004568")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004569")
    void case_UTAPI_004569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004569",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004569", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004569", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004569", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004569", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004569", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004569", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004569", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004569", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004569", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004569", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004569", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004569", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004569", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004569", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004569", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004569", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004569")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004570")
    void case_UTAPI_004570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004570",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004570", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004570", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004570", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004570", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004570", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004570", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004570", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004570", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004570", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004570", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004570", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004570", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004570", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004570", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004570", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004570", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004570")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004571")
    void case_UTAPI_004571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004571",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004571", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004571", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004571", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004571", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004571", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004571", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004571", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004571", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004571", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004571", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004571", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004571", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004571", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004571", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004571", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004571", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004571")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004572")
    void case_UTAPI_004572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004572",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004572", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004572", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004572", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004572", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004572", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004572", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004572", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004572", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004572", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004572", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004572", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004572", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004572", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004572", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004572", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004572", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004572")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004573")
    void case_UTAPI_004573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004573",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004573", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004573", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004573", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004573", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004573", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004573", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004573", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004573", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004573", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004573", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004573", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004573", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004573", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004573", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004573", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004573", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004573")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004574")
    void case_UTAPI_004574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004574",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004574", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004574", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004574", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004574", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004574", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004574", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004574", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004574", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004574", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004574", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004574", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004574", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004574", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004574", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004574", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004574", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004574")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004575")
    void case_UTAPI_004575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004575",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004575", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004575", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004575", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004575", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004575", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004575", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004575", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004575", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004575", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004575", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004575", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004575", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004575", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004575", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004575", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004575", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004575")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004576")
    void case_UTAPI_004576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004576",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004576", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004576", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004576", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004576", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004576", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004576", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004576", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004576", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004576", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004576", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004576", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004576", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004576", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004576", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004576", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004576", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004576")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004577")
    void case_UTAPI_004577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004577",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004577", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004577", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004577", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004577", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004577", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004577", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004577", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004577", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004577", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004577", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004577", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004577", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004577", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004577", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004577", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004577", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004577")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004578")
    void case_UTAPI_004578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004578",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004578", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004578", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004578", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004578", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004578", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004578", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004578", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004578", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004578", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004578", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004578", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004578", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004578", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004578", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004578", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004578", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004578")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004579")
    void case_UTAPI_004579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004579",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004579", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004579", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004579", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004579", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004579", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004579", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004579", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004579", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004579", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004579", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004579", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004579", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004579", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004579", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004579", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004579", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004579")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004580")
    void case_UTAPI_004580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004580",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004580", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004580", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004580", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004580", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004580", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004580", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004580", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004580", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004580", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004580", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004580", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004580", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004580", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004580", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004580", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004580", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004580")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004581")
    void case_UTAPI_004581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004581",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004581", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004581", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004581", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004581", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004581", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004581", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004581", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004581", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004581", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004581", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004581", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004581", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004581", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004581", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004581", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004581", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004581")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004582")
    void case_UTAPI_004582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004582",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004582", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004582", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004582", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004582", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004582", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004582", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004582", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004582", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004582", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004582", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004582", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004582", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004582", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004582", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004582", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004582", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004582")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004583")
    void case_UTAPI_004583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004583",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004583", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004583", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004583", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004583", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004583", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004583", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004583", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004583", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004583", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004583", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004583", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004583", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004583", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004583", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004583", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004583", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004583")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004584")
    void case_UTAPI_004584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004584",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004584", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004584", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004584", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004584", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004584", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004584", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004584", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004584", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004584", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004584", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004584", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004584", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004584", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004584", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004584", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004584", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004584")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004585")
    void case_UTAPI_004585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004585",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004585", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004585", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004585", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004585", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004585", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004585", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004585", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004585", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004585", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004585", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004585", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004585", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004585", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004585", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004585", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004585", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004585")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004586")
    void case_UTAPI_004586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004586",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004586", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004586", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004586", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004586", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004586", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004586", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004586", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004586", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004586", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004586", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004586", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004586", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004586", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004586", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004586", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004586", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004586")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004587")
    void case_UTAPI_004587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004587",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004587", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004587", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004587", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004587", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004587", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004587", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004587", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004587", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004587", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004587", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004587")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004588")
    void case_UTAPI_004588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004588",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004588", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004588", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004588", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004588", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004588", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004588", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004588", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004588", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004588", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004588", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004588")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004589")
    void case_UTAPI_004589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004589",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004589", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004589", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004589", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004589", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004589", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004589", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004589", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004589", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004589", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004589", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004589")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004590")
    void case_UTAPI_004590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004590",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004590", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004590", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004590", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004590", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004590", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004590", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004590", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004590", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004590", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004590", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004590")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004591")
    void case_UTAPI_004591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004591",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004591", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004591", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004591", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004591", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004591", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004591", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004591", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004591", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004591", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004591", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004591")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004592")
    void case_UTAPI_004592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004592",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004592", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004592", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004592", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004592", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004592", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004592", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004592", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004592", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004592", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004592", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004592")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004593")
    void case_UTAPI_004593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004593",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004593", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004593", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004593", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004593", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004593", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004593", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004593", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004593", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004593", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004593", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004593")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004594")
    void case_UTAPI_004594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004594",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004594", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004594", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004594", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004594", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004594", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004594", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004594", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004594", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004594", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004594", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004594")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004595")
    void case_UTAPI_004595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004595",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004595", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004595", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004595", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004595", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004595", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004595", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004595", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004595", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004595", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004595", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004595")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004596")
    void case_UTAPI_004596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004596",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004596", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004596", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004596", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004596", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004596", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004596", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004596", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004596", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004596", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004596", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004596")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004597")
    void case_UTAPI_004597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004597",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004597", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004597", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004597", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004597", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004597", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004597", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004597", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004597", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004597", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004597", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004597")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004598")
    void case_UTAPI_004598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004598",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004598", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004598", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004598", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004598", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004598", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004598", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004598", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004598", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004598", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004598", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004598", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004598", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004598", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004598", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004598", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004598", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004598")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004599")
    void case_UTAPI_004599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004599",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004599", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004599", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004599", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004599", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004599", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004599", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004599", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004599", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004599", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004599", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004599", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004599", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004599", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004599", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004599", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004599", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004599")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004600")
    void case_UTAPI_004600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004600",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004600", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004600", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004600", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004600", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004600", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004600", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004600", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004600", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004600", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004600", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004600", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004600", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004600", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004600", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004600", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004600", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004600")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004601")
    void case_UTAPI_004601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004601",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004601", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004601", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004601", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004601", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004601", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004601", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004601", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004601", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004601", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004601", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004601", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004601", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004601", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004601", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004601", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004601", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004601")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004602")
    void case_UTAPI_004602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004602",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004602", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004602", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004602", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004602", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004602", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004602", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004602", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004602", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004602", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004602", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004602", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004602", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004602", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004602", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004602", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004602", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004602")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004603")
    void case_UTAPI_004603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004603",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004603", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004603", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004603", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004603", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004603", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004603", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004603", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004603", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004603", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004603", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004603", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004603", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004603", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004603", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004603", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004603", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004603")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004604")
    void case_UTAPI_004604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004604",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004604", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004604", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004604", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004604", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004604", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004604", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004604", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004604", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004604", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004604", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004604", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004604", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004604", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004604", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004604", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004604", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004604")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004605")
    void case_UTAPI_004605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004605",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004605", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004605", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004605", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004605", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004605", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004605", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004605", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004605", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004605", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004605", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004605", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004605", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004605", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004605", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004605", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004605", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004605")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004606")
    void case_UTAPI_004606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004606",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004606", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004606", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004606", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004606", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004606", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004606", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004606", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004606", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004606", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004606", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004606", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004606", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004606", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004606", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004606", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004606", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004606")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004607")
    void case_UTAPI_004607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004607",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004607", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004607", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004607", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004607", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004607", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004607", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004607", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004607", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004607", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004607", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004607", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004607", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004607", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004607", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004607", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004607", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004607")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004608")
    void case_UTAPI_004608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004608",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004608", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004608", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004608", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004608", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004608", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004608", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004608", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004608", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004608", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004608", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004608", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004608", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004608", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004608", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004608", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004608", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004608")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004609")
    void case_UTAPI_004609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004609",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004609", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004609", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004609", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004609", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004609", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004609", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004609", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004609", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004609", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004609", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004609", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004609", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004609", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004609", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004609", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004609", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004609")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004610")
    void case_UTAPI_004610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004610",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004610", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004610", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004610", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004610", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004610", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004610", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004610", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004610", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004610", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004610", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004610", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004610", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004610", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004610", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004610", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004610", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004610")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004611")
    void case_UTAPI_004611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004611",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004611", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004611", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004611", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004611", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004611", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004611", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004611", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004611", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004611", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004611", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004611", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004611", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004611", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004611", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004611", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004611", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004611")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004612")
    void case_UTAPI_004612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004612",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004612", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004612", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004612", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004612", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004612", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004612", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004612", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004612", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004612", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004612", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004612", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004612", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004612", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004612", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004612", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004612", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004612")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004613")
    void case_UTAPI_004613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004613",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004613", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004613", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004613", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004613", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004613", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004613", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004613", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004613", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004613", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004613", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004613", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004613", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004613", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004613", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004613", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004613", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004613")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004614")
    void case_UTAPI_004614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004614",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004614", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004614", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004614", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004614", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004614", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004614", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004614", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004614", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004614", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004614", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004614", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004614", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004614", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004614", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004614", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004614", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004614")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004615")
    void case_UTAPI_004615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004615",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004615", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004615", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004615", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004615", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004615", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004615", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004615", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004615", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004615", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004615", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004615", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004615", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004615", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004615", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004615", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004615", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004615")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004616")
    void case_UTAPI_004616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004616",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004616", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004616", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004616", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004616", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004616", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004616", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004616", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004616", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004616", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004616", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004616", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004616", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004616", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004616", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004616", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004616", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004616")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004617")
    void case_UTAPI_004617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004617",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004617", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004617", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004617", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004617", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004617", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004617", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004617", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004617", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004617", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004617", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004617", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004617", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004617", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004617", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004617", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004617", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004617")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004618")
    void case_UTAPI_004618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004618",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004618", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004618", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004618", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004618", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004618", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004618", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004618", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004618", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004618", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004618", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004618", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004618", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004618", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004618", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004618", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004618", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004618")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004619")
    void case_UTAPI_004619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004619",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004619", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004619", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004619", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004619", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004619", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004619", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004619", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004619", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004619", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004619", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004619")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004620")
    void case_UTAPI_004620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004620",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004620", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004620", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004620", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004620", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004620", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004620", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004620", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004620", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004620", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004620", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004620")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004621")
    void case_UTAPI_004621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004621",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004621", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004621", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004621", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004621", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004621", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004621", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004621", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004621", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004621", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004621", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004621")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004622")
    void case_UTAPI_004622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004622",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004622", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004622", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004622", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004622", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004622", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004622", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004622", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004622", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004622", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004622", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004622")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004623")
    void case_UTAPI_004623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004623",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004623", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004623", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004623", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004623", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004623", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004623", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004623", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004623", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004623", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004623", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004623")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004624")
    void case_UTAPI_004624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004624",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004624", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004624", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004624", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004624", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004624", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004624", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004624", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004624", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004624", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004624", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004624")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004625")
    void case_UTAPI_004625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004625",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004625", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004625", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004625", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004625", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004625", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004625", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004625", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004625", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004625", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004625", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004625")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004626")
    void case_UTAPI_004626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004626",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004626", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004626", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004626", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004626", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004626", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004626", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004626", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004626", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004626", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004626", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004626")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004627")
    void case_UTAPI_004627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004627",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004627", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004627", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004627", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004627", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004627", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004627", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004627", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004627", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004627", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004627", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004627")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004628")
    void case_UTAPI_004628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004628",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004628", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004628", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004628", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004628", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004628", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004628", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004628", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004628", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004628", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004628", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004628")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004629")
    void case_UTAPI_004629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004629",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004629", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004629", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004629", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004629", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004629", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004629", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004629", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004629", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004629", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004629", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004629")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004630")
    void case_UTAPI_004630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004630",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004630", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004630", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004630", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004630", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004630", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004630", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004630", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004630", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004630", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004630", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004630")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004631")
    void case_UTAPI_004631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004631",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004631", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004631", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004631", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004631", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004631", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004631", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004631", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004631", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004631", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004631", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004631")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004632")
    void case_UTAPI_004632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004632",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004632", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004632", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004632", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004632", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004632", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004632", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004632", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004632", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004632", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004632", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004632")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004633")
    void case_UTAPI_004633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004633",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004633", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004633", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004633", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004633", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004633", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004633", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004633", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004633", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004633", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004633", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004633")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004634")
    void case_UTAPI_004634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004634",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004634", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004634", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004634", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004634", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004634", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004634", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004634", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004634", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004634", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004634", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004634")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004635")
    void case_UTAPI_004635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004635",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004635", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004635", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004635", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004635", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004635", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004635", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004635", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004635", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004635", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004635", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004635")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004636")
    void case_UTAPI_004636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004636",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004636", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004636", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004636", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004636", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004636", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004636", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004636", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004636", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004636", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004636", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004636")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004637")
    void case_UTAPI_004637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004637",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004637", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004637", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004637", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004637", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004637", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004637", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004637", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004637", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004637", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004637", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004637")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004638")
    void case_UTAPI_004638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004638",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004638", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004638", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004638", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004638", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004638", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004638", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004638", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004638", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004638", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004638", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004638", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004638", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004638", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004638", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004638", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004638", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004638")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004639")
    void case_UTAPI_004639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004639",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004639", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004639", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004639", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004639", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004639", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004639", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004639", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004639", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004639", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004639", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004639", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004639", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004639", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004639", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004639", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004639", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004639")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004640")
    void case_UTAPI_004640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004640",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004640", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004640", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004640", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004640", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004640", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004640", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004640", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004640", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004640", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004640", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004640", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004640", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004640", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004640", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004640", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004640", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004640")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004641")
    void case_UTAPI_004641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004641",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004641", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004641", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004641", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004641", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004641", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004641", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004641", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004641", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004641", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004641", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004641", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004641", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004641", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004641", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004641", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004641", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004641")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004642")
    void case_UTAPI_004642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004642",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004642", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004642", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004642", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004642", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004642", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004642", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004642", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004642", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004642", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004642", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004642", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004642", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004642", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004642", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004642", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004642", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004642")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004643")
    void case_UTAPI_004643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004643",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004643", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004643", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004643", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004643", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004643", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004643", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004643", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004643", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004643", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004643", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004643", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004643", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004643", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004643", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004643", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004643", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004643")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004644")
    void case_UTAPI_004644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004644",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004644", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004644", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004644", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004644", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004644", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004644", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004644", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004644", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004644", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004644", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004644", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004644", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004644", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004644", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004644", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004644", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004644")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004645")
    void case_UTAPI_004645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004645",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004645", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004645", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004645", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004645", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004645", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004645", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004645", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004645", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004645", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004645", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004645", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004645", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004645", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004645", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004645", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004645", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004645")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004646")
    void case_UTAPI_004646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004646",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004646", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004646", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004646", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004646", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004646", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004646", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004646", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004646", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004646", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004646", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004646", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004646", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004646", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004646", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004646", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004646", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004646")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004647")
    void case_UTAPI_004647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004647",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004647", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004647", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004647", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004647", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004647", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004647", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004647", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004647", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004647", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004647", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004647", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004647", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004647", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004647", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004647", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004647", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004647")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004648")
    void case_UTAPI_004648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004648",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004648", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004648", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004648", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004648", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004648", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004648", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004648", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004648", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004648", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004648", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004648", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004648", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004648", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004648", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004648", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004648", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004648")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004649")
    void case_UTAPI_004649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004649",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004649", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004649", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004649", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004649", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004649", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004649", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004649", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004649", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004649", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004649", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004649", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004649", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004649", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004649", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004649", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004649", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004649")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004650")
    void case_UTAPI_004650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004650",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004650", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004650", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004650", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004650", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004650", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004650", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004650", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004650", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004650", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004650", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004650", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004650", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004650", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004650", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004650", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004650", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004650")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004651")
    void case_UTAPI_004651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004651",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004651", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004651", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004651", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004651", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004651", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004651", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004651", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004651", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004651", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004651", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004651", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004651", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004651", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004651", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004651", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004651", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004651")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004652")
    void case_UTAPI_004652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004652",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004652", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004652", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004652", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004652", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004652", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004652", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004652", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004652", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004652", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004652", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004652", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004652", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004652", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004652", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004652", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004652", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004652")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004653")
    void case_UTAPI_004653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004653",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004653", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004653", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004653", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004653", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004653", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004653", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004653", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004653", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004653", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004653", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004653", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004653", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004653", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004653", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004653", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004653", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004653")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004654")
    void case_UTAPI_004654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004654",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004654", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004654", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004654", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004654", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004654", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004654", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004654", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004654", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004654", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004654", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004654", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004654", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004654", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004654", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004654", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004654", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004654")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004655")
    void case_UTAPI_004655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004655",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004655", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004655", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004655", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004655", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004655", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004655", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004655", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004655", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004655", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004655", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004655", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004655", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004655", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004655", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004655", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004655", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004655")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004656")
    void case_UTAPI_004656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004656",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004656", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004656", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004656", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004656", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004656", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004656", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004656", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004656", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004656", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004656", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004656", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004656", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004656", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004656", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004656", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004656", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004656")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004657")
    void case_UTAPI_004657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004657",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004657", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004657", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004657", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004657", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004657", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004657", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004657", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004657", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004657", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004657", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004657", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004657", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004657", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004657", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004657", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004657", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004657")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004658")
    void case_UTAPI_004658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004658",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004658", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004658", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004658", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004658", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004658", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004658", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004658", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004658", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004658", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004658", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004658", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004658", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004658", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004658", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004658", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004658", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004658")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004659")
    void case_UTAPI_004659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004659",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004659", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004659", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004659", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004659", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004659", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004659", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004659", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004659", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004659", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004659", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004659")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004660")
    void case_UTAPI_004660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004660",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004660", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004660", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004660", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004660", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004660", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004660", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004660", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004660", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004660", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004660", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004660")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004661")
    void case_UTAPI_004661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004661",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004661", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004661", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004661", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004661", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004661", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004661", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004661", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004661", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004661", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004661", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004661")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004662")
    void case_UTAPI_004662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004662",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004662", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004662", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004662", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004662", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004662", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004662", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004662", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004662", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004662", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004662", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004662")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004663")
    void case_UTAPI_004663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004663",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004663", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004663", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004663", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004663", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004663", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004663", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004663", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004663", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004663", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004663", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004663")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004664")
    void case_UTAPI_004664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004664",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004664", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004664", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004664", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004664", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004664", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004664", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004664", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004664", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004664", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004664", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004664")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004665")
    void case_UTAPI_004665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004665",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004665", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004665", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004665", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004665", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004665", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004665", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004665", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004665", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004665", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004665", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004665")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004666")
    void case_UTAPI_004666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004666",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004666", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004666", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004666", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004666", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004666", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004666", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004666", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004666", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004666", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004666", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004666")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004667")
    void case_UTAPI_004667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004667",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004667", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004667", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004667", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004667", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004667", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004667", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004667", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004667", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004667", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004667", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004667")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004668")
    void case_UTAPI_004668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004668",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004668", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004668", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004668", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004668", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004668", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004668", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004668", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004668", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004668", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004668", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004668")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004669")
    void case_UTAPI_004669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004669",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004669", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004669", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004669", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004669", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004669", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004669", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004669", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004669", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004669", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004669", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004669")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004670")
    void case_UTAPI_004670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004670",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004670", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004670", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004670", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004670", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004670", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004670", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004670", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004670", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004670", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004670", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004670")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004671")
    void case_UTAPI_004671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004671",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004671", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004671", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004671", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004671", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004671", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004671", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004671", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004671")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004672")
    void case_UTAPI_004672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004672",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004672", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004672", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004672", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004672", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004672", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004672", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004672", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004672")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004673")
    void case_UTAPI_004673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004673",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004673", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004673", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004673", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004673", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004673", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004673", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004673", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004673")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004674")
    void case_UTAPI_004674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004674",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004674", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004674", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004674", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004674", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004674", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004674", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004674", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004674")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004675")
    void case_UTAPI_004675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004675",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004675", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004675", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004675", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004675", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004675", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004675", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004675", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004675")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004676")
    void case_UTAPI_004676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004676",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004676", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004676", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004676", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004676", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004676", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004676", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004676", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004676")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004677")
    void case_UTAPI_004677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004677",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004677", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004677", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004677", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004677", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004677", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004677", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004677", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004677")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004678")
    void case_UTAPI_004678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004678",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004678", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004678", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004678", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004678", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004678", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004678", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004678")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004679")
    void case_UTAPI_004679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004679",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004679", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004679", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004679", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004679", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004679", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004679", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004679", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004679")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004680")
    void case_UTAPI_004680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004680",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004680", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004680", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004680", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004680", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004680", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004680", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004680", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004680")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "1:length_null", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004681")
    void case_UTAPI_004681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004681",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004681", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004681", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004681", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004681", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004681", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004681", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004681", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004681")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004682")
    void case_UTAPI_004682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004682",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004682", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004682", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004682", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004682", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004682", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004682", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004682", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004682")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "3:length_min", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004683")
    void case_UTAPI_004683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004683",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004683", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004683", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004683", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004683", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004683", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004683", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004683", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004683")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004684")
    void case_UTAPI_004684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004684",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004684", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004684", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004684", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004684", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004684", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004684", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004684")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "5:length_max", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004685")
    void case_UTAPI_004685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004685",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004685", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004685", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004685", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004685", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004685", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004685", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004685")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004686")
    void case_UTAPI_004686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004686",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "saveHistory",
                "int",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004686", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004686", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-004686", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-004686", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-004686", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004686", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-004686")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::saveHistory::3::ARG::4::-::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

}

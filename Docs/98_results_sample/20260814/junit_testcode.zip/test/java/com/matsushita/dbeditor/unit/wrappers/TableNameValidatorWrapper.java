package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableNameValidator.
 */
public final class TableNameValidatorWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.infrastructure.database.TableNameValidator";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.infrastructure.database.TableNameValidator";
    private static final String[] DEP_NAMES = new String[] {"VALID_IDENTIFIER"};
    private static final String[] DEP_TYPES = new String[] {"Pattern"};
    private static final String[] TYPES_Constructor1 = new String[] {};
    private static final String[] TYPES_backupTableName = new String[] {"String"};
    private static final String[] TYPES_copyTableName = new String[] {"String"};
    private static final String[] TYPES_historyTableName = new String[] {"String", "int"};
    private static final String[] TYPES_quoted = new String[] {"String", "String"};
    private static final String[] TYPES_quotedBackup = new String[] {"String", "String"};
    private static final String[] TYPES_quotedCopy = new String[] {"String", "String"};
    private static final String[] TYPES_quotedHistory = new String[] {"String", "String", "int"};
    private static final String[] TYPES_quotedReal = new String[] {"String", "String"};
    private static final String[] TYPES_validate = new String[] {"String"};

    public TableNameValidatorWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** - Constructor1() */
    public ExecutionResult Constructor1(Object[] args) {
        return invoke("Constructor1", TYPES_Constructor1, args);
    }

    /** String backupTableName(tableName) */
    public ExecutionResult backupTableName(Object[] args) {
        return invoke("backupTableName", TYPES_backupTableName, args);
    }

    /** String copyTableName(tableName) */
    public ExecutionResult copyTableName(Object[] args) {
        return invoke("copyTableName", TYPES_copyTableName, args);
    }

    /** String historyTableName(tableName, seq) */
    public ExecutionResult historyTableName(Object[] args) {
        return invoke("historyTableName", TYPES_historyTableName, args);
    }

    /** String quoted(schemaName, tableName) */
    public ExecutionResult quoted(Object[] args) {
        return invoke("quoted", TYPES_quoted, args);
    }

    /** String quotedBackup(schemaName, tableName) */
    public ExecutionResult quotedBackup(Object[] args) {
        return invoke("quotedBackup", TYPES_quotedBackup, args);
    }

    /** String quotedCopy(schemaName, tableName) */
    public ExecutionResult quotedCopy(Object[] args) {
        return invoke("quotedCopy", TYPES_quotedCopy, args);
    }

    /** String quotedHistory(schemaName, tableName, seq) */
    public ExecutionResult quotedHistory(Object[] args) {
        return invoke("quotedHistory", TYPES_quotedHistory, args);
    }

    /** String quotedReal(schemaName, tableName) */
    public ExecutionResult quotedReal(Object[] args) {
        return invoke("quotedReal", TYPES_quotedReal, args);
    }

    /** String validate(name) */
    public ExecutionResult validate(Object[] args) {
        return invoke("validate", TYPES_validate, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("Constructor1".equals(operation)) {
            return Constructor1(args);
        } else if ("backupTableName".equals(operation)) {
            return backupTableName(args);
        } else if ("copyTableName".equals(operation)) {
            return copyTableName(args);
        } else if ("historyTableName".equals(operation)) {
            return historyTableName(args);
        } else if ("quoted".equals(operation)) {
            return quoted(args);
        } else if ("quotedBackup".equals(operation)) {
            return quotedBackup(args);
        } else if ("quotedCopy".equals(operation)) {
            return quotedCopy(args);
        } else if ("quotedHistory".equals(operation)) {
            return quotedHistory(args);
        } else if ("quotedReal".equals(operation)) {
            return quotedReal(args);
        } else if ("validate".equals(operation)) {
            return validate(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}
